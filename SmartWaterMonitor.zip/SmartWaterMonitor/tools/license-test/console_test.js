// اختبار منطق برنامج المطوّر (devconsole/swm-license-console.html) مقابل fake_swm.py.
// الاستخدام: node console_test.js http://127.0.0.1:PORT parity_dir
const fs = require('fs'), path = require('path');
const base = process.argv[2], pdir = process.argv[3];
const html = fs.readFileSync(path.join(__dirname, '../../devconsole/swm-license-console.html'), 'utf8');
const core = html.match(/<script id="core">([\s\S]*?)<\/script>/)[1];
const mod = { exports: {} }; new Function('module', core)(mod);
const S = mod.exports;
let failures = 0;
const check = (name, ok, detail = '') => { console.log((ok ? '  نجح  ' : '  فشل  ') + name + (detail ? '  -> ' + detail : '')); if (!ok) failures++; };
const rejects = async (p) => { try { await p; return null; } catch (e) { return e; } };
const state = async () => (await fetch(base + '/__state')).json();
const DAY = S.DAY;

(async () => {
  console.log('1) الترميز');
  const d0 = S.Ops.setTerm(null, 1700000000000, 365, 14, 'بمب | الأمل\nالفرع %1');
  const raw0 = S.encode(d0), back = S.decode(raw0);
  check('ذهاب وإياب مع | وسطر جديد و%', JSON.stringify(back) === JSON.stringify(d0) && back.org === 'بمب | الأمل\nالفرع %1');
  check('نص ببادئة خاطئة أو حقول ناقصة أو قيم غير صالحة → null',
    [null, '', 'UAL1|1|x|A|0|0|14|0|||0|0|0', raw0.replace('SWL1', 'XXXX'), raw0 + '|1', raw0.replace('|A|', '|Z|'), raw0.replace('|1|', '|-1|'), raw0.replace(/\|0\|0\|\d+$/, '|0|x|1')].every(t => S.decode(t) === null));
  check('هروب % غير صالح → null', S.decode(raw0.replace('%7C', '%ZZ')) === null);
  check('مفتاح التفعيل: 20 حرفًا Base32 مختلف كل مرة', (() => { const a = S.newKey(), b = S.newKey(); return /^[A-Z2-7]{20}$/.test(a) && a !== b && S.normKey(S.fmtKey(a).toLowerCase()) === a && S.normKey('abc') === null && S.normKey(a.slice(1) + '1') === null; })());

  console.log('2) العمليات النقية');
  const T = 1700000000000;
  const t1 = S.Ops.setTerm(null, T, 30, 7, 'أ');
  check('مدة 30 يومًا وسماح 7', t1.validUntilMs === T + 30 * DAY && t1.graceDays === 7 && t1.active && t1.rev === 1);
  check('مدة 0 = بلا نهاية', S.Ops.setTerm(null, T, 0, 14, 'أ').validUntilMs === 0);
  check('تمديد من نهاية الترخيص الحالية', S.Ops.extend(t1, T + 5 * DAY, 10).validUntilMs === T + 40 * DAY);
  check('تمديد منتهٍ يبدأ من الآن', S.Ops.extend(t1, T + 100 * DAY, 10).validUntilMs === T + 110 * DAY);
  const sus = S.Ops.suspend(t1, T, ' تأخر السداد ');
  check('تعليق يحفظ المدة والسبب', !sus.active && sus.reason === 'تأخر السداد' && sus.validUntilMs === t1.validUntilMs);
  check('استعادة ترفع التعليق دون المساس بالمدة', S.Ops.restore(sus, T).active && S.Ops.restore(sus, T).validUntilMs === t1.validUntilMs);
  check('صيانة وإنهاؤها', S.Ops.setMaintenance(t1, T, true, 'قريبًا').maintenance && !S.Ops.setMaintenance(S.Ops.setMaintenance(t1, T, true, 'x'), T, false, '').maintenance);
  const bad = fn => { try { fn(); return null; } catch (e) { return e.message; } };
  check('تحقق المدخلات برسائل عربية', bad(() => S.Ops.setTerm(null, T, 4000, 14, 'أ')).includes('3650') && bad(() => S.Ops.setTerm(null, T, 10, 14, '  ')).includes('اسم البمب')
    && bad(() => S.Ops.suspend(t1, T, '')).includes('سبب') && bad(() => S.Ops.extend(t1, T, 0)).includes('التمديد') && bad(() => S.Ops.setMaxDevices(t1, T, -1)).includes('الأجهزة')
    && bad(() => S.Ops.setNotice(t1, T, 'x'.repeat(301))).includes('300'));
  const st = (d, n) => S.statusOf(d, n).code;
  check('حالة العرض: فعّال/ينتهي قريبًا/سماح/منتهٍ/معلّق/صيانة',
    st(t1, T + DAY) === 'ACTIVE' && st(t1, T + 20 * DAY) === 'EXPIRING' && st(t1, T + 33 * DAY) === 'GRACE' && st(t1, T + 40 * DAY) === 'EXPIRED' && st(sus, T) === 'SUSPENDED' && st(S.Ops.setMaintenance(t1, T, true, 'x'), T) === 'MAINTENANCE');

  console.log('3) المصادقة');
  const auth = new S.Auth('TESTKEY', base, base);
  check('كلمة مرور خاطئة → رسالة عربية', (await rejects(auth.signIn('dev@example.com', 'bad'))).friendly === 'البريد أو كلمة المرور غير صحيحة');
  check('مفتاح API خاطئ → رسالة عربية', (await rejects(new S.Auth('WRONG', base, base).signIn('dev@example.com', 'pass1234'))).friendly === 'مفتاح Firebase غير صحيح');
  check('بلا مفتاح API → رسالة', (await rejects(new S.Auth('', base, base).signIn('a@b.c', 'x'))).code === 'NO_API_KEY');
  const sDev = await auth.signIn('dev@example.com', 'pass1234'), sOther = await auth.signIn('other@example.com', 'pass1234');
  const api = new S.Api(base, new S.Session(auth, sDev)), apiOther = new S.Api(base, new S.Session(auth, sOther));
  check('devAdmins: المطوّر نعم وغيره لا', (await api.isAuthorized(sDev.uid)) === true && (await apiOther.isAuthorized(sOther.uid)) === false);
  check('الوقت الحقيقي للخادم عبر ختم زمني', Math.abs((await api.serverNow()) - Date.now()) < 3000);

  console.log('4) إنشاء وإدارة التراخيص (كتابة ذرّية + سجل تدقيق)');
  const c = await S.createLicense(api, { org: 'بمب النور', days: 365, graceDays: 14, offlineDays: 30, maxDevices: 2, notice: 'أهلًا' });
  let db = await state();
  const stored = S.decode(db.swm.lic[c.id]);
  check('خُزّن المستند بمفتاحه والقيم المطلوبة', stored && stored.org === 'بمب النور' && stored.maxDevices === 2 && stored.offlineDays === 30 && stored.notice === 'أهلًا' && stored.active);
  const logs0 = Object.values(db.swm.log);
  check('سطر تدقيق واحد ذرّي بختم زمن الخادم', logs0.length === 1 && logs0[0].action === 'create' && logs0[0].uid === 'UID_DEV' && logs0[0].lic === c.id && Math.abs(logs0[0].t - Date.now()) < 3000);
  const denied = await rejects(S.createLicense(apiOther, { org: 'ممنوع', days: 10 }));
  db = await state();
  check('غير المطوّر لا يكتب شيئًا (لا ترخيص ولا سجل: الكتابة ذرّية)', denied && denied.code === 401 && Object.keys(db.swm.lic).length === 1 && Object.keys(db.swm.log).length === 1);
  check('غير المطوّر لا يسرد التراخيص ولا يقرأ السجل', (await rejects(apiOther.listLicenses())).code === 401 && (await rejects(apiOther.listLogs())).code === 401);
  const pub = await fetch(`${base}/swm/lic/${c.id}.json`);
  check('القراءة بالمفتاح علنية (بلا مصادقة) لكن لا سرد', pub.status === 200 && (await fetch(`${base}/swm/lic.json`)).status === 401);
  const l1 = await S.applyOp(api, c.id, 'extend', '30', (p, n) => S.Ops.extend(p, n, 30));
  check('تمديد: يرفع rev ويكتب سجلًا قبل/بعد', l1.doc.rev === c.doc.rev + 1 && l1.doc.validUntilMs === c.doc.validUntilMs + 30 * DAY && Object.keys((await state()).swm.log).length === 2);
  await S.applyOp(api, c.id, 'suspend', 'x', (p, n) => S.Ops.suspend(p, n, 'تأخر السداد'));
  check('تعليق ينعكس على المستند المقروء بالمفتاح', (() => { return true; })() && S.decode(await (await fetch(`${base}/swm/lic/${c.id}.json`)).json()).active === false);
  await S.applyOp(api, c.id, 'restore', '', (p, n) => S.Ops.restore(p, n));
  const list = await api.listLicenses();
  check('قائمة التراخيص للمطوّر', list.length === 1 && list[0].id === c.id && list[0].doc.active);
  const errBuild = await rejects(S.applyOp(api, c.id, 'suspend', '', (p, n) => S.Ops.suspend(p, n, '')));
  check('خطأ إدخال لا يكتب شيئًا', errBuild && /سبب/.test(errBuild.message) && Object.keys((await state()).swm.log).length === 4);

  console.log('5) الأجهزة والحذف');
  const dev = 'AB12CD34EF56GH78';
  await fetch(`${base}/swm/bind/${c.id}/${dev}.json`, { method: 'PUT', body: JSON.stringify({ t: { '.sv': 'timestamp' }, n: 'Samsung A12' }) });
  check('تسجيل جهاز (من التطبيق) يظهر للمطوّر', Object.keys(await api.readBindings(c.id)).length === 1 && Object.keys((await api.listBindings())[c.id]).includes(dev));
  const again = await fetch(`${base}/swm/bind/${c.id}/${dev}.json`, { method: 'PUT', body: JSON.stringify({ t: { '.sv': 'timestamp' }, n: 'Hacker' }) });
  check('write-once: لا يُعاد تسجيل جهاز ولا يُغيَّر اسمه', again.status === 401 && (await api.readBindings(c.id))[dev].n === 'Samsung A12');
  const noLic = await fetch(`${base}/swm/bind/AAAAAAAAAAAAAAAAAAAA/${dev}.json`, { method: 'PUT', body: JSON.stringify({ t: { '.sv': 'timestamp' }, n: 'x' }) });
  check('لا تسجيل على مفتاح غير موجود', noLic.status === 401);
  await S.removeDevice(api, c.id, dev);
  check('إزالة جهاز بيد المطوّر مع سجل', Object.keys(await api.readBindings(c.id)).length === 0 && (await api.listLogs()).some(l => l.action === 'remove_device'));
  await fetch(`${base}/swm/bind/${c.id}/${dev}.json`, { method: 'PUT', body: JSON.stringify({ t: { '.sv': 'timestamp' }, n: 'again' }) });
  await S.deleteLicense(api, c.id);
  db = await state();
  check('حذف الترخيص يحذف مستنده وأجهزته ويسجّل', !(db.swm.lic || {})[c.id] && !(db.swm.bind || {})[c.id] && Object.values(db.swm.log).some(l => l.action === 'delete'));

  console.log('6) تجديد جلسة منتهية تلقائيًا');
  await fetch(base + '/__expire', { method: 'POST' });
  check('انتهاء الرمز → تجديد صامت ثم نجاح الطلب', (await api.listLicenses()).length === 0 && api.session.cur.idToken !== sDev.idToken);

  console.log('7) سجل التدقيق مرتب');
  const logs = await api.listLogs();
  check('أحدث أولًا', logs.length === 6 && logs.every((l, i) => i === 0 || logs[i - 1].t >= l.t));

  console.log('8) CSV');
  const csv = S.toCsv([{ id: S.newKey(), doc: t1, devices: 1 }], T);
  check('CSV بـ BOM وعناوين عربية', csv.startsWith('\uFEFF') && csv.includes('البمب') && csv.split('\n').length === 2);

  console.log('9) توافق الترميز بين Kotlin وJS');
  const samples = [d0, S.Ops.setMaintenance(S.Ops.suspend({ ...t1, offlineDays: 9, maxDevices: 3, notice: 'سطر\nثانٍ | وفاصل' }, T, 'سبب %'), T, true, 'صيانة')];
  fs.writeFileSync(path.join(pdir, 'parity_js.txt'), samples.map(S.encode).join('\n---\n'));
  const kt = fs.readFileSync(path.join(pdir, 'parity_kt.txt'), 'utf8').split('\n---\n').map(S.decode);
  check('JS يقرأ ما ترمّزه Kotlin بدقة', kt.length === 2 && kt.every(Boolean) && kt[0].org === 'مصباح | النور\n١' && kt[0].maxDevices === 4 && kt[1].active === false && kt[1].reason === 'سبب|' && kt[1].maintMsg === 'صيانة 100%');

  console.log(failures === 0 ? 'اختبارات برنامج المطوّر نجحت' : 'فشل ' + failures + ' اختبار');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error('استثناء غير متوقع:', e); process.exit(2); });
