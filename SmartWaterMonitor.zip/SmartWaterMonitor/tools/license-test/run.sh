#!/bin/bash
# اختبار نظام الترخيص كاملًا: خادم Firebase تجريبي + نواة التطبيق (Kotlin) + برنامج المطوّر (Node) + توافق الترميز.
# الاستخدام: bash run.sh [مسار kotlinc]
set -e
KC="${1:-kotlinc}"
HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$HERE/../../app/src/main/java/com/smartwater/monitor/core"
OUT="$HERE/build"; rm -rf "$OUT"; mkdir -p "$OUT"
PORT=$((20000 + RANDOM % 20000))
echo "تجميع اختبار الترخيص ..."
$KC -nowarn "$CORE"/*.kt "$HERE/LicenseTest.kt" -include-runtime -d "$OUT/lic.jar" 2>&1 | grep -v '^warning' || true
python3 "$HERE/fake_swm.py" $PORT & SRV=$!
trap "kill $SRV 2>/dev/null || true" EXIT
for i in $(seq 1 50); do curl -s "http://127.0.0.1:$PORT/__state" >/dev/null 2>&1 && break; sleep 0.1; done
JA="java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp $OUT/lic.jar LicenseTest"
$JA gen "http://127.0.0.1:$PORT" "$OUT"
echo "=== برنامج المطوّر (Node) ==="
node "$HERE/console_test.js" "http://127.0.0.1:$PORT" "$OUT"
echo "=== نواة الترخيص في التطبيق (Kotlin) ==="
$JA check "http://127.0.0.1:$PORT" "$OUT"
echo "=== واجهة برنامج المطوّر (jsdom) ==="
if [ ! -d "$HERE/node_modules/jsdom" ]; then
  (cd "$HERE" && npm init -y >/dev/null 2>&1; npm i jsdom@24 --silent >/dev/null 2>&1) || true
fi
if [ -d "$HERE/node_modules/jsdom" ]; then
  NODE_PATH="$HERE/node_modules" node "$HERE/ui_test.js" "http://127.0.0.1:$PORT"
else
  echo "تخطّي اختبار الواجهة: تعذّر تثبيت jsdom (لا شبكة)"
fi
