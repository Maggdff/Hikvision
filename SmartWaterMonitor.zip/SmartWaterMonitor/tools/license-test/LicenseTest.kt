import com.smartwater.monitor.core.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * اختبار نواة الترخيص في التطبيق: الترميز، الحكم، المفتاح، ترتيب الأجهزة، الساعة الموثوقة، حالة الجهاز،
 * وجلب/تسجيل الجهاز عبر الشبكة مقابل fake_swm.py. المراحل: gen (يكتب ترميز Kotlin) ثم check (كل الاختبارات + قراءة ترميز JS).
 */
object LicenseTest {
    private var failures = 0
    private fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }
    private const val DAY = LicenseGate.DAY_MS
    private const val T0 = 1_700_000_000_000L

    private fun doc(until: Long = T0 + 100 * DAY, active: Boolean = true, grace: Int = 14, maint: Boolean = false, offline: Int = 0, maxDev: Int = 0,
                    reason: String = "", notice: String = "", org: String = "بمب الأمل") =
        LicenseDoc(1, org, active, T0, until, grace, maint, "", notice, reason, offline, maxDev, T0)

    class Kv : KeyValue {
        val m = HashMap<String, String>()
        override fun get(key: String) = m[key]
        override fun put(key: String, value: String?) { if (value == null) m.remove(key) else m[key] = value }
    }

    // ---------- HTTP صغير لتجهيز الخادم كمطوّر ----------
    private fun req(method: String, url: String, body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val t = (if (code in 200..299) c.inputStream else c.errorStream)?.use { String(it.readBytes()) } ?: ""
        c.disconnect(); return code to t
    }
    private fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    @JvmStatic fun main(a: Array<String>) {
        val phase = a[0]; val pdir = a.getOrElse(2) { "." }
        if (phase == "gen") {
            val d1 = LicenseDoc(7, "مصباح | النور\n١", true, T0, T0 + 30 * DAY, 14, false, "", "", "", 0, 4, T0)
            val d2 = LicenseDoc(9, "بمب", false, T0, 0, 0, true, "صيانة 100%", "", "سبب|", 3, 0, T0)
            File(pdir, "parity_kt.txt").writeText(LicenseCodec.encode(d1) + "\n---\n" + LicenseCodec.encode(d2))
            println("كُتب parity_kt.txt"); return
        }
        val base = a[1]

        println("1) الترميز")
        val d = doc(org = "بمب | الأمل\nالفرع %1", reason = "سبب|", notice = "سطر\nثانٍ", offline = 9, maxDev = 3)
        check("ذهاب وإياب مع | وسطر جديد و%", LicenseCodec.decode(LicenseCodec.encode(d)) == d)
        val raw = LicenseCodec.encode(d)
        check("نصوص تالفة → null", listOf(null, "", "UAL1|1|x|A|0|0|14|0|||0|0|0", raw.replace("SWL1", "X"), "$raw|1", raw.replace("|A|", "|Z|"),
            raw.replace("%7C", "%ZZ"), raw.replace("|1|", "|-1|"), raw.replace("|1|", "|+1|"), raw.replace("|1|", "|1.0|"), raw.replace("|1|", "||")).all { LicenseCodec.decode(it) == null })

        println("2) الحكم على الترخيص")
        fun v(dc: LicenseDoc?, now: Long, last: Long = now, dev: Boolean = true, rev: Boolean = false) = LicenseGate.evaluate(dc, now, last, dev, rev)
        check("بلا مستند → غير مفعّل ومحجوب", v(null, T0).let { it.status == LicenseStatus.NOT_ACTIVATED && it.blocked })
        check("فعّال بعيد: لا تنبيه", v(doc(), T0).let { it.status == LicenseStatus.ACTIVE && !it.blocked && it.banner.isEmpty() && it.daysLeft == 100L })
        check("قرب الانتهاء: تنبيه بالأيام", v(doc(), T0 + 90 * DAY + 1).let { it.status == LicenseStatus.ACTIVE && it.banner.contains("10") })
        check("فترة السماح: يعمل مع تنبيه", v(doc(), T0 + 105 * DAY).let { it.status == LicenseStatus.GRACE && !it.blocked && it.banner.isNotEmpty() && it.daysLeft == 9L })
        check("بعد السماح: منتهٍ ومحجوب", v(doc(), T0 + 115 * DAY).let { it.status == LicenseStatus.EXPIRED && it.blocked })
        check("بلا نهاية لا ينتهي أبدًا", v(doc(until = 0), T0 + 5000 * DAY).status == LicenseStatus.ACTIVE)
        check("معلّق مع السبب", v(doc(active = false, reason = "تأخر السداد"), T0).let { it.status == LicenseStatus.SUSPENDED && it.blocked && it.message.contains("تأخر السداد") })
        check("صيانة بالرسالة الافتراضية", v(doc(maint = true), T0).let { it.status == LicenseStatus.MAINTENANCE && it.blocked && it.message.contains("الصيانة") })
        check("حد بلا اتصال", v(doc(offline = 7), T0 + 8 * DAY, last = T0).status == LicenseStatus.OFFLINE_LIMIT && v(doc(offline = 7), T0 + 6 * DAY, last = T0).status == LicenseStatus.ACTIVE)
        check("تجاوز الأجهزة", v(doc(maxDev = 2), T0, dev = false).let { it.status == LicenseStatus.DEVICE_LIMIT && it.blocked })
        check("ملغى من الخادم", v(doc(), T0, rev = true).let { it.status == LicenseStatus.REVOKED && it.blocked })
        check("الأولوية: التعليق ثم الانتهاء ثم الأجهزة ثم الصيانة",
            v(doc(active = false, until = T0 - 99 * DAY), T0).status == LicenseStatus.SUSPENDED && v(doc(until = T0 - 99 * DAY, maint = true), T0).status == LicenseStatus.EXPIRED
                && v(doc(maint = true), T0, dev = false).status == LicenseStatus.DEVICE_LIMIT && v(doc(maint = true, offline = 1), T0 + 3 * DAY, T0).status == LicenseStatus.MAINTENANCE)
        check("الرسالة تظهر دون إيقاف", v(doc(notice = "تجديد قريب"), T0).let { it.banner.contains("تجديد قريب") && !it.blocked })
        check("رسالة المحجوب تطمئن أن السجلات محفوظة", v(doc(active = false), T0).message.contains("محفوظة"))

        println("3) مفتاح التفعيل")
        check("تطبيع (شرطات/مسافات/حالة) والرفض", LicenseKey.normalize("abcd-efgh-ij23-4567-abcd") == "ABCDEFGHIJ234567ABCD" && LicenseKey.normalize(" ABCDEFGHIJ234567ABCD ") != null
            && LicenseKey.normalize("ABCDEFGHIJ234567ABC") == null && LicenseKey.normalize("ABCDEFGHIJ234567ABC1") == null && LicenseKey.normalize(null) == null)
        check("التنسيق XXXX-XXXX-...", LicenseKey.format("ABCDEFGHIJ234567ABCD") == "ABCD-EFGH-IJ23-4567-ABCD")

        println("4) ترتيب الأجهزة")
        val e = listOf(DeviceRank.Entry("C", 30), DeviceRank.Entry("A", 10), DeviceRank.Entry("B", 20))
        check("الأقدم تسجيلًا هو المسموح ضمن الحد", DeviceRank.allowed("A", e, 2) && DeviceRank.allowed("B", e, 2) && !DeviceRank.allowed("C", e, 2))
        check("بلا حد = الكل، وغير المسجَّل مرفوض", DeviceRank.allowed("C", e, 0) && !DeviceRank.allowed("Z", e, 0))
        check("تساوي الوقت يُحسم بالمعرّف (ثابت)", DeviceRank.allowed("A", listOf(DeviceRank.Entry("B", 5), DeviceRank.Entry("A", 5)), 1) && !DeviceRank.allowed("B", listOf(DeviceRank.Entry("B", 5), DeviceRank.Entry("A", 5)), 1))

        println("5) حالة الجهاز والساعة الموثوقة")
        run {
            val kv = Kv(); var wall = T0; var mono = 1000L; var boot = "b1"
            val k = LicenseKeeper(kv, { wall }, { mono }, { boot })
            check("لا مفتاح: مطلوب → غير مفعّل، وغير مطلوب → UNMANAGED", k.verdict(true).status == LicenseStatus.NOT_ACTIVATED && k.verdict(false).status == LicenseStatus.UNMANAGED)
            k.setLicenseId("ABCDEFGHIJ234567ABCD")
            k.onFetched(LicenseCodec.encode(doc(until = T0 + 30 * DAY, offline = 7)), T0, true)
            check("بعد الجلب: فعّال", k.verdict().status == LicenseStatus.ACTIVE)
            wall += 400 * DAY
            check("تقديم ساعة الهاتف 400 يوم لا يُنهي الترخيص (ساعة الخادم الموثوقة)", k.verdict().status == LicenseStatus.ACTIVE)
            wall = T0 - 400 * DAY
            check("وتأخيرها لا يطيله", k.nowMs() in T0 until T0 + DAY)
            wall = T0; mono += 20 * DAY
            check("مرور الوقت الحقيقي (عدّاد رتيب) يُحتسب", k.nowMs() == T0 + 20 * DAY)
            mono += 8 * DAY
            check("حد 7 أيام بلا اتصال يحجب", k.verdict().status == LicenseStatus.OFFLINE_LIMIT)
            k.onFetched(LicenseCodec.encode(doc(until = T0 + 30 * DAY, offline = 7)), T0 + 28 * DAY, true)
            check("اتصال جديد يعيد العمل", k.verdict().status == LicenseStatus.ACTIVE)
            mono += 3 * DAY
            check("بعد 3 أيام أخرى: يتجاوز النهاية فيدخل السماح", k.verdict().status == LicenseStatus.GRACE)
            // إعادة تشغيل الهاتف: الساعة الرتيبة تبدأ من جديد
            boot = "b2"; mono = 50L; wall = T0 - 400 * DAY
            check("بعد إعادة التشغيل بلا اتصال لا يُسمح بالرجوع بالزمن (آخر وقت خادم محفوظ)", k.nowMs() >= T0 + 28 * DAY)
            val k2 = LicenseKeeper(kv, { wall }, { mono }, { boot })
            check("يُستعاد الحكم من التخزين بعد إغلاق التطبيق", k2.licenseId() == "ABCDEFGHIJ234567ABCD" && k2.doc() != null)
            k2.onFetched("نص تالف", T0 + 29 * DAY)
            check("نص تالف على الخادم لا يستبدل المحفوظ ولا يوقف أحدًا", k2.doc() != null && !k2.revoked())
            k2.onFetched(null, T0 + 29 * DAY)
            check("اختفاء المستند من الخادم = ملغى", k2.verdict().status == LicenseStatus.REVOKED)
            k2.onFetched(LicenseCodec.encode(doc()), T0 + 30 * DAY, true)
            check("عودة المستند تلغي الإلغاء", k2.verdict().status == LicenseStatus.ACTIVE)
            k2.onFetched(LicenseCodec.encode(doc(maxDev = 1)), T0 + 30 * DAY, false)
            check("تجاوز الأجهزة يُحفظ ويحجب", k2.verdict().status == LicenseStatus.DEVICE_LIMIT)
            k2.setLicenseId("ZZZZZZZZZZ234567ABCD")
            check("تغيير المفتاح يمحو حالة السابق", k2.doc() == null && !k2.revoked() && k2.deviceOk() && k2.verdict().status == LicenseStatus.NOT_ACTIVATED)
        }

        println("6) JSON الصغير")
        check("كائنات/مصفوفات/نصوص مهرَّبة/أرقام", (MiniJson.parse("""{"a":{"t":1700000000123,"n":"x\"y\u0645"},"b":[1,2.5,true,null]}""") as Map<*, *>).let {
            ((it["a"] as Map<*, *>)["t"] as Long) == 1700000000123L && (it["a"] as Map<*, *>)["n"] == "x\"yم" && (it["b"] as List<*>)[1] == 2.5 } && MiniJson.parse("null") == null && MiniJson.parse("\"s\"") == "s")
        check("نص تالف يرمي ParseException", listOf("{", "{\"a\"}", "[1,", "\"x", "tru", "{} x").all { try { MiniJson.parse(it); false } catch (e: MiniJson.ParseException) { true } })

        println("7) الجلب والتسجيل عبر الشبكة (خادم تجريبي بقواعد الترخيص)")
        val tok = MiniJson.parse(req("POST", "$base/v1/accounts:signInWithPassword?key=TESTKEY", """{"email":"dev@example.com","password":"pass1234","returnSecureToken":true}""").second).let { (it as Map<*, *>)["idToken"] as String }
        val real = System.currentTimeMillis()
        fun ld(active: Boolean = true, maxDev: Int = 0, reason: String = "") = doc(until = real + 100 * DAY, active = active, maxDev = maxDev, reason = reason)
        fun putLic(id: String, d: LicenseDoc?) = req("PUT", "$base/swm/lic/$id.json?auth=$tok", if (d == null) "null" else q(LicenseCodec.encode(d)))
        fun delDev(id: String, dev: String) = req("DELETE", "$base/swm/bind/$id/$dev.json?auth=$tok")
        val id1 = "ABCDEFGHIJ234567AAAA"; val devA = "AAAAAAAAAAAAAAAA"; val devB = "BBBBBBBBBBBBBBBB"
        fun sync(id: String, dev: String, b: String = base) = LicenseApi.sync(b, id, dev, "Samsung A12 \"x\"")
        fun ok(r: LicenseApi.Result) = (r as? LicenseApi.Result.Ok)?.sync

        check("مفتاح غير موجود → مستند null (لا خطأ)", ok(sync("ZZZZZZZZZZZZZZZZZZZZ", devA))?.let { it.raw == null } == true)
        check("مفتاح بصيغة خاطئة → خطأ", sync("abc", devA) is LicenseApi.Result.Error && sync(id1, "x") is LicenseApi.Result.Error)
        check("عنوان غير صالح → خطأ", sync(id1, devA, "ftp://x") is LicenseApi.Result.Error)
        check("لا خادم → بلا اتصال (لا خطأ)", sync(id1, devA, "http://127.0.0.1:1") is LicenseApi.Result.Offline)

        check("تجهيز ترخيص بجهاز واحد", putLic(id1, ld(maxDev = 1)).first == 200)
        val a1 = ok(sync(id1, devA))
        check("الجهاز الأول: مستند + مسجَّل + ضمن الحد + وقت الخادم", a1 != null && a1.raw != null && a1.registered && a1.deviceOk && Math.abs(a1.serverMs - System.currentTimeMillis()) < 5000)
        val b1 = ok(sync(id1, devB))
        check("الجهاز الثاني يتجاوز الحد (الأقدم تسجيلًا هو المسموح)", b1 != null && b1.registered && !b1.deviceOk)
        check("الأول يبقى مسموحًا بعد دخول الثاني", ok(sync(id1, devA))?.deviceOk == true)
        check("تكرار المزامنة لا يعيد التسجيل ولا يغيّر الترتيب", ok(sync(id1, devB))?.deviceOk == false)
        check("إزالة المطوّر للجهاز الأول تُفسح للثاني", delDev(id1, devA).first == 200 && ok(sync(id1, devB))?.deviceOk == true)
        putLic(id1, ld(maxDev = 0))
        check("بلا حد: الكل مسموح", ok(sync(id1, devA))?.deviceOk == true && ok(sync(id1, devB))?.deviceOk == true)

        // نتيجة الشبكة تغذّي حالة الجهاز
        val kv = Kv(); val k = LicenseKeeper(kv, mono = { 1L })
        k.setLicenseId(id1)
        ok(sync(id1, devA))!!.let { k.onFetched(it.raw, it.serverMs, it.deviceOk) }
        check("الجهاز يحكم من نتيجة الشبكة: فعّال", k.verdict().status == LicenseStatus.ACTIVE)
        putLic(id1, ld(active = false, reason = "تأخر السداد"))
        ok(sync(id1, devA))!!.let { k.onFetched(it.raw, it.serverMs, it.deviceOk) }
        check("تعليق المطوّر يصل الجهاز عند أول مزامنة", k.verdict().let { it.status == LicenseStatus.SUSPENDED && it.message.contains("تأخر السداد") })
        putLic(id1, null)
        ok(sync(id1, devA))!!.let { k.onFetched(it.raw, it.serverMs, it.deviceOk) }
        check("حذف الترخيص يُلغيه على الجهاز", k.verdict().status == LicenseStatus.REVOKED)

        println("8) توافق الترميز بين Kotlin وJS")
        val js = File(pdir, "parity_js.txt").readText().split("\n---\n").map { LicenseCodec.decode(it) }
        check("Kotlin يقرأ ما يرمّزه JS بدقة", js.size == 2 && js.all { it != null } &&
            js[0]!!.org == "بمب | الأمل\nالفرع %1" && js[0]!!.active && js[0]!!.graceDays == 14 && js[0]!!.validUntilMs > js[0]!!.startMs &&
            !js[1]!!.active && js[1]!!.reason == "سبب %" && js[1]!!.maintenance && js[1]!!.maintMsg == "صيانة" && js[1]!!.offlineDays == 9 && js[1]!!.maxDevices == 3 && js[1]!!.notice == "سطر\nثانٍ | وفاصل")

        println(if (failures == 0) "اختبارات نواة الترخيص نجحت" else "فشل $failures اختبار")
        if (failures > 0) System.exit(1)
    }
}
