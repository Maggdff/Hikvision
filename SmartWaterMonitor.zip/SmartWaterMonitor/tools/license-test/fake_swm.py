# خادم اختبار يحاكي Firebase Authentication (REST) + Realtime Database بقواعد ترخيص البمبات (devconsole/firebase-rules.json).
# ليس Firebase الحقيقي: نموذج مبسّط للقواعد للتحقق من منطق التطبيق وبرنامج المطوّر (الكتابة الذرّية، write-once، append-only...).
# الاستخدام: python3 fake_swm.py PORT [skewMs]   — dev@example.com / pass1234 (uid=UID_DEV ضمن devAdmins)،
# other@example.com / pass1234 (uid=UID_OTHER ليس مطوّرًا).   مفتاح الـAPI: TESTKEY
import json, sys, time, uuid, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

PORT = int(sys.argv[1]); SKEW = int(sys.argv[2]) if len(sys.argv) > 2 else 0
API_KEY = 'TESTKEY'
USERS = {'dev@example.com': ('pass1234', 'UID_DEV'), 'other@example.com': ('pass1234', 'UID_OTHER')}
db = {'devAdmins': {'UID_DEV': True}}
tokens, refresh, expired = {}, {}, set()
def now_ms(): return int(time.time() * 1000) + SKEW

def get_path(p):
    cur = db
    for k in [x for x in p.split('/') if x]:
        if not isinstance(cur, dict) or k not in cur: return None
        cur = cur[k]
    return cur
def set_path(p, v):
    ks = [x for x in p.split('/') if x]
    cur = db
    for k in ks[:-1]:
        if not isinstance(cur.get(k), dict): cur[k] = {}
        cur = cur[k]
    if v is None: cur.pop(ks[-1], None)
    else: cur[ks[-1]] = v
    # Firebase يحذف العقد الفارغة
    for i in range(len(ks) - 1, 0, -1):
        n = get_path('/'.join(ks[:i]))
        if isinstance(n, dict) and not n:
            parent = get_path('/'.join(ks[:i - 1])) if i > 1 else db
            parent.pop(ks[i - 1], None)
def resolve_sv(v):
    if isinstance(v, dict):
        if v == {'.sv': 'timestamp'}: return now_ms()
        return {k: resolve_sv(x) for k, x in v.items()}
    return v

def is_dev(uid): return uid is not None and get_path('devAdmins/' + uid) is True
LID = re.compile(r'^[A-Z2-7]{20}$'); DEV = re.compile(r'^[A-Z0-9]{8,32}$')

def can_read(path, uid):
    p = path.strip('/'); parts = p.split('/') if p else []
    if p.startswith('devAdmins/'): return uid is not None and parts[1] == uid
    if not parts or parts[0] != 'swm': return False
    if len(parts) == 2 and parts[1] in ('lic', 'bind', 'log'): return is_dev(uid)          # السرد للمطوّر فقط
    if len(parts) >= 3 and parts[1] in ('lic', 'bind'): return True                         # بالمفتاح فقط
    if len(parts) >= 2 and parts[1] in ('ping', 'log'): return is_dev(uid)
    return False

def check_write(path, value, uid):
    p = path.strip('/'); parts = p.split('/')
    if parts[0] != 'swm' or len(parts) < 2: return 'Permission denied'
    kind = parts[1]
    if kind == 'lic' and len(parts) == 3:
        if not is_dev(uid): return 'Permission denied'
        if value is not None and not (isinstance(value, str) and value.startswith('SWL1|') and len(value) < 1500): return 'validation failed'
        return None
    if kind == 'bind' and len(parts) == 3:                         # حذف كل أجهزة ترخيص: للمطوّر
        return None if (is_dev(uid) and value is None) else 'Permission denied'
    if kind == 'bind' and len(parts) == 4:
        lid, dev = parts[2], parts[3]
        if value is None: return None if is_dev(uid) else 'Permission denied'
        if not is_dev(uid):
            if get_path(p) is not None: return 'Permission denied'                      # write-once
            if get_path('swm/lic/' + lid) is None: return 'Permission denied'           # لا تسجيل على مفتاح غير موجود
        v = resolve_sv(value)
        if not DEV.match(dev): return 'validation failed'
        if not isinstance(v, dict) or 't' not in v or 'n' not in v or not isinstance(v['n'], str) or len(v['n']) >= 60: return 'validation failed'
        if abs(v['t'] - now_ms()) > 5000: return 'validation failed'
        return None
    if kind == 'ping' and len(parts) == 3:
        if not is_dev(uid) or parts[2] != uid: return 'Permission denied'
        v = resolve_sv(value)
        if not isinstance(v, dict) or abs(v.get('t', 0) - now_ms()) > 5000: return 'validation failed'
        return None
    if kind == 'log' and len(parts) == 3:
        if not is_dev(uid): return 'Permission denied'
        if get_path(p) is not None or value is None: return 'Permission denied'        # append-only
        v = resolve_sv(value)
        if not isinstance(v, dict) or not all(k in v for k in ('t', 'uid', 'action')) or v['uid'] != uid: return 'validation failed'
        if abs(v['t'] - now_ms()) > 5000: return 'validation failed'
        return None
    return 'Permission denied'

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ctype='application/json'):
        b = body.encode('utf-8')
        self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b)))
        self.send_header('Date', time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(now_ms() / 1000)))
        self.end_headers(); self.wfile.write(b)
    def _body(self):
        n = int(self.headers.get('Content-Length', 0)); return self.rfile.read(n).decode('utf-8') if n else ''
    def _auth(self, q):
        t = (q.get('auth') or [None])[0]
        if t is None: return None, None
        if t in expired: return 'EXPIRED', None
        return (None, tokens[t][0]) if t in tokens else ('BAD', None)

    def do_POST(self):
        u = urlparse(self.path); q = parse_qs(u.query); path = u.path
        if path == '/v1/accounts:signInWithPassword':
            if (q.get('key') or [''])[0] != API_KEY: return self._send(400, json.dumps({'error': {'message': 'API key not valid'}}))
            j = json.loads(self._body()); e = j.get('email'); pw = j.get('password')
            if e not in USERS or USERS[e][0] != pw: return self._send(400, json.dumps({'error': {'message': 'INVALID_LOGIN_CREDENTIALS'}}))
            uid = USERS[e][1]; t = 'idt-' + uuid.uuid4().hex; r = 'rft-' + uuid.uuid4().hex
            tokens[t] = (uid, e); refresh[r] = (uid, e)
            return self._send(200, json.dumps({'idToken': t, 'refreshToken': r, 'localId': uid, 'email': e, 'expiresIn': '3600'}))
        if path == '/v1/token':
            f = parse_qs(self._body()); r = (f.get('refresh_token') or [''])[0]
            if r not in refresh: return self._send(400, json.dumps({'error': {'message': 'INVALID_REFRESH_TOKEN'}}))
            uid, e = refresh[r]; t = 'idt-' + uuid.uuid4().hex; tokens[t] = (uid, e)
            return self._send(200, json.dumps({'id_token': t, 'refresh_token': r, 'user_id': uid, 'expires_in': '3600'}))
        if path == '/__expire': expired.update(tokens.keys()); return self._send(200, '{}')
        if path == '/__state': return self._send(200, json.dumps(db))
        m = self.headers.get('X-HTTP-Method-Override') or (q.get('x-http-method-override') or [''])[0]
        if m: return self._rtdb(m.upper(), u, q)
        return self._send(400, '{"error":"unsupported"}')
    def do_GET(self):
        u = urlparse(self.path)
        if u.path == '/__state': return self._send(200, json.dumps(db))
        self._rtdb('GET', u, parse_qs(u.query))
    def do_PUT(self): u = urlparse(self.path); self._rtdb('PUT', u, parse_qs(u.query))
    def do_PATCH(self): u = urlparse(self.path); self._rtdb('PATCH', u, parse_qs(u.query))
    def do_DELETE(self): u = urlparse(self.path); self._rtdb('DELETE', u, parse_qs(u.query))

    def _rtdb(self, method, u, q):
        if not u.path.endswith('.json'): return self._send(404, '{}')
        path = unquote(u.path[1:-5]); err, uid = self._auth(q)
        if err == 'EXPIRED': return self._send(401, json.dumps({'error': 'Auth token is expired'}))
        if err == 'BAD': return self._send(401, json.dumps({'error': 'Invalid token in path'}))
        if method == 'GET':
            if not can_read(path, uid): return self._send(401, json.dumps({'error': 'Permission denied'}))
            v = get_path(path)
            if isinstance(v, dict) and (q.get('orderBy') or [None])[0]:
                key = json.loads(q['orderBy'][0]); lim = int((q.get('limitToLast') or ['1000'])[0])
                items = sorted(v.items(), key=lambda kv: (kv[1].get(key) if isinstance(kv[1], dict) else 0) or 0)[-lim:]
                v = dict(items)
            return self._send(200, json.dumps(v))
        body = self._body(); val = json.loads(body) if body else None
        if method == 'PATCH':
            changes = {(path.strip('/') + '/' + k if path.strip('/') else k): x for k, x in val.items()}
            for p, x in changes.items():             # كل المسارات أو لا شيء
                r = check_write(p, x, uid)
                if r: return self._send(401 if r == 'Permission denied' else 400, json.dumps({'error': r}))
            for p, x in changes.items(): set_path(p, resolve_sv(x))
            return self._send(200, json.dumps(val))
        if method in ('PUT', 'DELETE'):
            v = None if method == 'DELETE' else val
            r = check_write(path, v, uid)
            if r: return self._send(401 if r == 'Permission denied' else 400, json.dumps({'error': r}))
            rv = resolve_sv(v)
            set_path(path, rv); return self._send(200, json.dumps(rv))      # Firebase يعيد القيمة المكتوبة بعد حلّ .sv
        self._send(405, '{}')

ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
