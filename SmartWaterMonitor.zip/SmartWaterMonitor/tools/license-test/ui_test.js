// اختبار واجهة برنامج المطوّر في بيئة متصفح محاكاة (jsdom) مقابل fake_swm.py: يضغط الأزرار فعليًا ويملأ النوافذ.
// الاستخدام: NODE_PATH=<مجلد node_modules> node ui_test.js http://127.0.0.1:PORT
const fs = require('fs'), path = require('path');
const { JSDOM } = require('jsdom');
const base = process.argv[2];
const html = fs.readFileSync(path.join(__dirname, '../../devconsole/swm-license-console.html'), 'utf8');
let failures = 0;
const check = (name, ok, detail = '') => { console.log((ok ? '  نجح  ' : '  فشل  ') + name + (detail ? '  -> ' + detail : '')); if (!ok) failures++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const state = async () => (await fetch(base + '/__state')).json();

(async () => {
  const errors = [];
  const dom = new JSDOM(html, {
    url: 'http://localhost/', runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(w) {
      // fetch الحقيقي مع إعادة توجيه خوادم Google (المصادقة) إلى الخادم التجريبي
      w.fetch = (u, o) => fetch(String(u).replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, base), o);
      if (!w.crypto || !w.crypto.getRandomValues) w.crypto = require('crypto').webcrypto;
      // <dialog>: jsdom لا ينفّذ showModal/close
      w.HTMLElement.prototype.showModal = function () { this.setAttribute('open', ''); };
      w.HTMLElement.prototype.close = function (rv) { if (rv !== undefined) this.returnValue = rv; this.removeAttribute('open'); this.dispatchEvent(new w.Event('close')); };
      w.addEventListener('error', e => errors.push('window.onerror: ' + e.message));
      w.addEventListener('unhandledrejection', e => errors.push('unhandledrejection: ' + e.reason));
    }
  });
  const w = dom.window, d = w.document;
  // أزرار نماذج method=dialog تُغلق النافذة بقيمة الزر
  d.addEventListener('click', e => { const b = e.target.closest && e.target.closest('dialog form button'); if (b) { e.preventDefault(); b.closest('dialog').close(b.value); } }, true);
  const $ = s => d.querySelector(s), $$ = s => [...d.querySelectorAll(s)];
  const waitFor = async (fn, t = 4000) => { const t0 = Date.now(); while (Date.now() - t0 < t) { try { const v = fn(); if (v) return v; } catch (_) {} await sleep(30); } return null; };
  const click = el => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
  const fill = (root, name, v) => { const el = root.querySelector(`[name="${name}"]`); el.value = v; };
  const topDialog = () => $$('dialog[open]').pop();
  const okDialog = async (vals) => { const dlg = await waitFor(topDialog); for (const [k, v] of Object.entries(vals || {})) fill(dlg, k, v); click(dlg.querySelector('button[value="ok"]')); await sleep(60); };
  const licState = async () => { const db = await state(); return db.swm && db.swm.lic ? Object.entries(db.swm.lic) : []; };

  console.log('1) تسجيل الدخول');
  await waitFor(() => $('#go'));
  check('تظهر شاشة الدخول بالعنوان الافتراضي لقاعدة الترخيص', $('#db').value.includes('firebasedatabase.app'));
  $('#db').value = base; $('#key').value = 'WRONG'; $('#em').value = 'dev@example.com'; $('#pw').value = 'pass1234';
  click($('#go'));
  check('مفتاح API خاطئ → رسالة عربية في الإشعار', !!(await waitFor(() => /مفتاح Firebase غير صحيح/.test($('#toast').textContent))));
  $('#key').value = 'TESTKEY'; $('#em').value = 'other@example.com';
  click($('#go'));
  check('حساب ليس مطوّرًا → يرجع للدخول برسالة', !!(await waitFor(() => /devAdmins/.test($('#app').textContent) && $('#go'))));
  $('#db').value = base; $('#key').value = 'TESTKEY'; $('#em').value = 'dev@example.com'; $('#pw').value = 'pass1234'; $('#rem').checked = true;
  click($('#go'));
  check('دخول المطوّر: تبويب العملاء (0)', !!(await waitFor(() => /العملاء \(0\)/.test($('#app').textContent))) && $('#who').textContent === 'dev@example.com');
  check('تُحفظ إعدادات الدخول محليًا (رمز التجديد لا كلمة المرور)', w.localStorage.getItem('swm_rt') && !JSON.stringify(w.localStorage).includes('pass1234'));

  console.log('2) إنشاء ترخيص');
  click($('#new'));
  await okDialog({ org: 'بمب النور', days: '365', grace: '14', off: '30', dev: '2', notice: 'أهلًا بك' });
  const detail1 = await waitFor(() => $$('dialog[open]').find(x => /أرسل المفتاح/.test(x.textContent)));
  check('يظهر المفتاح الجديد مع تعليمات الإرسال', !!detail1);
  const key = detail1 && detail1.querySelector('.key').textContent.trim();
  check('المفتاح بصيغة XXXX-XXXX-XXXX-XXXX-XXXX', /^[A-Z2-7]{4}(-[A-Z2-7]{4}){4}$/.test(key || ''), key);
  let lics = await licState(); const id = lics[0] && lics[0][0];
  check('خُزّن على الخادم بنفس المفتاح', lics.length === 1 && id === (key || '').replace(/-/g, ''));
  click(detail1.querySelector('#x'));
  check('البطاقة تظهر بالاسم والحالة «فعّال»', !!(await waitFor(() => $$('.lic').length === 1 && /بمب النور/.test($('.lic').textContent) && /فعّال/.test($('.lic').textContent))));

  console.log('3) إدارة الترخيص من نافذة التفاصيل');
  const open = async () => { click($('.lic')); return await waitFor(() => $$('dialog[open]').find(x => x.querySelector('[data-a]'))); };
  const act = async (a, vals) => { const dlg = await open(); click(dlg.querySelector(`[data-a="${a}"]`)); if (vals !== null) await okDialog(vals); await waitFor(() => !$$('dialog[open]').length); await sleep(250); };
  const cur = async () => { const raw = (await licState())[0][1]; return raw.split('|'); };
  const rev0 = Number((await cur())[1]);
  await act('extend', { n: '30' });
  check('تمديد 30 يومًا: يرتفع الرقم', Number((await cur())[1]) === rev0 + 1 && Number((await cur())[5]) > 0);
  await act('suspend', { r: 'تأخر السداد' });
  check('تعليق بالسبب → الحالة «معلّق»', (await cur())[3] === 'S' && (await cur())[10] === decodeURIComponent('%D8%AA%D8%A3%D8%AE%D8%B1 %D8%A7%D9%84%D8%B3%D8%AF%D8%A7%D8%AF'.replace(/%20/g, ' ')) && /معلّق/.test($('.lic').textContent));
  await act('restore', null);
  check('استعادة → فعّال', (await cur())[3] === 'A' && /فعّال/.test($('.lic').textContent));
  await act('maint', { m: 'صيانة قصيرة' });
  check('وضع الصيانة بالرسالة', (await cur())[7] === '1' && /صيانة/.test($('.lic').textContent));
  await act('maint', null);
  check('إنهاء الصيانة', (await cur())[7] === '0');
  await act('maxd', { n: '5' }); check('عدد الأجهزة 5', (await cur())[12] === '5');
  await act('off', { n: '7' }); check('حد الاتصال 7 أيام', (await cur())[11] === '7');
  await act('grace', { n: '3' }); check('سماح 3 أيام', (await cur())[6] === '3');
  await act('notice', { m: 'جدّد قريبًا' }); check('رسالة للمستخدم', (await cur())[9] === 'جدّد قريبًا');
  await act('name', { n: 'بمب النور الجديد' }); check('تغيير الاسم', (await cur())[2] === 'بمب النور الجديد' && /الجديد/.test($('.lic').textContent));
  const bad = async () => { const dlg = await open(); click(dlg.querySelector('[data-a="extend"]')); await okDialog({ n: '0' }); await sleep(300); };
  await bad();
  check('إدخال خاطئ (تمديد 0) → رسالة خطأ ولا تعديل', /التمديد/.test($('#toast').textContent) && Number((await cur())[1]) >= rev0 + 9);
  await waitFor(() => !$$('dialog[open]').length);

  console.log('4) الأجهزة');
  await fetch(`${base}/swm/bind/${id}/AB12CD34EF56GH78.json`, { method: 'PUT', body: JSON.stringify({ t: { '.sv': 'timestamp' }, n: 'Samsung A12' }) });
  click($('#rl')); await sleep(300);
  check('العدّاد يظهر في البطاقة (1 / 5)', /الأجهزة: 1 \/ 5/.test($('.lic').textContent));
  let dlg = await open();
  check('الجهاز يظهر في التفاصيل باسمه', /Samsung A12/.test(dlg.textContent));
  click(dlg.querySelector('[data-dev]'));
  check('إزالة الجهاز', !!(await waitFor(() => $$('dialog[open]').some(x => /لم يُفعَّل على أي جهاز/.test(x.textContent)))));
  click($$('dialog[open]').pop().querySelector('#x'));

  console.log('5) البحث والتصفية');
  $('#q').value = 'غير موجود'; $('#q').dispatchEvent(new w.Event('input'));
  check('بحث بلا نتائج', /لا نتائج/.test($('#list').textContent));
  $('#q').value = ''; $('#q').dispatchEvent(new w.Event('input'));
  $('#flt').value = 'SUSPENDED'; $('#flt').dispatchEvent(new w.Event('change'));
  check('تصفية «معلّق» تُخفي الفعّال', /لا نتائج/.test($('#list').textContent));
  $('#flt').value = ''; $('#flt').dispatchEvent(new w.Event('change'));

  console.log('6) أمان العرض (لا حقن HTML)');
  click($('#new'));
  await okDialog({ org: '<img src=x onerror="window.__xss=1">بمب', days: '10' });
  await waitFor(() => $$('dialog[open]').find(x => /أرسل المفتاح/.test(x.textContent)));
  const dx = $$('dialog[open]').pop(); click(dx.querySelector('#x')); await sleep(200);
  check('الاسم الخبيث يُعرض نصًا ولا يُنفَّذ', !w.__xss && !$('#app img') && $$('.lic').some(c => c.textContent.includes('<img src=x')));

  console.log('7) الحذف وسجل التدقيق');
  const target = $$('.lic').find(c => /بمب النور الجديد/.test(c.textContent)); click(target);
  dlg = await waitFor(() => $$('dialog[open]').find(x => x.querySelector('#del')));
  click(dlg.querySelector('#del'));
  await okDialog({});
  await sleep(400);
  lics = await licState();
  check('حذف الترخيص المحدد فقط', lics.length === 1 && !lics.some(([, r]) => r.includes('بمب النور الجديد')));
  click($('.tabs [data-t="log"]'));
  check('سجل التدقيق يعرض العمليات', !!(await waitFor(() => $$('#pane .card').length >= 12)), String($$('#pane .card').length));
  check('السجل يتضمن إنشاء وتمديدًا وتعليقًا وحذفًا', ['create', 'extend', 'suspend', 'restore', 'delete', 'remove_device'].every(a => $('#pane').textContent.includes(a)));

  console.log('8) خروج');
  click($('#btnOut'));
  check('الخروج يمسح الرمز المحفوظ ويرجع للدخول', !!(await waitFor(() => $('#go'))) && !w.localStorage.getItem('swm_rt'));

  check('لا أخطاء غير معالَجة في الصفحة', errors.length === 0, errors.join(' | '));
  console.log(failures === 0 ? 'اختبار واجهة برنامج المطوّر نجح' : 'فشل ' + failures + ' اختبار');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error('استثناء غير متوقع:', e); process.exit(2); });
