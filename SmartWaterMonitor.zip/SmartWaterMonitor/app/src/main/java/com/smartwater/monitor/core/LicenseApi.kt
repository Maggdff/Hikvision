package com.smartwater.monitor.core

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * جلب الترخيص وتسجيل الجهاز من Firebase Realtime Database عبر REST (بلا SDK ولا google-services).
 *  - `swm/lic/<مفتاح>`: مستند الترخيص (قراءة بالمفتاح فقط).
 *  - `swm/bind/<مفتاح>/<جهاز>`: تسجيل الجهاز (يُكتب مرة واحدة؛ ختم الزمن من الخادم). الأقدم تسجيلًا هو المسموح ضمن maxDevices.
 * وقت الخادم من ترويسة Date فلا حاجة لصلاحية كتابة. أي خطأ لا يغيّر الحكم المحفوظ: التطبيق يكمل بآخر حكم معروف.
 */
object LicenseApi {
    const val ROOT = "swm"

    class SyncResult(val raw: String?, val serverMs: Long, val deviceOk: Boolean, val registered: Boolean)

    sealed class Result {
        class Ok(val sync: SyncResult) : Result()
        object Offline : Result()
        class Error(val msg: String) : Result()
    }

    private class Resp(val code: Int, val body: String, val dateMs: Long)

    /** خطأ HTTP من الخادم (ليس انقطاع شبكة): لا يُصنَّف «بلا اتصال». */
    private class ApiError(msg: String) : RuntimeException(msg)

    private fun http(method: String, url: String, body: String?, timeoutMs: Int): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs; c.readTimeout = timeoutMs
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            return Resp(code, text, c.getHeaderFieldDate("Date", 0L))
        } finally { c.disconnect() }
    }

    private fun friendly(code: Int) = when (code) {
        401, 403 -> "قواعد قاعدة الترخيص لم تُنشر بعد (Permission denied)"
        404 -> "عنوان قاعدة الترخيص غير صحيح"
        429 -> "طلبات كثيرة؛ أعد المحاولة بعد قليل"
        else -> "خطأ من خادم الترخيص ($code)"
    }

    private fun parseBindings(body: String): List<DeviceRank.Entry> {
        val t = body.trim()
        if (t.isEmpty() || t == "null") return emptyList()
        val m = MiniJson.parse(t) as? Map<*, *> ?: return emptyList()
        return m.entries.mapNotNull { (k, v) ->
            val id = k as? String ?: return@mapNotNull null
            val tm = ((v as? Map<*, *>)?.get("t") as? Number)?.toLong() ?: return@mapNotNull null
            DeviceRank.Entry(id, tm)
        }
    }

    /** يجلب المستند ويسجّل هذا الجهاز (إن لم يُسجَّل) ويحسب هل هو ضمن العدد المسموح. يُستدعى من خيط خلفي. */
    fun sync(base: String, licenseId: String, deviceId: String, deviceName: String, timeoutMs: Int = 12_000): Result {
        val b = base.trim().trimEnd('/')
        if (!(b.startsWith("https://") || b.startsWith("http://"))) return Result.Error("عنوان قاعدة الترخيص غير صالح")
        val id = LicenseKey.normalize(licenseId) ?: return Result.Error("مفتاح التفعيل غير صالح")
        if (!deviceId.matches(Regex("[A-Za-z0-9]{8,40}"))) return Result.Error("معرّف الجهاز غير صالح")
        return try {
            val d = http("GET", "$b/$ROOT/lic/$id.json", null, timeoutMs)
            if (d.code !in 200..299) return Result.Error(friendly(d.code))
            if (d.dateMs <= 0L) return Result.Error("لم يرسل الخادم وقته")
            val txt = d.body.trim()
            val raw: String? = if (txt.isEmpty() || txt == "null") null else (MiniJson.parse(txt) as? String)
            if (raw == null) return Result.Ok(SyncResult(null, d.dateMs, true, false))

            val max = LicenseCodec.decode(raw)?.maxDevices ?: 0
            var entries = fetchBindings(b, id, timeoutMs)
            var registered = entries.any { it.id == deviceId }
            if (!registered) {
                val body = "{\"t\":{\".sv\":\"timestamp\"},\"n\":" + jsonStr(deviceName.take(50)) + "}"
                val r = http("PUT", "$b/$ROOT/bind/$id/$deviceId.json", body, timeoutMs)
                // 401/403 هنا = مسجَّل مسبقًا (القاعدة write-once) أو لا صلاحية؛ نعيد القراءة لنعرف
                if (r.code !in 200..299 && r.code != 401 && r.code != 403) return Result.Error(friendly(r.code))
                entries = fetchBindings(b, id, timeoutMs)
                registered = entries.any { it.id == deviceId }
            }
            val ok = if (registered) DeviceRank.allowed(deviceId, entries, max) else max <= 0
            Result.Ok(SyncResult(raw, d.dateMs, ok, registered))
        } catch (e: ApiError) {
            Result.Error(e.message ?: "خطأ من خادم الترخيص")
        } catch (e: MiniJson.ParseException) {
            Result.Error("استجابة غير مفهومة من الخادم")
        } catch (e: IOException) {
            Result.Offline
        }
    }

    private fun fetchBindings(base: String, id: String, timeoutMs: Int): List<DeviceRank.Entry> {
        val r = http("GET", "$base/$ROOT/bind/$id.json", null, timeoutMs)
        if (r.code !in 200..299) throw ApiError(friendly(r.code))
        return parseBindings(r.body)
    }

    private fun jsonStr(s: String) = buildString {
        append('"')
        for (c in s) when (c) {
            '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n"); '\r' -> append("\\r"); '\t' -> append("\\t")
            else -> if (c < ' ') append("\\u%04x".format(c.code)) else append(c)
        }
        append('"')
    }
}
