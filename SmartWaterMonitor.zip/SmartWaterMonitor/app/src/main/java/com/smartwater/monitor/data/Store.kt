package com.smartwater.monitor.data

import android.content.Context
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.core.MeterConfig
import com.smartwater.monitor.core.SwingParams
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File

data class AppConfig(
    val ip: String = "192.168.1.100",
    val user: String = "admin",
    val pass: String = "",
    val channel: Int = 4,
    val streamType: Int = 0,        // 0 رئيسي (دقة عالية، يلزم لقراءة عقرب صغير)، 1 فرعي
    val realChannel: Int = -1,      // تجاوز اختياري لرقم القناة الفعلي في SDK
    val meters: List<MeterConfig> = listOf(
        // قيم افتراضية مأخوذة من فيديو الاختبار 2560×1944؛ عايرها لكاميرتك من شاشة المعايرة.
        MeterConfig("العداد 1", 505.0, 1232.0, 60.0),
        MeterConfig("العداد 2", 1887.0, 1337.0, 62.0),
    ),
    val swing: SwingParams = SwingParams(),
    val calW: Int = 0,              // مقاس الإطار الذي جرت عليه المعايرة (0 = غير معروف)
    val calH: Int = 0,
    val truckChannel: Int = 7,      // قناة كاميرا الوايتات: لقطة JPEG عند بدء حركة العدّاد (0 = معطّل)
    val autoRecognize: Boolean = true, // التعرّف التلقائي على الوايت من شكله ولونه
    /** عدد العدّادات في كاميرا العدّادات: 1 أو 2 (معايرة العدّاد المخفي تبقى محفوظة). */
    val meterCount: Int = 2,
    /** نسبة تغيّر منطقة الوايت (عن مرجعه أثناء التدفق) لاعتباره وايتًا آخر وإغلاق الجلسة. أقل = أحسّ. */
    val swapFrac: Double = 0.35,
    /** وضع التشخيص: يحفظ لقطات العدّاد وقراءات المتتبّع وحالة كشف الوايت لكل تعبئة للتصدير. */
    val diag: Boolean = false,
    /** كم برميلًا في الدورة الكاملة (360°) للعقرب الكبير. الافتراضي 0.5 (= 720° للبرميل). */
    val barrelsPerTurn: Double = 0.5,
    /** 0 = تفرّع (العدّادان يقيسان ماءً مختلفًا فيُجمعان، وهو السلوك السابق)؛ 1 = تسلسل (الماء نفسه فلا يُجمع). */
    val wiring: Int = 0,
    /**
     * منطقة «تحت القصبة» في قناة الوايتات: "x,y,w,h" بالنسب المئوية. القيمة الافتراضية مقيسة على فيديو Camera 07:
     * الوايت الواقف تحت القصبة يغطي 26–33% منها، والوايت العابر البعيد في الخلفية أقل من 7%.
     */
    val truckZone: String = DEFAULT_ZONE,
) {
    /** درجات العقرب لكل برميل (مشتقّة من «براميل الدورة الكاملة»). */
    val degPerBarrel: Double get() = 360.0 / barrelsPerTurn.coerceIn(0.01, 10.0)

    /** العدّادات الفعّالة فقط (الأول أو الأول والثاني). */
    val activeMeters: List<MeterConfig> get() = meters.take(meterCount.coerceIn(1, meters.size))

    companion object { const val DEFAULT_ZONE = "44,28,46,47" }
}

/** إعدادات التطبيق في SharedPreferences (ملاحظة: كلمة المرور تُخزَّن محليًا بلا تشفير). */
class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("smart_water", Context.MODE_PRIVATE)

    fun load(): AppConfig {
        val s = prefs.getString("config", null) ?: return AppConfig()
        return try {
            val j = JSONObject(s)
            val d = AppConfig()
            val ms = j.optJSONArray("meters")
            val meters = if (ms != null && ms.length() == 2) List(2) {
                val m = ms.getJSONObject(it)
                MeterConfig(m.getString("name"), m.getDouble("cx"), m.getDouble("cy"), m.getDouble("r"))
            } else d.meters
            val sw = j.optJSONObject("swing")
            val sd = SwingParams()
            val swing = if (sw == null) sd else SwingParams(
                startDeg = sw.optDouble("startDeg", sd.startDeg),
                startWindowSec = sw.optDouble("startWindowSec", sd.startWindowSec),
                stopDeg = sw.optDouble("stopDeg", sd.stopDeg),
                stopWindowSec = sw.optDouble("stopWindowSec", sd.stopWindowSec),
                minSwingDeg = sw.optDouble("minSwingDeg", sd.minSwingDeg),
                endToleranceSec = sw.optDouble("endToleranceSec", sd.endToleranceSec),
                minOverlapSec = sw.optDouble("minOverlapSec", sd.minOverlapSec),
                gapSec = sw.optDouble("gapSec", sd.gapSec),
            )
            AppConfig(
                j.optString("ip", d.ip), j.optString("user", d.user), j.optString("pass", d.pass),
                j.optInt("channel", d.channel), j.optInt("streamType", d.streamType),
                j.optInt("realChannel", d.realChannel), meters, swing,
                j.optInt("calW", 0), j.optInt("calH", 0),
                truckChannel = j.optInt("truckChannel", d.truckChannel),
                autoRecognize = j.optBoolean("autoRecognize", d.autoRecognize),
                meterCount = j.optInt("meterCount", d.meterCount).coerceIn(1, 2),
                swapFrac = j.optDouble("swapFrac", d.swapFrac).let { if (it.isFinite() && it in 0.05..0.95) it else d.swapFrac },
                diag = j.optBoolean("diag", d.diag),
                barrelsPerTurn = j.optDouble("barrelsPerTurn", d.barrelsPerTurn).let { if (it.isFinite() && it > 0.0) it else d.barrelsPerTurn },
                wiring = j.optInt("wiring", d.wiring),
                truckZone = j.optString("truckZone", d.truckZone).ifBlank { d.truckZone },
            )
        } catch (e: Exception) { AppConfig() }
    }

    fun save(c: AppConfig) {
        val j = JSONObject()
        j.put("ip", c.ip).put("user", c.user).put("pass", c.pass)
        j.put("channel", c.channel).put("streamType", c.streamType).put("realChannel", c.realChannel).put("calW", c.calW).put("calH", c.calH)
        j.put("truckChannel", c.truckChannel).put("autoRecognize", c.autoRecognize)
        j.put("swapFrac", c.swapFrac).put("diag", c.diag).put("barrelsPerTurn", c.barrelsPerTurn).put("meterCount", c.meterCount).put("wiring", c.wiring).put("truckZone", c.truckZone)
        val ms = JSONArray()
        c.meters.forEach { ms.put(JSONObject().put("name", it.name).put("cx", it.cx).put("cy", it.cy).put("r", it.radius)) }
        j.put("meters", ms)
        val s = c.swing
        j.put("swing", JSONObject()
            .put("startDeg", s.startDeg).put("startWindowSec", s.startWindowSec)
            .put("stopDeg", s.stopDeg).put("stopWindowSec", s.stopWindowSec)
            .put("minSwingDeg", s.minSwingDeg).put("endToleranceSec", s.endToleranceSec)
            .put("minOverlapSec", s.minOverlapSec).put("gapSec", s.gapSec))
        prefs.edit().putString("config", j.toString()).apply()
    }

    /** مرجع المعايرة: نافذة ROI رمادية من لحظة المعايرة، تُستخدم لتعويض الاهتزاز. */
    fun saveReference(i: Int, f: GrayFrame) {
        DataOutputStream(File(ctx.filesDir, "ref_$i.bin").outputStream().buffered()).use {
            it.writeInt(f.width); it.writeInt(f.height); it.writeInt(f.originX); it.writeInt(f.originY)
            it.write(f.data, 0, f.width * f.height)
        }
    }

    fun loadReference(i: Int): GrayFrame? {
        val file = File(ctx.filesDir, "ref_$i.bin")
        if (!file.exists()) return null
        return try {
            DataInputStream(file.inputStream().buffered()).use {
                val w = it.readInt(); val h = it.readInt(); val ox = it.readInt(); val oy = it.readInt()
                val d = ByteArray(w * h); it.readFully(d)
                GrayFrame(w, h, d, ox, oy)
            }
        } catch (e: Exception) { null }
    }

    fun deleteReferences() { for (i in 0..1) File(ctx.filesDir, "ref_$i.bin").delete() }
}
