package com.smartwater.monitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** يعرض لقطة قناة الوايتات ويرسم المستخدم عليها بالسحب مستطيل «منطقة تحت القصبة». النتيجة نسب مئوية x,y,w,h. */
class ZonePickerView(ctx: Context, private val bmp: Bitmap, initial: DoubleArray?) : View(ctx) {
    private val r = RectF(0.44f, 0.28f, 0.90f, 0.75f)       // مطبَّع 0..1
    private val fill = Paint().apply { color = Color.argb(70, 30, 160, 255) }
    private val line = Paint().apply { color = Color.rgb(30, 160, 255); style = Paint.Style.STROKE; strokeWidth = 4f }
    private var sx = 0f; private var sy = 0f

    init { if (initial != null && initial.size == 4) r.set(initial[0].toFloat(), initial[1].toFloat(), (initial[0] + initial[2]).toFloat(), (initial[1] + initial[3]).toFloat()) }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, (width.toFloat() * bmp.height / bmp.width).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.drawBitmap(bmp, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)
        val d = RectF(r.left * width, r.top * height, r.right * width, r.bottom * height)
        c.drawRect(d, fill); c.drawRect(d, line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val nx = (e.x / width).coerceIn(0f, 1f); val ny = (e.y / height).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = nx; sy = ny; r.set(nx, ny, nx, ny) }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> r.set(min(sx, nx), min(sy, ny), max(sx, nx), max(sy, ny))
        }
        invalidate(); parent?.requestDisallowInterceptTouchEvent(true)
        return true
    }

    /** "x,y,w,h" بالنسبة المئوية، أو null إن كان المستطيل أصغر من 3% (لم يُرسَم شيء). */
    fun zonePct(): String? {
        val w = (r.width() * 100); val h = (r.height() * 100)
        if (w < 3f || h < 3f) return null
        return "%.0f,%.0f,%.0f,%.0f".format(r.left * 100, r.top * 100, w, h)
    }
}
