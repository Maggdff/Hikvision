package com.smartwater.monitor.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * تعويض اهتزاز الصورة: مطابقة NCC لحلقة الدرجات الخارجية الثابتة لوجه العدّاد
 * (r من 0.72R إلى 1.02R، بعيدة عن العقرب) مع إطار مرجعي، ثم استخدام الإزاحة
 * (بدقة تحت البكسل) لتحريك مركز العدّاد.
 */
class ShakeCompensator(
    private val search: Int = 6,
    private val innerR: Double = 0.72,
    private val outerR: Double = 1.02,
    private val stride: Int = 2,
    private val minNcc: Double = 0.45,
    /** مطابقة محلية أعلى من هذا تُقبل مباشرة؛ دونه يُجرى بحث عام حول المرجع (اهتزاز كبير يقفز بعيدًا عن آخر موضع). */
    private val goodNcc: Double = 0.80,
    /** مطابقة بهذا المستوى فما فوق موثوقة (الصحيحة ≥ 0.85 حتى مع تمويه شديد، والزائفة ≤ 0.74 غالبًا). */
    private val trustNcc: Double = 0.70,
    /** مدى البحث العام حول المرجع (بكسل). */
    private val globalSearch: Int = 20,
) {
    private var dx = IntArray(0)
    private var dy = IntArray(0)
    private var ref = DoubleArray(0)
    private var refSum = 0.0
    private var refSq = 0.0
    private var subSum = 0.0   // إحصاءات مجموعة فرعية (كل نقطة ثانية) للبحث التقريبي
    private var subSq = 0.0
    private var baseX = 0
    private var baseY = 0
    var hasRef = false
        private set

    fun setReference(f: GrayFrame, cx: Double, cy: Double, radius: Double) {
        baseX = cx.roundToInt(); baseY = cy.roundToInt()
        val xs = ArrayList<Int>(); val ys = ArrayList<Int>(); val vs = ArrayList<Double>()
        val ro = outerR * radius; val ri = innerR * radius
        val lim = ro.toInt() + 1
        var y = -lim
        while (y <= lim) {
            var x = -lim
            while (x <= lim) {
                val r = sqrt((x * x + y * y).toDouble())
                if (r in ri..ro) {
                    val p = f.pixel(baseX + x, baseY + y)
                    if (p >= 0) { xs.add(x); ys.add(y); vs.add(p.toDouble()) }
                }
                x += stride
            }
            y += stride
        }
        dx = xs.toIntArray(); dy = ys.toIntArray(); ref = vs.toDoubleArray()
        refSum = ref.sum(); refSq = ref.sumOf { it * it }
        subSum = 0.0; subSq = 0.0
        for (k in ref.indices step 2) { subSum += ref[k]; subSq += ref[k] * ref[k] }
        hasRef = ref.size > 100
    }

    class Shift(val x: Double, val y: Double, val ncc: Double)

    /**
     * يبحث أولًا حول (lastX,lastY) بمدى ±search (الحالة المعتادة). إن ضعفت المطابقة (اهتزاز كبير يتجاوز النافذة المحلية)
     * يُجرى بحث عام تقريبي حول المرجع بمدى ±globalSearch ثم تدقيق محلي حول أفضل نقطة. null إذا بقيت المطابقة غير موثوقة.
     */
    fun estimate(f: GrayFrame, lastX: Double, lastY: Double): Shift? {
        if (!hasRef) return null
        val n = ref.size
        val denR = refSq - refSum * refSum / n
        if (denR <= 1e-6) return null
        var r = refine(f, lastX.roundToInt(), lastY.roundToInt(), search, denR)
        if (r == null || r.ncc < goodNcc) {
            val c = coarse(f)
            if (c != null) {
                val r2 = refine(f, c.first, c.second, 3, denR)
                if (r2 != null && (r == null || r2.ncc > r.ncc)) r = r2
            }
        }
        if (r == null || r.ncc < minNcc) return null
        if (r.ncc >= trustNcc) return r
        // مطابقة متوسطة (قد تكون زائفة خارج مدى البحث): تُقبل فقط إن اتسقت مع آخر إزاحة معروفة (ليست قفزة)
        return if (hypot(r.x - lastX, r.y - lastY) <= 4.0) r else null
    }

    /** بحث تقريبي: خطوة 2 بكسل ونصف نقاط الحلقة. يعيد أفضل إزاحة صحيحة أو null. */
    private fun coarse(f: GrayFrame): Pair<Int, Int>? {
        val n = ref.size
        val m = (n + 1) / 2
        val denS = subSq - subSum * subSum / m
        if (denS <= 1e-6) return null
        var best = -2.0; var bx = 0; var by = 0
        var sy = -globalSearch
        while (sy <= globalSearch) {
            var sx = -globalSearch
            while (sx <= globalSearch) {
                var sv = 0.0; var svv = 0.0; var svr = 0.0; var ok = true
                var k = 0
                while (k < n) {
                    val p = f.pixel(baseX + dx[k] + sx, baseY + dy[k] + sy)
                    if (p < 0) { ok = false; break }
                    val v = p.toDouble()
                    sv += v; svv += v * v; svr += v * ref[k]
                    k += 2
                }
                if (ok) {
                    val denV = svv - sv * sv / m
                    if (denV > 1e-6) {
                        val ncc = (svr - sv * subSum / m) / sqrt(denV * denS)
                        if (ncc > best) { best = ncc; bx = sx; by = sy }
                    }
                }
                sx += 2
            }
            sy += 2
        }
        return if (best < minNcc * 0.8) null else bx to by
    }

    /** بحث صحيح كامل حول (cx0,cy0) بمدى ±sr ثم تدقيق تحت البكسل. */
    private fun refine(f: GrayFrame, cx0: Int, cy0: Int, sr: Int, denR: Double): Shift? {
        val n = ref.size
        val w = 2 * sr + 1
        var best = -2.0; var bi = -1
        for (j in 0 until w) for (i in 0 until w) {
            val sx = cx0 + i - sr; val sy = cy0 + j - sr
            var sv = 0.0; var svv = 0.0; var svr = 0.0; var ok = true
            for (k in 0 until n) {
                val p = f.pixel(baseX + dx[k] + sx, baseY + dy[k] + sy)
                if (p < 0) { ok = false; break }
                val v = p.toDouble()
                sv += v; svv += v * v; svr += v * ref[k]
            }
            if (!ok) continue
            val denV = svv - sv * sv / n
            if (denV <= 1e-6) continue
            val ncc = (svr - sv * refSum / n) / sqrt(denV * denR)
            if (ncc > best) { best = ncc; bi = j * w + i }
        }
        if (bi < 0) return null
        val bj = bi / w; val bx = bi % w
        var rx = (cx0 + bx - sr).toDouble()
        var ry = (cy0 + bj - sr).toDouble()
        // تدقيق تحت البكسل: شبكة 0.25 بكسل حول أفضل نقطة صحيحة (عيّنة ثنائية الخطية)
        var fb = best
        val ix = rx; val iy = ry
        var ox = -0.5
        while (ox <= 0.5001) {
            var oy = -0.5
            while (oy <= 0.5001) {
                if (ox != 0.0 || oy != 0.0) {
                    val v = nccReal(f, ix + ox, iy + oy, denR)
                    if (v > fb) { fb = v; rx = ix + ox; ry = iy + oy }
                }
                oy += 0.25
            }
            ox += 0.25
        }
        if (abs(rx) > 60 || abs(ry) > 60) return null
        return Shift(rx, ry, fb)
    }

    private fun nccReal(f: GrayFrame, sx: Double, sy: Double, denR: Double): Double {
        val n = ref.size
        var sv = 0.0; var svv = 0.0; var svr = 0.0
        for (k in 0 until n) {
            val v = f.sample(baseX + dx[k] + sx, baseY + dy[k] + sy)
            if (v.isNaN()) return -2.0
            sv += v; svv += v * v; svr += v * ref[k]
        }
        val denV = svv - sv * sv / n
        if (denV <= 1e-6) return -2.0
        return (svr - sv * refSum / n) / sqrt(denV * denR)
    }
}
