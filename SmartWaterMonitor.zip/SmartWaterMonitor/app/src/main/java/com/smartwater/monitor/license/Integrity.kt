package com.smartwater.monitor.license

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.smartwater.monitor.BuildConfig
import java.security.MessageDigest

/**
 * فحص سلامة التطبيق: يقارن بصمة شهادة توقيع الـAPK المثبَّت ببصمة مفتاحنا وقت البناء. من يفكّ الـAPK ويعدّله ويعيد توقيعه بمفتاح آخر
 * تتغير البصمة فيُغلق العدّ (TAMPERED) ويبقى السجل والتصدير متاحَين. يرفع الكلفة ولا يمنع من يبتر الفحص نفسه من الشيفرة.
 * إن كانت البصمة فارغة وقت البناء (تعذّر حسابها) يُعطَّل الفحص.
 */
internal object Integrity {
    @Volatile private var cached: Boolean? = null

    fun ok(ctx: Context): Boolean = cached ?: compute(ctx.applicationContext).also { cached = it }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun compute(ctx: Context): Boolean {
        val want = BuildConfig.CERT_SHA256
        if (want.isEmpty()) return true
        return try {
            val pm = ctx.packageManager
            val sigs = if (Build.VERSION.SDK_INT >= 28) {
                val s = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
                when { s == null -> null; s.hasMultipleSigners() -> s.apkContentsSigners; else -> s.signingCertificateHistory }
            } else {
                @Suppress("DEPRECATION") pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
            }
            sigs != null && sigs.isNotEmpty() && sigs.any { hex(MessageDigest.getInstance("SHA-256").digest(it.toByteArray())) == want }
        } catch (_: Exception) { false }
    }
}
