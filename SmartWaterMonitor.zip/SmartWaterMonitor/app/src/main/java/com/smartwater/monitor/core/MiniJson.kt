package com.smartwater.monitor.core

/** قارئ JSON صغير بلا مكتبات (يعمل على JVM وأندرويد): كائن → Map، مصفوفة → List، نص، رقم (Long/Double)، منطقي، null. */
object MiniJson {
    class ParseException(msg: String) : Exception(msg)

    fun parse(text: String): Any? {
        val p = Parser(text)
        val v = p.value()
        p.skipWs()
        if (p.i != text.length) throw ParseException("نص زائد بعد JSON")
        return v
    }

    private class Parser(val s: String) {
        var i = 0
        fun skipWs() { while (i < s.length && s[i].isWhitespace()) i++ }
        private fun fail(m: String): Nothing = throw ParseException("$m عند $i")

        fun value(): Any? {
            skipWs()
            if (i >= s.length) fail("نهاية مفاجئة")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else fail("حرف غير متوقع '$c'")
            }
        }

        private fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) fail("قيمة غير صالحة")
            i += w.length; return v
        }

        private fun num(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val t = s.substring(st, i)
            return t.toLongOrNull() ?: t.toDoubleOrNull() ?: fail("رقم غير صالح")
        }

        private fun str(): String {
            i++                                   // "
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) fail("نص غير منتهٍ")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) fail("هروب غير منتهٍ")
                        when (val e = s[i++]) {
                            '"', '\\', '/' -> sb.append(e)
                            'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                            'u' -> {
                                if (i + 4 > s.length) fail("\\u غير مكتمل")
                                sb.append(s.substring(i, i + 4).toIntOrNull(16)?.toChar() ?: fail("\\u غير صالح")); i += 4
                            }
                            else -> fail("هروب غير معروف")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            skipWs()
            if (i < s.length && s[i] == ']') { i++; return out }
            while (true) {
                out.add(value()); skipWs()
                if (i >= s.length) fail("مصفوفة غير منتهية")
                if (s[i] == ',') { i++; continue }
                if (s[i] == ']') { i++; return out }
                fail("مصفوفة غير صالحة")
            }
        }

        private fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (i < s.length && s[i] == '}') { i++; return out }
            while (true) {
                skipWs()
                if (i >= s.length || s[i] != '"') fail("مفتاح كائن متوقّع")
                val k = str(); skipWs()
                if (i >= s.length || s[i] != ':') fail("':' متوقّعة")
                i++
                out[k] = value(); skipWs()
                if (i >= s.length) fail("كائن غير منتهٍ")
                if (s[i] == ',') { i++; continue }
                if (s[i] == '}') { i++; return out }
                fail("كائن غير صالح")
            }
        }
    }
}
