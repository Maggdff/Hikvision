package com.smartwater.monitor.engine

import android.graphics.BitmapFactory
import android.os.SystemClock
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.camera.SnapshotProvider
import com.smartwater.monitor.core.FillSession
import com.smartwater.monitor.core.FillState
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.core.MeterSample
import com.smartwater.monitor.core.PresenceEvent
import com.smartwater.monitor.core.PresenceParams
import com.smartwater.monitor.core.SwapGuard
import com.smartwater.monitor.core.SwingResult
import com.smartwater.monitor.core.TruckPresenceDetector
import com.smartwater.monitor.core.Wiring
import com.smartwater.monitor.data.AppConfig
import com.smartwater.monitor.data.SwingRecord
import java.util.Locale

/** حالة التعبئة المعروضة للمستخدم. */
class FillStatus(
    val label: String,
    val state: FillState?,
    val truckName: String,
    val perMeter: List<Double>,
    val total: Double,
    val graceRemainingSec: Double?,
    val note: String,
)

/**
 * جلسة التعبئة من البث الحي، مع معرفة بقاء الوايت تحت القصبة (من قناة الوايتات):
 *  - العدّ يبدأ من حركة العدّادين الفعلية.
 *  - بعد سكون العدّادين تنتظر مهلة دقيقة (تعدّ الوقت المرصود فقط): إن عاد التدفق استمر السجل نفسه دون تصفير.
 *  - إن بقي الوايت تحت القصبة بعد المهلة تعتمد الكمية وتبقى الجلسة «توقف مؤقت» وهوية الوايت محفوظة؛ ويستأنف العدّ في السجل نفسه عند عودة الماء.
 *  - تُغلق الجلسة (اكتملت التعبئة) فقط حين يغادر الوايت (أو يُستبدل)، أو بعد 10 دقائق توقف بلا تدفق كحدّ أمان.
 *  - إن تعذّر كشف الوايت (القناة معطّلة/لا لقطة) يعود السلوك لإغلاق الجلسة بعد المهلة كما كان.
 *  - السجل يُحدَّث دوريًا أثناء التعبئة (كل 15ث) فلا يضيع شيء إن أُغلق التطبيق فجأة.
 */
class LiveFill(
    private val config: () -> AppConfig,
    private val snapshots: () -> SnapshotProvider?,
    private val truckFlow: TruckCoordinator,
    private val onSwingText: (String) -> Unit,
    private val onStatus: (FillStatus) -> Unit,
) {
    companion object {
        const val GRACE_SEC = 60.0                  // مهلة التوقف قبل اعتماد النهاية
        const val MAX_PAUSE_MS = 10 * 60_000L       // أقصى توقف مؤقت بلا تدفق قبل الإغلاق (حدّ أمان)
        const val CKPT_MS = 15_000L                 // تحديث السجل أثناء التعبئة
        const val STALE_PRESENCE_MS = 120_000L      // آخر لقطة وجود أقدم من هذا = الوجود مجهول
        const val REBASE_MS = 20 * 60_000L          // «موجود» عالقة بلا تدفق هذه المدة = أعد ضبط الخلفية
        const val DONE_SHOW_MS = 10 * 60_000L       // مدة بقاء «اكتملت التعبئة» ظاهرة
        const val SAMPLE_MS = 2000L                 // لقطة القناة 7 كل ثانيتين
    }

    private val lock = Any()
    private var session: FillSession? = null
    private var epId = -1L
    private var epTried = false
    private var baseWall = Long.MIN_VALUE
    private var lastCkpt = 0L
    private var pausedSince = 0L
    private var lastPublish = 0L
    private var lastDone: FillStatus? = null
    private var lastDoneAt = 0L

    /** مسجّل التشخيص (اختياري؛ يعمل فقط حين يُفعَّل في الإعدادات). */
    @Volatile var diag: DiagRecorder? = null

    @Volatile private var present = false
    @Volatile private var presenceOkAt = 0L
    private var presentSince = 0L
    private var guard = SwapGuard()
    private var guardFrac = 0.35
    @Volatile private var resetBg = false
    @Volatile private var running = false
    private var th: Thread? = null

    fun start() {
        running = true
        th = Thread({ presenceLoop() }, "live-presence").also { it.start() }
    }

    /** يوقف الكشف ويغلق أي جلسة جارية (تُحفظ). */
    fun stop() {
        running = false
        th?.interrupt()
        synchronized(lock) { session?.let { if (it.hasFlowed) close(it, "أُوقفت المراقبة") } }
    }

    /** يعتمد لقطة القناة 7 التالية خلفيةً فارغة (استدعِها والمنطقة خالية). */
    fun resetBackground() { resetBg = true }

    // ------------------------------------------------------------------ عيّنات العدّادات (من البث الحي)
    private fun wallOf(t: Double): Long {
        if (baseWall == Long.MIN_VALUE) baseWall = System.currentTimeMillis() - (t * 1000).toLong()
        return baseWall + (t * 1000).toLong()
    }

    private fun effectivePresent(now: Long) = present && now - presenceOkAt < STALE_PRESENCE_MS
    private fun presenceActive(now: Long) = config().truckChannel > 0 && now - presenceOkAt < STALE_PRESENCE_MS

    fun feed(t: Double, samples: List<MeterSample>) {
        synchronized(lock) {
            val ms = wallOf(t)
            val now = System.currentTimeMillis()
            val s = session ?: newSession(ms).also { session = it }
            s.setTruckPresent(effectivePresent(now))
            s.feed(ms, samples)
            val dg = diag
            if (dg != null && config().diag) dg.sample(s.id, s.hasFlowed, ms, samples)
            after(s, ms, now)
            if (now - lastPublish > 500) publishLocked(now)
        }
    }

    fun markGap() { synchronized(lock) { session?.markGap() } }

    /** مقاطع وجه العدّادات لإطار (وضع التشخيص). */
    fun diagRoi(t: Double, rois: List<GrayFrame>) {
        val dg = diag ?: return
        if (!config().diag) return
        synchronized(lock) { val s = session; if (s != null && s.hasFlowed) dg.roi(s.id, wallOf(t), rois) }
    }

    fun isActive(i: Int) = synchronized(lock) { session?.isActive(i) ?: false }
    fun currentDegrees(i: Int) = synchronized(lock) { session?.currentDegrees(i) ?: 0.0 }
    fun cumulativeDegrees(i: Int) = synchronized(lock) { session?.cumulativeDegrees(i) ?: 0.0 }

    private fun newSession(ms: Long): FillSession {
        val c = config()
        var ref: FillSession? = null
        val fs = FillSession("L$ms", ms, c.activeMeters.size, if (c.wiring == 1) Wiring.SERIES else Wiring.PARALLEL, c.swing.copy(degPerBarrel = c.degPerBarrel), GRACE_SEC) { _, res ->
            ref?.let { finalized(it, res) }
        }
        ref = fs
        CamLog.i("جلسة تعبئة جديدة ${fs.id} (${c.activeMeters.size} عدّاد)")
        return fs
    }

    private fun after(s: FillSession, ms: Long, now: Long) {
        if (!s.hasFlowed) return
        // بدأ التدفق: صورة الوايت من القناة 7 + تعرّف (أو سؤال) — مرة واحدة لكل جلسة
        if (epId < 0 && !epTried && config().truckChannel > 0 && snapshots() != null) {
            epTried = true
            epId = truckFlow.beginEpisode(null)
        }
        if (ms - lastCkpt >= CKPT_MS) {   // حفظ دوري للسجل أثناء التعبئة
            lastCkpt = ms
            val (st, en) = s.flowWindowMs()
            truckFlow.recordSession(epId, s.id, s.result(), st, en)
        }
        val snap = s.snapshot()
        when {
            snap.state == FillState.PAUSED -> {
                if (pausedSince == 0L) pausedSince = ms
                if (ms - pausedSince > MAX_PAUSE_MS) close(s, "الوايت لا يزال تحت القصبة لكن لا تدفق منذ 10 دقائق")
            }
            snap.state == FillState.COMPLETED && snap.finalizedOnce -> close(s, "غادر الوايت")
            else -> pausedSince = 0L
        }
    }

    /** اعتماد/تحديث سجل الجلسة (بعد المهلة أو عند الإغلاق). يُحدَّث السجل نفسه عند الاستئناف. */
    private fun finalized(s: FillSession, res: SwingResult) {
        val (st, en) = s.flowWindowMs()
        val rec = truckFlow.recordSession(epId, s.id, res, st, en)
        lastCkpt = en
        onSwingText(describe(rec, res))
        CamLog.i("اعتُمدت الجلسة ${s.id} → سجل #${rec.seq}: مقاس %.3f برميل".format(Locale.US, res.totalBarrels))
    }

    private fun describe(rec: SwingRecord, r: SwingResult): String {
        val names = config().activeMeters.map { it.name }
        val parts = r.parts.joinToString("\n") { m -> "• ${names.getOrElse(m.meter) { "عداد ${m.meter + 1}" }}: %.2f برميل (%.0f°)".format(Locale.US, m.barrels, m.degrees) }
        val truck = when {
            rec.truckName.isNotEmpty() -> "\nالوايت: ${rec.truckName} — المسجَّل %.2f برميل (الكمية المدخلة)".format(Locale.US, rec.total)
            rec.photo.isNotEmpty() -> "\nالوايت: لم يُحدَّد بعد (تُستبدل الكمية المقاسة بكمية الوايت عند اختياره)"
            else -> ""
        }
        val kind = if (rec.truckName.isNotEmpty()) "زفة كاملة" else rec.typeAr
        return "زفة رقم ${rec.seq} — $kind\n$parts\nمقاس: %.2f برميل$truck".format(Locale.US, r.totalBarrels) +
            (if (r.notes.isNotEmpty()) "\n⚠ ${r.notes}" else "")
    }

    /** الماء متوقف (لا جريان حاليًا) وللجلسة تدفق سابق: أغلقها فورًا (انتهت تعبئة وايتها). أثناء الجريان لا تُغلق. */
    private fun closeIfQuiet(why: String) {
        val s = session ?: return
        if (s.hasFlowed && s.snapshot().state != FillState.COUNTING) close(s, why)
    }

    private fun close(s: FillSession, why: String) {
        s.finish()                       // يعتمد ما بقي من حركة/مهلة بنهاية عند آخر حركة فعلية
        val snap = s.snapshot()
        truckFlow.closeEpisode(epId, true)
        val name = truckFlow.episodeTruck(epId)?.name ?: ""
        lastDone = FillStatus(FillState.COMPLETED.ar, FillState.COMPLETED, name, snap.meterBarrels, snap.totalBarrels, null, why)
        lastDoneAt = System.currentTimeMillis()
        CamLog.i("أُغلقت الجلسة ${s.id}: %.3f برميل مقاس — $why".format(Locale.US, snap.totalBarrels))
        diag?.let { d -> if (config().diag) d.summary(s.id, "الجلسة ${s.id}\nالسبب: $why\nالمقاس: %.3f برميل (لكل عدّاد: ${snap.meterBarrels.joinToString { "%.3f".format(Locale.US, it) }})\nالبداية: ${snap.flowStartMs}\nآخر حركة: ${snap.lastFlowMs}\nالوايت: $name\nملاحظات: ${snap.notes}\n".format(Locale.US, snap.totalBarrels)) }
        session = null; epId = -1L; epTried = false; pausedSince = 0L; lastCkpt = 0L
        publishLocked(System.currentTimeMillis())
    }

    // ------------------------------------------------------------------ الحالة
    private fun statusLocked(now: Long): FillStatus {
        val s = session
        val n = config().activeMeters.size
        val present = effectivePresent(now)
        if (s == null || !s.hasFlowed) {
            val d = lastDone
            if (d != null && now - lastDoneAt < DONE_SHOW_MS && !present) return d
            val label = when {
                present -> "وايت تحت القصبة — بانتظار بدء التدفق"
                presenceActive(now) -> "لا يوجد وايت — بانتظار بدء التدفق"
                else -> FillState.WAITING_FLOW.ar
            }
            val note = if (config().truckChannel > 0 && !presenceActive(now) && running) "لا لقطات من القناة ${config().truckChannel} — كشف الوايت متوقف (يعمل العدّ بلا انتظار الوايت)" else ""
            return FillStatus(label, FillState.WAITING_FLOW, "", List(n) { 0.0 }, 0.0, null, note)
        }
        val snap = s.snapshot()
        val name = truckFlow.episodeTruck(epId)?.name ?: ""
        val note = when (snap.state) {
            FillState.PAUSED -> "الوايت لا يزال تحت القصبة — يُستأنف العدّ في السجل نفسه عند عودة الماء"
            FillState.STOP_WAIT -> "إن عاد الماء قبل انتهاء المهلة يستمر الحساب دون تصفير"
            else -> ""
        }
        return FillStatus(snap.state.ar, snap.state, name, snap.meterBarrels, snap.totalBarrels, snap.graceRemainingSec,
            listOf(note, snap.notes).filter { it.isNotEmpty() }.joinToString(" • "))
    }

    private fun publishLocked(now: Long) { lastPublish = now; onStatus(statusLocked(now)) }

    // ------------------------------------------------------------------ كشف الوايت (قناة الوايتات)
    private fun presenceLoop() {
        var zoneKey = config().truckZone
        var det = TruckPresenceDetector(PresenceParams(zone = parseZone(zoneKey)))
        while (running) {
            val t0 = SystemClock.elapsedRealtime()
            try {
                val c = config()
                if (c.truckZone != zoneKey) { zoneKey = c.truckZone; det = TruckPresenceDetector(PresenceParams(zone = parseZone(zoneKey))) }
                val snap = snapshots()
                if (c.truckChannel > 0 && snap != null) {
                    val jpeg = snap.snapshotJpeg(c.truckChannel)
                    val g = jpeg?.let { decodeGray(it) }
                    if (g != null) {
                        var tag = ""
                        val now = System.currentTimeMillis()
                        presenceOkAt = now
                        if (resetBg) { resetBg = false; det.setBackground(g.first, g.second, g.third); CamLog.i("اعتُمدت لقطة القناة ${c.truckChannel} خلفيةً فارغة"); synchronized(lock) { present = false } }
                        val ev = det.update(now, g.first, g.second, g.third)
                        tag = when (ev) { is PresenceEvent.Entered -> "entered"; is PresenceEvent.Left -> "left"; is PresenceEvent.Replaced -> "replaced"; null -> "" }
                        when (ev) {
                            is PresenceEvent.Entered -> synchronized(lock) {
                                present = true; presentSince = now; CamLog.i("وايت تحت القصبة")
                                // دخل وايت والماء متوقف وللجلسة السابقة تدفق: هو وايت جديد (لا تنتظر مهلة الدقيقة)
                                closeIfQuiet("دخل وايت جديد"); publishLocked(now)
                            }
                            is PresenceEvent.Left -> synchronized(lock) { present = false; CamLog.i("غادر الوايت"); closeIfQuiet("غادر الوايت"); publishLocked(now) }
                            is PresenceEvent.Replaced -> synchronized(lock) { CamLog.i("استُبدل الوايت"); closeIfQuiet("استُبدل الوايت") }
                            null -> {}
                        }
                        synchronized(lock) {
                            // مرجع الوايت يُثبَّت أثناء جريان الماء (واقف تحت القصبة)، وبعد توقفه أي تغيّر كبير في المنطقة = وايت آخر
                            if (guardFrac != c.swapFrac) { guardFrac = c.swapFrac; guard = SwapGuard(c.swapFrac) }
                            val s = session
                            if (s != null && s.hasFlowed) {
                                if (s.snapshot().state == FillState.COUNTING) { det.setReference(); guard.reset() }
                                else if (guard.update(det.refChange)) {
                                    CamLog.i("تغيّر منطقة الوايت %.0f%% عن مرجعه: وايت جديد".format(Locale.US, det.refChange * 100))
                                    tag = "swap"
                                    diag?.let { d -> if (c.diag) d.presence(s.id, now, det.lastFraction, det.refChange, present, tag, jpeg) }
                                    close(s, "تغيّر الوايت"); guard.reset(); det.clearReference()
                                }
                            } else { guard.reset(); det.clearReference() }
                            val dg = diag; val ss = session
                            if (dg != null && c.diag && ss != null && ss.hasFlowed) dg.presence(ss.id, now, det.lastFraction, det.refChange, present, if (tag == "swap") "" else tag, jpeg)
                        }
                        synchronized(lock) {
                            // «موجود» عالقة بلا أي تدفق (خلفية خاطئة عند التشغيل مثلًا): أعد ضبط الخلفية
                            if (present && now - presentSince > REBASE_MS && session?.hasFlowed != true) {
                                det.rebaseToLast(); present = false; CamLog.i("أُعيد ضبط خلفية القناة ${c.truckChannel} (حالة «موجود» بلا تدفق 20 دقيقة)")
                            }
                        }
                    }
                }
            } catch (_: InterruptedException) { return
            } catch (t: Throwable) { CamLog.e("خيط كشف الوايت", t) }
            val rest = SAMPLE_MS - (SystemClock.elapsedRealtime() - t0)
            if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return }
        }
    }

    private fun decodeGray(jpeg: ByteArray): Triple<ByteArray, Int, Int>? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= 640) s *= 2
        val b = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h); b.recycle()
        val g = ByteArray(w * h)
        for (i in px.indices) { val p = px[i]; g[i] = ((((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000).toByte() }
        return Triple(g, w, h)
    }

    private fun parseZone(s: String): DoubleArray? {
        val v = s.split(",").mapNotNull { it.trim().toDoubleOrNull() }
        if (v.size != 4 || v[2] <= 0 || v[3] <= 0) return null
        return doubleArrayOf(v[0] / 100, v[1] / 100, v[2] / 100, v[3] / 100)
    }
}
