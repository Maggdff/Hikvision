package com.smartwater.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.license.LicenseManager

/**
 * خدمة أمامية تُبقي المراقبة تعمل بعد إغلاق الواجهة وإطفاء الشاشة. المحرك نفسه يعيش في App.
 *  - قفل CPU جزئي + قفل Wi‑Fi: كي لا يتوقف المعالج والشبكة عند إطفاء الشاشة.
 *  - START_STICKY + علامة «المراقبة مطلوبة»: إن قتل النظام العملية (مثل سحب التطبيق من الأخيرة) تُعاد الخدمة
 *    وتستأنف المراقبة تلقائيًا بلا واجهة؛ والجلسة المفتوحة تُستأنف من نقطة حفظها فلا يضيع شيء ولا يتكرر.
 *  - لا تتوقف إلا بزر «إيقاف».
 */
class MonitorService : Service() {
    private val guard = Handler(Looper.getMainLooper())
    private val guardTick = object : Runnable {
        override fun run() {
            checkLicense()
            guard.postDelayed(this, 60_000L)
        }
    }

    /**
     * حارس الترخيص: كل دقيقة يتحقق (بحد أدنى 20 دقيقة بين اتصالين)؛ إن حُجب الترخيص يوقف العدّ، وإن عاد (تجديد/استعادة) والمراقبة مطلوبة
     * يستأنف تلقائيًا. السجلات لا تُمَسّ.
     */
    private fun checkLicense() {
        val engine = (application as App).engine
        LicenseManager.refreshAsync()
        val ok = LicenseManager.allowed()
        if (!ok && engine.running) { CamLog.e("الترخيص محجوب: إيقاف العدّ (${LicenseManager.verdict().title})"); engine.stop() }
        else if (ok && isWanted(this) && !engine.running) { CamLog.i("عاد الترخيص: استئناف المراقبة تلقائيًا"); engine.startCamera(null) }
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // أعاد النظام الخدمة بعد قتلها لكن المستخدم كان قد أوقف المراقبة: لا شيء نفعله
        if (intent == null && !isWanted(this)) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "مراقبة العدّادات", NotificationManager.IMPORTANCE_LOW))
        val open = android.app.PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Smart Water Monitor")
            .setContentText("المراقبة جارية في الخلفية")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(1, n)
        } catch (e: Exception) {
            // Android 12+ يمنع بدء خدمة أمامية من الخلفية (ForegroundServiceStartNotAllowedException): لا ننهار؛ نكمل بأفضل جهد
            CamLog.e("تعذّر تحويل الخدمة إلى أمامية (قيود الخلفية في Android 12+)", e)
        }
        acquireLocks()

        LicenseManager.ensure(this)
        val engine = (application as App).engine
        if (isWanted(this) && !engine.running) {
            if (LicenseManager.allowed()) {
                CamLog.i("استئناف المراقبة تلقائيًا بعد إعادة تشغيل الخدمة (بلا واجهة)")
                engine.startCamera(null)
            } else CamLog.e("لا استئناف: الترخيص محجوب (${LicenseManager.verdict().title})")
        }
        guard.removeCallbacks(guardTick); guard.postDelayed(guardTick, 60_000L)
        return START_STICKY
    }

    private fun acquireLocks() {
        try {
            if (wake == null) {
                wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "smartwater:monitor").apply { setReferenceCounted(false) }
            }
            if (wake?.isHeld != true) wake?.acquire()
            if (wifi == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifi = wm.createWifiLock(if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF, "smartwater:wifi")
                    .apply { setReferenceCounted(false) }
            }
            if (wifi?.isHeld != true) wifi?.acquire()
        } catch (e: Exception) { CamLog.e("تعذّر أخذ أقفال التشغيل", e) }
    }

    override fun onDestroy() {
        guard.removeCallbacks(guardTick)
        try { if (wake?.isHeld == true) wake?.release(); if (wifi?.isHeld == true) wifi?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CH = "monitor"
        private const val PREFS = "monitor_state"

        /** هل يريد المستخدم أن تبقى المراقبة تعمل (تُمسح فقط بزر «إيقاف»). */
        fun isWanted(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("wanted", false)
        private fun setWanted(ctx: Context, v: Boolean) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("wanted", v).apply() }

        fun start(ctx: Context) {
            setWanted(ctx, true)
            try { ctx.startForegroundService(Intent(ctx, MonitorService::class.java)) }
            catch (e: Exception) { CamLog.e("تعذّر بدء الخدمة الأمامية", e) }
        }
        fun stop(ctx: Context) {
            setWanted(ctx, false)
            ctx.stopService(Intent(ctx, MonitorService::class.java))
        }
    }
}
