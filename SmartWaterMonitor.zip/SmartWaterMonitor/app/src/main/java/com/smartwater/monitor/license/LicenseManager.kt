package com.smartwater.monitor.license

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import com.smartwater.monitor.BuildConfig
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.core.KeyValue
import com.smartwater.monitor.core.LicenseApi
import com.smartwater.monitor.core.LicenseCodec
import com.smartwater.monitor.core.LicenseGate
import com.smartwater.monitor.core.LicenseKey
import com.smartwater.monitor.core.LicenseKeeper
import com.smartwater.monitor.core.LicenseStatus
import com.smartwater.monitor.core.LicenseVerdict
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

private class PrefsKv(private val p: SharedPreferences) : KeyValue {
    override fun get(key: String): String? = p.getString(key, null)
    override fun put(key: String, value: String?) { p.edit().apply { if (value == null) remove(key) else putString(key, value) }.apply() }
}

/**
 * مدير الترخيص على الهاتف (واحد للتطبيق): يفعّل بمفتاح، ويجلب الترخيص من Firebase ويسجّل الجهاز ويحكم عليه بساعة موثوقة.
 *  - [verdict]: الحكم الحالي للواجهة.   - [allowed]: للعدّ والخدمة قبل أي عمل (محجوب = لا اتصال بالكاميرا ولا عدّ).
 * فشل الجلب (انقطاع، قواعد غير منشورة) يُبقي آخر حكم معروف: لا يُوقَف أحد بسبب الشبكة، ولا يُقفَل إلا بقرار المطوّر
 * أو انتهاء الترخيص/حد الاتصال. السجلات لا تُمَسّ أبدًا.
 */
object LicenseManager {
    private const val MIN_GAP_MS = 20 * 60_000L
    @Volatile private var keeper: LicenseKeeper? = null
    @Volatile private var appCtx: Context? = null
    @Volatile private var lastTry = 0L
    @Volatile private var busy = false
    @Volatile var lastError: String = ""
        private set
    private val listeners = CopyOnWriteArrayList<(LicenseVerdict) -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    private val TAMPERED = LicenseVerdict(LicenseStatus.TAMPERED, true, "نسخة غير موثوقة",
        "تم اكتشاف أن ملف التطبيق عُدّل أو أُعيد توقيعه. ثبّت النسخة الأصلية من مزوّد الخدمة. سجلاتك محفوظة ولم يُحذف منها شيء ويمكنك تصديرها.")

    @Synchronized
    fun ensure(ctx: Context) {
        appCtx = ctx.applicationContext
        if (keeper == null) {
            val app = ctx.applicationContext
            val boot = try { Settings.Global.getInt(app.contentResolver, "boot_count", -1).toString() } catch (_: Exception) { "" }
            keeper = LicenseKeeper(PrefsKv(app.getSharedPreferences("swm_license", Context.MODE_PRIVATE)), mono = { SystemClock.elapsedRealtime() }, bootId = { boot })
        }
    }

    fun addListener(l: (LicenseVerdict) -> Unit) { listeners.addIfAbsent(l) }
    fun removeListener(l: (LicenseVerdict) -> Unit) { listeners.remove(l) }
    private fun publishVerdict() { val v = verdict(); main.post { listeners.forEach { it(v) } } }

    fun verdict(): LicenseVerdict {
        val k = keeper ?: return if (BuildConfig.LICENSE_REQUIRED) LicenseVerdict.NOT_ACTIVATED else LicenseVerdict.UNMANAGED
        val c = appCtx
        if (BuildConfig.LICENSE_REQUIRED && c != null && !Integrity.ok(c)) return TAMPERED
        return k.verdict(BuildConfig.LICENSE_REQUIRED)
    }

    fun allowed(): Boolean = !verdict().blocked

    fun licenseKey(): String? = keeper?.licenseId()?.let { LicenseKey.format(it) }

    /** ملخص للعرض في الإعدادات. */
    fun describe(): String {
        val k = keeper; val v = verdict()
        if (k == null || k.licenseId() == null) return if (BuildConfig.LICENSE_REQUIRED) "غير مفعّل" else "بناء تطوير داخلي: لا يطلب ترخيصًا"
        val d = k.doc()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val sb = StringBuilder()
        sb.append(if (v.blocked) "⛔ ${v.title}" else "✅ مفعّل" + if (v.status == LicenseStatus.GRACE) " (فترة سماح)" else "")
        if (d != null) {
            sb.append("\nالبمب: ${d.org}")
            sb.append("\nينتهي: ").append(if (d.validUntilMs > 0) fmt.format(Date(d.validUntilMs)) else "بلا نهاية")
            v.daysLeft?.let { sb.append(" (متبقٍ $it يومًا)") }
            if (d.maxDevices > 0) sb.append("\nالأجهزة المسموحة: ${d.maxDevices}")
        }
        sb.append("\nالمفتاح: ${licenseKey()}")
        k.lastContactMs().let { if (it > 0) sb.append("\nآخر تحقق: ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(it))) }
        if (lastError.isNotEmpty()) sb.append("\n⚠ آخر محاولة: $lastError")
        return sb.toString()
    }

    private fun deviceId(ctx: Context, lid: String): String {
        val aid = try { Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) } catch (_: Exception) { null }
        val base = if (aid.isNullOrBlank()) ctx.getSharedPreferences("swm_license", Context.MODE_PRIVATE).let { p ->
            p.getString("dev_rand", null) ?: java.util.UUID.randomUUID().toString().also { u -> p.edit().putString("dev_rand", u).apply() } } else aid
        return MessageDigest.getInstance("SHA-256").digest("$base:$lid".toByteArray()).joinToString("") { "%02X".format(it) }.take(16)
    }

    private fun deviceName() = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifEmpty { "Android" }

    /** يتحقق من الترخيص ويسجّل الجهاز (خيط خلفي). يتجاهل الطلبات المتقاربة ما لم تكن [force]. */
    fun refreshAsync(force: Boolean = false, done: (() -> Unit)? = null) {
        val k = keeper; val ctx = appCtx
        val id = k?.licenseId()
        if (k == null || ctx == null || id == null) { done?.let { main.post(it) }; return }
        val now = SystemClock.elapsedRealtime()
        if (busy || (!force && lastTry != 0L && now - lastTry < MIN_GAP_MS)) { done?.let { main.post(it) }; return }
        busy = true; lastTry = now
        Thread({
            try {
                when (val r = LicenseApi.sync(BuildConfig.LICENSE_URL, id, deviceId(ctx, id), deviceName())) {
                    is LicenseApi.Result.Ok -> { k.onFetched(r.sync.raw, r.sync.serverMs, r.sync.deviceOk); lastError = "" }
                    LicenseApi.Result.Offline -> { lastError = "لا اتصال بالإنترنت"; lastTry = 0L }
                    is LicenseApi.Result.Error -> { lastError = r.msg; CamLog.e("الترخيص: ${r.msg}") }
                }
            } catch (t: Throwable) { lastError = t.message ?: "خطأ"; CamLog.e("الترخيص", t) }
            finally { busy = false }
            publishVerdict(); done?.let { main.post(it) }
        }, "license-sync").start()
    }

    /** تفعيل بمفتاح (يلزم إنترنت). يعيد null عند النجاح أو رسالة الخطأ. */
    fun activate(key: String, cb: (String?) -> Unit) {
        val ctx = appCtx; val k = keeper
        val id = LicenseKey.normalize(key)
        if (ctx == null || k == null) { main.post { cb("التطبيق لم يجهز بعد") }; return }
        if (id == null) { main.post { cb("مفتاح غير صالح: 20 حرفًا وأرقامًا (A-Z و2-7) مثل ABCD-EFGH-IJ23-4567-ABCD") }; return }
        Thread({
            val msg: String? = try {
                when (val r = LicenseApi.sync(BuildConfig.LICENSE_URL, id, deviceId(ctx, id), deviceName())) {
                    LicenseApi.Result.Offline -> "يلزم اتصال بالإنترنت للتفعيل"
                    is LicenseApi.Result.Error -> r.msg
                    is LicenseApi.Result.Ok -> when {
                        r.sync.raw == null -> "المفتاح غير موجود — تحقق من كتابته"
                        LicenseCodec.decode(r.sync.raw) == null -> "مستند الترخيص تالف؛ تواصل مع مزوّد الخدمة"
                        else -> { k.setLicenseId(id); k.onFetched(r.sync.raw, r.sync.serverMs, r.sync.deviceOk); lastError = ""; null }
                    }
                }
            } catch (t: Throwable) { t.message ?: "خطأ" }
            publishVerdict(); main.post { cb(msg) }
        }, "license-activate").start()
    }

    /** إلغاء التفعيل على هذا الجهاز (لتغيير المفتاح). لا يمسّ السجلات. */
    fun deactivate() { keeper?.clear(); lastError = ""; publishVerdict() }
}
