package com.smartwater.monitor.engine

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.SurfaceHolder
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.camera.FrameSource
import com.smartwater.monitor.camera.HikSourceFactory
import com.smartwater.monitor.camera.SnapshotProvider
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.data.AppConfig
import com.smartwater.monitor.data.Store
import com.smartwater.monitor.data.SwingDb
import com.smartwater.monitor.data.TruckDb
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MeterState(
    val name: String, val valid: Boolean, val active: Boolean,
    val totalDeg: Double, val rawAngle: Double, val currentDeg: Double,
    val contrast: Double, val shiftX: Double, val shiftY: Double,
    val episodeDeg: Double = 0.0,   // درجات الزبون الحالي (تتصفّر عند انتهاء الزفة)
)

class UiState(val connected: Boolean, val running: Boolean, val frameW: Int, val frameH: Int, val meters: List<MeterState>, val fps: Double)

/** المحرك المشترك بين الواجهة والخدمة: البث الحي -> Pipeline -> جلسة التعبئة (LiveFill) -> سجل الزفات. */
class MonitorEngine(private val ctx: Context) : FrameSource.Listener {
    interface UiListener {
        fun onState(s: UiState)
        fun onSwing(text: String)
        fun onStatus(msg: String)
        /** سؤال «أي وايت هذا؟» (صورة + قائمة الأسماء). */
        fun onTruckPrompt(p: TruckPrompt) {}
        /** أُجيب السؤال أو أُلغي (أغلق نافذته إن كانت معروضة). */
        fun onTruckPromptClosed(episodeId: Long) {}
        /** رسالة قصيرة عن سير الوايت (تعرّف تلقائي، فشل لقطة...). */
        fun onTruckInfo(msg: String) {}
        /** حالة التعبئة: تم التعرف/بانتظار بدء التدفق/جارٍ حساب الماء/بانتظار المهلة/توقف مؤقت/اكتملت. */
        fun onFill(s: FillStatus) {}
    }

    val store = Store(ctx)
    val db = SwingDb(ctx)
    val trucks = TruckDb(ctx)
    val diag = DiagRecorder(ctx)
    @Volatile var cfg: AppConfig = store.load()
    var uiListener: UiListener? = null
        set(v) { field = v; truckFlow.listener = if (v == null) null else truckListener }

    /** الوايتات: لقطة القناة 7 عند بدء الحركة، التعرّف، الربط بالزفة، ومنع التكرار. */
    val truckFlow = TruckCoordinator(ctx, trucks, db, { cfg }) { source as? SnapshotProvider }
    private val truckListener = object : TruckCoordinator.Listener {
        override fun onPrompt(p: TruckPrompt) { uiListener?.onTruckPrompt(p) }
        override fun onPromptClosed(episodeId: Long) { uiListener?.onTruckPromptClosed(episodeId) }
        override fun onInfo(msg: String) { uiListener?.onTruckInfo(msg) }
    }
    init { Thread({ truckFlow.cleanup() }, "truck-cleanup").start() }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("monitor-proc").also { it.start() }
    private val wh = Handler(worker.looper)
    private val busy = AtomicBoolean(false)
    private var inBuf = ByteArray(0)

    @Volatile private var source: FrameSource? = null
    @Volatile private var pipeline: Pipeline? = null
    @Volatile private var fill: LiveFill? = null
    @Volatile var running = false
        private set
    @Volatile private var connected = false
    private var lastT = 0.0
    private var lastUi = 0L
    private var fpsCount = 0
    private var fpsT = 0L
    private var fps = 0.0

    // آخر إطار كامل (للمعايرة) ولقطة المعايرة
    private val lock = Any()
    private var latestMat: Mat? = null
    private var stillMat: Mat? = null
    val stillWidth: Int get() = synchronized(lock) { stillMat?.cols() ?: 0 }
    val stillHeight: Int get() = synchronized(lock) { stillMat?.rows() ?: 0 }

    // ---------- التشغيل ----------
    private fun newPipeline(): Pipeline {
        cfg = store.load()
        val meters = cfg.activeMeters            // عدّاد واحد أو عدّادان بحسب الإعدادات
        val refs = List(meters.size) { store.loadReference(it) }
        return Pipeline(meters, refs) { t, samples -> fill?.feed(t, samples) }
    }

    fun startCamera(holder: SurfaceHolder?) {
        stop()
        pipeline = newPipeline()
        running = true; connected = false
        val c = cfg
        fill = LiveFill({ cfg }, { source as? SnapshotProvider }, truckFlow, { txt -> ui.post { uiListener?.onSwing(txt) } }) { st ->
            ui.post { uiListener?.onFill(st) }
        }.also { it.diag = diag; it.start() }
        pipeline?.tap = { t, rois -> fill?.diagRoi(t, rois) }
        CamLog.i("طلب الاتصال: ${c.ip}:8000 قناة ${c.channel} (SDK متوفر=${HikSourceFactory.AVAILABLE}) — ${c.activeMeters.size} عدّاد")
        status("جارٍ الاتصال بـ ${c.ip}:8000 ، القناة ${c.channel} ...")
        source = HikSourceFactory.create(ctx, c.ip, c.user, c.pass, c.channel, c.streamType, c.realChannel, holder)
            .also { it.start(this) }
    }

    /** لقطة من قناة الوايتات لواجهة رسم المنطقة (خيط خلفي). */
    fun grabTruckSnapshot(cb: (android.graphics.Bitmap?, String) -> Unit) {
        val src = source as? SnapshotProvider; val ch = cfg.truckChannel
        if (src == null || ch <= 0) { ui.post { cb(null, "اتصل بالكاميرا أولًا (وقناة الوايتات غير صفر)") }; return }
        Thread({
            val bmp = try { src.snapshotJpeg(ch)?.let { TruckCoordinator.decode(it, 1280) } } catch (_: Throwable) { null }
            ui.post { cb(bmp, if (bmp == null) "تعذّر التقاط صورة القناة $ch" else "") }
        }, "zone-snap").start()
    }

    /** يعتمد لقطة قناة الوايتات التالية خلفيةً فارغة لكاشف الوجود (والمنطقة خالية). */
    fun resetPresenceBackground(): Boolean { val f = fill ?: return false; f.resetBackground(); return true }

    fun stop() {
        val f = fill; fill = null
        f?.stop()                                  // يعتمد ويغلق أي جلسة جارية
        val s = source ?: return
        source = null
        s.stop()
        wh.post {
            running = false; connected = false
            ui.post { uiListener?.onStatus("متوقف") }
        }
    }

    // ---------- استقبال الإطارات ----------
    override fun onFrame(gray: ByteArray, width: Int, height: Int, tSec: Double) {
        if (!busy.compareAndSet(false, true)) return          // المعالج مشغول: نُسقط الإطار (الزمن حقيقي فلا يتأثر الحساب)
        val n = width * height
        if (inBuf.size != n) inBuf = ByteArray(n)
        System.arraycopy(gray, 0, inBuf, 0, n)
        wh.post {
            try { process(inBuf, width, height, tSec) } catch (e: Exception) { CamLog.e("خطأ معالجة الإطار", e); status("خطأ معالجة: ${e.message}") }
            finally { busy.set(false) }
        }
    }

    override fun onStatus(message: String) = status(message)

    override fun onDisconnected() {
        connected = false
        wh.post { fill?.markGap() }   // انقطاع البث ليس توقف عدّاد
        status("انقطع البث — لا يُحتسب توقفًا للعدّادين")
        publish()
    }

    override fun onFinished() {
        wh.post { running = false; status("انتهى البث"); publish() }
    }

    private var roiWarnKey = 0L
    private var sizeWarnKey = 0L

    private fun process(gray: ByteArray, w: Int, h: Int, t: Double) {
        val p = pipeline ?: return
        connected = true
        val full = Roi.toMat(gray, w, h)
        // الإعدادات الافتراضية مأخوذة من فيديو 2560×1944؛ إن كانت حلقة أي عدّاد خارج حدود إطار الكاميرا الفعلي
        // لا نعالج (كان يرمي CvException من OpenCV) بل نعرض الصورة ليعاير المستخدم عليها.
        val outside = p.meters.withIndex().filter { (_, m) ->
            val r = 1.02 * m.radius
            m.cx - r < 0 || m.cy - r < 0 || m.cx + r > w || m.cy + r > h
        }.map { it.index }
        val cc = cfg
        if (cc.calW > 0 && (cc.calW != w || cc.calH != h) && sizeWarnKey != w.toLong() * 100000 + h) {
            sizeWarnKey = w.toLong() * 100000 + h
            val msg = "تنبيه: عُويرت المواضع على إطار ${cc.calW}×${cc.calH} والبث الآن ${w}×${h} — أعد المعايرة إن اختلفت الصورة."
            CamLog.e(msg); status(msg)
        }
        if (outside.isEmpty()) { roiWarnKey = 0L; p.process(full, t) }
        else {
            val key = w.toLong() * 100000 + h
            if (roiWarnKey != key) {
                roiWarnKey = key
                val msg = "المعايرة خارج حدود الصورة ${w}×${h} (العدّاد ${outside.map { it + 1 }}). افتح تبويب المعايرة وحدّد العدّادين على صورة الكاميرا."
                CamLog.e(msg); status(msg)
            }
        }
        lastT = t
        val now = System.currentTimeMillis()
        if (now - lastUi > 200) {
            lastUi = now
            synchronized(lock) { latestMat?.release(); latestMat = full }
            publish(w, h)
        } else full.release()
        fpsCount++
        if (fpsT == 0L) fpsT = now
        if (now - fpsT >= 2000) { fps = fpsCount * 1000.0 / (now - fpsT); fpsCount = 0; fpsT = now }
    }

    private fun publish(w: Int = 0, h: Int = 0) {
        val p = pipeline ?: return
        val smp = p.samples
        val ms = p.meters.indices.map { i ->
            val s = smp.getOrNull(i)
            val f = fill
            MeterState(
                p.meters[i].name, s?.valid ?: false, f?.isActive(i) ?: false,
                p.trackers[i].totalDegrees, s?.rawAngleDeg ?: 0.0, f?.currentDegrees(i) ?: 0.0,
                s?.contrast ?: 0.0, s?.shiftX ?: 0.0, s?.shiftY ?: 0.0,
                f?.cumulativeDegrees(i) ?: 0.0,
            )
        }
        val st = UiState(connected, running, w, h, ms, fps)
        ui.post { uiListener?.onState(st) }
    }

    private fun status(m: String) { ui.post { uiListener?.onStatus(m) } }

    // ---------- المعايرة ----------
    fun setStillFromLatest(): Boolean = synchronized(lock) {
        val l = latestMat ?: return false
        stillMat?.release(); stillMat = l.clone(); true
    }

    /** معاينة آخر إطار حي بتصغير يناسب العرض. */
    fun latestBitmap(maxDim: Int): Bitmap? = synchronized(lock) {
        val m = latestMat ?: return null
        val sc = min(1.0, maxDim.toDouble() / max(m.cols(), m.rows()))
        val out = Mat()
        Imgproc.resize(m, out, Size(m.cols() * sc, m.rows() * sc), 0.0, 0.0, Imgproc.INTER_AREA)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        out.release()
        bmp
    }

    fun stillBitmap(x0: Double, y0: Double, x1: Double, y1: Double, maxDim: Int): Pair<Bitmap, FloatArray>? = synchronized(lock) {
        val m = stillMat ?: return null
        val rx0 = max(0, x0.roundToInt()); val ry0 = max(0, y0.roundToInt())
        val rx1 = min(m.cols(), x1.roundToInt()); val ry1 = min(m.rows(), y1.roundToInt())
        if (rx1 - rx0 < 8 || ry1 - ry0 < 8) return null
        val sub = Mat(m, Rect(rx0, ry0, rx1 - rx0, ry1 - ry0))
        val sc = min(1.0, maxDim.toDouble() / max(sub.cols(), sub.rows()))
        val out = Mat()
        Imgproc.resize(sub, out, Size(sub.cols() * sc, sub.rows() * sc), 0.0, 0.0, Imgproc.INTER_AREA)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        sub.release(); out.release()
        Pair(bmp, floatArrayOf(rx0.toFloat(), ry0.toFloat(), rx1.toFloat(), ry1.toFloat()))
    }

    /** يحفظ مرجع كل عدّاد (ROI) من لقطة المعايرة الحالية مع المعايرة الجديدة. */
    /** يعيد null عند النجاح، وإلا نص الخطأ. المواضع تُحفظ أولًا (تبقى حتى لو فشل حفظ المرجع). */
    fun saveCalibration(newCfg: AppConfig): String? = synchronized(lock) {
        val m = stillMat ?: return "التقط لقطة أولًا (زر «التقاط من البث»)"
        val w = m.cols(); val h = m.rows()
        val outside = newCfg.activeMeters.withIndex().filter { (_, mc) ->
            val r = 1.02 * mc.radius
            mc.cx - r < 0 || mc.cy - r < 0 || mc.cx + r > w || mc.cy + r > h
        }.map { it.index + 1 }
        if (outside.isNotEmpty())
            return "العدّاد ${outside.joinToString("، ")} خارج حدود الصورة ${w}×${h} — المس موضعه على الصورة ثم احفظ"
        try {
            val saved = newCfg.copy(calW = w, calH = h)
            store.save(saved)
            newCfg.activeMeters.forEachIndexed { i, mc -> store.saveReference(i, Roi.extract(m, mc)) }
            cfg = saved
            CamLog.i("حُفظت المعايرة على إطار ${w}×${h}: " + saved.meters.joinToString { "%s(%.0f,%.0f,r=%.0f)".format(Locale.US, it.name, it.cx, it.cy, it.radius) })
            null
        } catch (t: Throwable) {
            CamLog.e("فشل حفظ المعايرة", t)
            "فشل حفظ المعايرة: ${t.message}"
        }
    }
}
