package com.smartwater.monitor.core

/**
 * ترخيص بمب (عميل) واحد: مستند نصّي يكتبه المطوّر فقط (من برنامج المطوّر) في `swm/lic/<مفتاح>` على Firebase،
 * ويقرؤه التطبيق بمفتاح التفعيل الذي يعرفه صاحب البمب وحده. القراءة بالمفتاح فقط (لا سرد)، والكتابة محصورة بحساب مطوّر معتمد.
 *
 * ملاحظة صريحة: الفحص داخل التطبيق، فهو يمنع الاستخدام العادي ويوقف العدّ بوضوح، لكنه ليس حماية مطلقة ضد من يعدّل ملف
 * APK نفسه (يرفع الكلفة فحص بصمة التوقيع). لا يحذف شيئًا ولا يتلف بيانات: التعليق قابل للعكس تمامًا والسجلات تبقى وتُصدَّر.
 */
data class LicenseDoc(
    /** رقم يزداد مع كل تعديل (للتتبّع والسجل). */
    val rev: Long,
    /** اسم البمب/العميل. */
    val org: String,
    /** false = معلّق من المطوّر. */
    val active: Boolean,
    val startMs: Long,
    /** نهاية الترخيص (ميلي ثانية UTC)، 0 = بلا نهاية. */
    val validUntilMs: Long,
    /** أيام السماح بعد النهاية: الخدمة تعمل مع تنبيه، ثم تتوقف. */
    val graceDays: Int,
    val maintenance: Boolean,
    val maintMsg: String,
    /** رسالة تظهر للمستخدم دون إيقاف الخدمة. */
    val notice: String,
    /** سبب التعليق (يظهر للمستخدم). */
    val reason: String,
    /** أقصى مدة بلا اتصال بخادم الترخيص (أيام)، 0 = بلا حد. تُلزم الجهاز بالتحقق دوريًا فيصله التعليق. */
    val offlineDays: Int,
    /** أقصى عدد أجهزة للترخيص، 0 = بلا حد. */
    val maxDevices: Int,
    val updatedMs: Long
)

object LicenseCodec {
    const val PREFIX = "SWL1"
    private const val FIELDS = 14

    private fun esc(s: String) = buildString {
        for (ch in s) when (ch) {
            '%' -> append("%25"); '|' -> append("%7C"); '\n' -> append("%0A"); '\r' -> append("%0D")
            else -> append(ch)
        }
    }

    private fun unesc(s: String): String? {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '%') { sb.append(c); i++; continue }
            if (i + 3 > s.length) return null
            when (s.substring(i, i + 3)) {
                "%25" -> sb.append('%'); "%7C", "%7c" -> sb.append('|'); "%0A", "%0a" -> sb.append('\n'); "%0D", "%0d" -> sb.append('\r')
                else -> return null
            }
            i += 3
        }
        return sb.toString()
    }

    fun encode(d: LicenseDoc): String = listOf(
        PREFIX, d.rev, esc(d.org), if (d.active) "A" else "S", d.startMs, d.validUntilMs, d.graceDays,
        if (d.maintenance) 1 else 0, esc(d.maintMsg), esc(d.notice), esc(d.reason), d.offlineDays, d.maxDevices, d.updatedMs
    ).joinToString("|")

    /** null = نص غير صالح (لا يُعامَل كترخيص). */
    fun decode(text: String?): LicenseDoc? {
        val p = (text ?: return null).trim().split('|')
        if (p.size != FIELDS || p[0] != PREFIX) return null
        // أرقام موجبة صريحة فقط (لا سالب ولا علامة +) كي يتطابق الفحص مع برنامج المطوّر حرفيًا
        fun num(x: String): Long? = if (x.matches(Regex("\\d{1,15}"))) x.toLong() else null
        val active = when (p[3]) { "A" -> true; "S" -> false; else -> return null }
        val maint = when (p[7]) { "1" -> true; "0" -> false; else -> return null }
        val rev = num(p[1]) ?: return null; val startMs = num(p[4]) ?: return null; val until = num(p[5]) ?: return null
        val grace = num(p[6]) ?: return null; val offline = num(p[11]) ?: return null; val maxDev = num(p[12]) ?: return null
        val updated = num(p[13]) ?: return null
        if (grace > Int.MAX_VALUE || offline > Int.MAX_VALUE || maxDev > Int.MAX_VALUE) return null
        return LicenseDoc(
            rev = rev, org = unesc(p[2]) ?: return null, active = active, startMs = startMs, validUntilMs = until, graceDays = grace.toInt(),
            maintenance = maint, maintMsg = unesc(p[8]) ?: return null, notice = unesc(p[9]) ?: return null,
            reason = unesc(p[10]) ?: return null, offlineDays = offline.toInt(), maxDevices = maxDev.toInt(), updatedMs = updated
        )
    }
}

enum class LicenseStatus {
    /** لم يُدخَل مفتاح تفعيل بعد. */ NOT_ACTIVATED,
    /** بناء لا يطلب ترخيصًا (تطوير داخلي). */ UNMANAGED,
    ACTIVE, GRACE, EXPIRED, SUSPENDED, MAINTENANCE, OFFLINE_LIMIT,
    /** تجاوز عدد الأجهزة المسموحة. */ DEVICE_LIMIT,
    /** حُذف الترخيص من الخادم. */ REVOKED,
    /** تعديل/إعادة توقيع التطبيق. */ TAMPERED
}

/**
 * [blocked] = العدّ والاتصال متوقفان (يبقى السجل والتصدير متاحَين). [banner] = تنبيه لا يوقف الخدمة.
 * [daysLeft] = الأيام المتبقية على نهاية الترخيص (أو على نهاية السماح عند [LicenseStatus.GRACE]).
 */
class LicenseVerdict(
    val status: LicenseStatus, val blocked: Boolean, val title: String, val message: String,
    val banner: String = "", val daysLeft: Long? = null, val org: String = ""
) {
    companion object {
        val UNMANAGED = LicenseVerdict(LicenseStatus.UNMANAGED, false, "", "")
        val NOT_ACTIVATED = LicenseVerdict(LicenseStatus.NOT_ACTIVATED, true, "التطبيق غير مفعّل",
            "أدخل مفتاح التفعيل الذي زوّدك به مزوّد الخدمة (يلزم اتصال بالإنترنت لأول تفعيل).")
    }
}

object LicenseGate {
    const val DAY_MS = 86_400_000L
    const val WARN_DAYS = 14L
    private const val SAFE = "سجلات الزفات محفوظة كما هي ولم يُحذف منها شيء، ويمكنك الاطلاع عليها وتصديرها الآن. يعود العدّ فور استعادة الترخيص."

    private fun daysCeil(ms: Long) = if (ms <= 0) 0L else (ms + DAY_MS - 1) / DAY_MS

    /**
     * [doc] null = لا مستند (غير مفعّل). [revoked] = كان مفعّلًا ثم اختفى مستنده من الخادم.
     * [deviceOk] = الجهاز ضمن العدد المسموح. [lastContactMs] = آخر اتصال ناجح بخادم الترخيص.
     */
    fun evaluate(doc: LicenseDoc?, nowMs: Long, lastContactMs: Long = nowMs, deviceOk: Boolean = true, revoked: Boolean = false): LicenseVerdict {
        if (revoked) return LicenseVerdict(LicenseStatus.REVOKED, true, "أُلغي الترخيص",
            "أُلغي ترخيص هذا التطبيق من مزوّد الخدمة. تواصل معه لإعادة التفعيل.\n\n$SAFE")
        doc ?: return LicenseVerdict.NOT_ACTIVATED
        val org = doc.org

        if (!doc.active) {
            val why = doc.reason.trim().let { if (it.isEmpty()) "" else "\nالسبب: $it" }
            return LicenseVerdict(LicenseStatus.SUSPENDED, true, "الترخيص معلّق",
                "أُوقفت الخدمة مؤقتًا من مزوّد الخدمة.$why\n\n$SAFE", org = org)
        }

        val until = doc.validUntilMs
        val graceEnd = if (until > 0) until + doc.graceDays * DAY_MS else 0L
        if (until > 0 && nowMs > graceEnd) {
            return LicenseVerdict(LicenseStatus.EXPIRED, true, "انتهى الترخيص",
                "انتهت مدة الترخيص وفترة السماح. تواصل مع مزوّد الخدمة لتجديده.\n\n$SAFE", org = org)
        }

        if (!deviceOk) {
            return LicenseVerdict(LicenseStatus.DEVICE_LIMIT, true, "تجاوز عدد الأجهزة",
                "هذا الترخيص مسموح لـ ${doc.maxDevices} جهازًا فقط وقد استُنفدت. تواصل مع مزوّد الخدمة لإضافة جهاز أو إزالة جهاز قديم.\n\n$SAFE", org = org)
        }

        if (doc.maintenance) {
            val m = doc.maintMsg.trim().ifEmpty { "النظام تحت الصيانة حاليًا. سيعود للعمل قريبًا." }
            return LicenseVerdict(LicenseStatus.MAINTENANCE, true, "النظام تحت الصيانة", "$m\n\n$SAFE", org = org)
        }

        if (doc.offlineDays > 0 && nowMs - lastContactMs > doc.offlineDays * DAY_MS) {
            return LicenseVerdict(LicenseStatus.OFFLINE_LIMIT, true, "يلزم التحقق من الترخيص",
                "لم يتصل هذا الهاتف بالإنترنت للتحقق من الترخيص منذ أكثر من ${doc.offlineDays} يومًا. اتصل بالإنترنت ثم أعد المحاولة.\n\n$SAFE", org = org)
        }

        val notice = doc.notice.trim()
        if (until > 0 && nowMs > until) {
            val left = daysCeil(graceEnd - nowMs)
            val b = "انتهى الترخيص وأنت في فترة السماح: يتوقف العدّ بعد $left يومًا. جدّد الترخيص."
            return LicenseVerdict(LicenseStatus.GRACE, false, "فترة السماح", b, banner = joinNotice(b, notice), daysLeft = left, org = org)
        }

        val left = if (until > 0) daysCeil(until - nowMs) else null
        val warn = if (left != null && left <= WARN_DAYS) "ينتهي الترخيص خلال $left يومًا." else ""
        return LicenseVerdict(LicenseStatus.ACTIVE, false, "", "", banner = joinNotice(warn, notice), daysLeft = left, org = org)
    }

    private fun joinNotice(a: String, b: String) = listOf(a, b).filter { it.isNotBlank() }.joinToString("\n")
}

/** مفتاح التفعيل: 20 حرفًا من أبجدية Base32 (A-Z و2-7) = 100 بت، يُعرض مجمَّعًا XXXX-XXXX-XXXX-XXXX-XXXX. */
object LicenseKey {
    private val ALPHABET = ('A'..'Z').toSet() + ('2'..'7').toSet()

    /** يقبل الشرطات والمسافات وحالة الأحرف؛ null = غير صالح. */
    fun normalize(input: String?): String? {
        val s = (input ?: return null).uppercase().filter { it != '-' && !it.isWhitespace() }
        return if (s.length == 20 && s.all { it in ALPHABET }) s else null
    }

    fun format(id: String): String = id.chunked(4).joinToString("-")
}

/** ترتيب الأجهزة المسجّلة على ترخيص واحد: الأقدم تسجيلًا هو المسموح، فلا سباق ولا يزاحم جهازٌ جديد قديمًا. */
object DeviceRank {
    class Entry(val id: String, val t: Long)

    /** هل [own] ضمن أول [max] جهازًا (بترتيب وقت التسجيل ثم المعرّف)؟ max ≤ 0 = بلا حد (بشرط أن يكون مسجّلًا). */
    fun allowed(own: String, entries: List<Entry>, max: Int): Boolean {
        val sorted = entries.sortedWith(compareBy<Entry>({ it.t }, { it.id }))
        val idx = sorted.indexOfFirst { it.id == own }
        if (idx < 0) return false
        return max <= 0 || idx < max
    }
}

/** مخزن مفتاح/قيمة يُنفَّذ بـ SharedPreferences في التطبيق وبخريطة في الاختبارات. */
interface KeyValue {
    fun get(key: String): String?
    fun put(key: String, value: String?)
}

/**
 * حالة الترخيص على الجهاز: يحفظ مفتاح التفعيل وآخر مستند وصل، ويحكم عليه بساعة موثوقة (وقت الخادم من ترويسة Date + عدّاد رتيب)
 * فلا يفيد تغيير ساعة الهاتف. عند انقطاع الاتصال يبقى آخر حكم معروف (لا يُوقَف أحد بسبب انقطاع الشبكة).
 * إن لم تتوفر ساعة موثوقة (بعد إعادة تشغيل بلا اتصال) نأخذ الأكبر من ساعة الهاتف وآخر وقت خادم رآه الجهاز.
 */
class LicenseKeeper(
    private val kv: KeyValue,
    private val wall: () -> Long = { System.currentTimeMillis() },
    mono: () -> Long,
    bootId: () -> String = { "" }
) {
    private val clock = TrustedClock(wall, mono, bootId).also { it.restore(kv.get(K_CLOCK)) }

    private fun long(k: String) = kv.get(k)?.toLongOrNull() ?: 0L

    fun licenseId(): String? = kv.get(K_ID)?.let { LicenseKey.normalize(it) }

    /** يحفظ مفتاحًا جديدًا ويمحو حالة المفتاح السابق. */
    fun setLicenseId(id: String) {
        kv.put(K_ID, id); kv.put(K_DOC, null); kv.put(K_REVOKED, null); kv.put(K_DEV, null)
    }

    fun clear() { kv.put(K_ID, null); kv.put(K_DOC, null); kv.put(K_REVOKED, null); kv.put(K_DEV, null) }

    fun doc(): LicenseDoc? = LicenseCodec.decode(kv.get(K_DOC))
    fun revoked(): Boolean = kv.get(K_REVOKED) == "1"
    fun deviceOk(): Boolean = kv.get(K_DEV) != "0"
    fun lastContactMs(): Long = long(K_CONTACT)

    fun nowMs(): Long {
        val r = clock.read()
        return if (r.trusted) r.ms else maxOf(wall(), long(K_SERVER))
    }

    /**
     * نتيجة جلب ناجحة: [raw] نص المستند (null = لا مستند على الخادم)، [serverMs] وقت الخادم،
     * [deviceOk] = ترتيب هذا الجهاز ضمن المسموح (null = لم يُحسب، يبقى المحفوظ).
     * نص موجود لكنه غير صالح لا يستبدل المحفوظ (لا نوقف أحدًا بسبب نص تالف).
     */
    fun onFetched(raw: String?, serverMs: Long, deviceOk: Boolean? = null) {
        if (serverMs > 0) {
            clock.anchorNow(serverMs)
            kv.put(K_CLOCK, clock.encode())
            kv.put(K_SERVER, maxOf(serverMs, long(K_SERVER)).toString())
            kv.put(K_CONTACT, serverMs.toString())
        }
        when {
            raw == null -> { kv.put(K_REVOKED, "1"); kv.put(K_DOC, null) }
            LicenseCodec.decode(raw) != null -> { kv.put(K_DOC, raw.trim()); kv.put(K_REVOKED, null) }
        }
        if (deviceOk != null) kv.put(K_DEV, if (deviceOk) "1" else "0")
    }

    /** [required] = false لبناء تطوير داخلي لا يطلب ترخيصًا (يعمل بلا مفتاح). */
    fun verdict(required: Boolean = true): LicenseVerdict {
        if (licenseId() == null) return if (required) LicenseVerdict.NOT_ACTIVATED else LicenseVerdict.UNMANAGED
        val now = nowMs()
        return LicenseGate.evaluate(doc(), now, lastContactMs().let { if (it == 0L) now else it }, deviceOk(), revoked())
    }

    private companion object {
        const val K_ID = "lic_id"; const val K_DOC = "lic_doc"; const val K_CLOCK = "lic_clk"; const val K_SERVER = "lic_srv"
        const val K_CONTACT = "lic_contact"; const val K_REVOKED = "lic_rev"; const val K_DEV = "lic_dev"
    }
}
