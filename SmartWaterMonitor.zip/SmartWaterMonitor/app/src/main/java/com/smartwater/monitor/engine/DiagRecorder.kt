package com.smartwater.monitor.engine

import android.content.Context
import android.graphics.Bitmap
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.core.MeterSample
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * وضع التشخيص: لكل تعبئة (مجلد باسم الجلسة) يحفظ ما يلزم لمعرفة سبب أي خطأ في الحساب أو في تمييز الوايت:
 *  - samples.csv: قراءات المتتبّع لكل عدّاد (صالحة؟ زاوية خام، تراكمي، تباين، سرعة) مع ما قبل بدء التدفق بنحو 10ث.
 *  - presence.csv: نسبة التغيّر في منطقة الوايت، التغيّر عن المرجع، وجود الوايت، والأحداث (دخل/غادر/استُبدل/وايت جديد).
 *  - m1_*.jpg / m2_*.jpg: مقاطع وجه العدّاد (≈1.4 لقطة/ث) أثناء التدفق؛ ch7_*.jpg: لقطات قناة الوايتات عند الأحداث وكل 20ث.
 *  - summary.txt: خلاصة الجلسة عند إغلاقها. ويُصدَّر كله zip مع إعدادات المعايرة.
 * الحدّ: آخر 25 تعبئة وبحد أقصى 400MB، والأقدم يُحذف تلقائيًا. يُعطَّل افتراضيًا.
 */
class DiagRecorder(ctx: Context) {
    companion object { const val MAX_SESSIONS = 25; const val MAX_BYTES = 400L * 1024 * 1024; const val MAX_ROI_PER_SESSION = 2500; const val ROI_GAP_MS = 700L; const val PHOTO_GAP_MS = 20_000L }

    private val root = File(ctx.filesDir, "diag").also { it.mkdirs() }
    private var id: String? = null
    private var dir: File? = null
    private var samplesW: BufferedWriter? = null
    private var presenceW: BufferedWriter? = null
    private val pre = ArrayDeque<String>()          // آخر عيّنات قبل بدء التدفق
    private val lastRoi = HashMap<Int, Long>()
    private var roiCount = 0
    private var lastPhoto = 0L

    private fun open(sid: String) {
        if (id == sid) return
        closeFiles()
        id = sid; roiCount = 0; lastRoi.clear(); lastPhoto = 0L
        val d = File(root, sid).also { it.mkdirs() }; dir = d
        samplesW = File(d, "samples.csv").bufferedWriter().also { it.write("t_ms,meter,valid,raw_deg,cum_deg,contrast,uncertain\n") }
        presenceW = File(d, "presence.csv").bufferedWriter().also { it.write("t_ms,changed_frac,ref_change,present,event\n") }
        pre.forEach { samplesW?.write(it) }; pre.clear()
        cleanup()
    }

    private fun closeFiles() {
        try { samplesW?.flush(); samplesW?.close(); presenceW?.flush(); presenceW?.close() } catch (_: Exception) {}
        samplesW = null; presenceW = null; id = null; dir = null
    }

    private fun rows(tMs: Long, s: List<MeterSample>) = buildString {
        s.forEachIndexed { i, m -> append("$tMs,${i + 1},${if (m.valid) 1 else 0},${"%.1f".format(Locale.US, m.rawAngleDeg)},${"%.1f".format(Locale.US, m.angleDeg)},${"%.3f".format(Locale.US, m.contrast)},${if (m.uncertainJump) 1 else 0}\n") }
    }

    /** قراءات المتتبّع: قبل بدء التدفق تُحفَظ في ذاكرة قصيرة، وبعده تُكتب. */
    @Synchronized fun sample(sid: String, flowed: Boolean, tMs: Long, s: List<MeterSample>) {
        val r = rows(tMs, s)
        if (!flowed) { pre.addLast(r); while (pre.size > 40) pre.removeFirst(); return }
        open(sid); samplesW?.write(r)
    }

    @Synchronized fun roi(sid: String, tMs: Long, rois: List<GrayFrame>) {
        open(sid)
        val d = dir ?: return
        rois.forEachIndexed { i, g ->
            if (roiCount >= MAX_ROI_PER_SESSION) return
            if (tMs - (lastRoi[i] ?: 0L) < ROI_GAP_MS) return
            lastRoi[i] = tMs; roiCount++
            try {
                val px = IntArray(g.width * g.height) { val v = g.data[it].toInt() and 255; (0xFF shl 24) or (v shl 16) or (v shl 8) or v }
                val b = Bitmap.createBitmap(px, g.width, g.height, Bitmap.Config.ARGB_8888)
                File(d, "m${i + 1}_$tMs.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                b.recycle()
            } catch (e: Exception) { CamLog.e("تشخيص: حفظ لقطة عدّاد", e) }
        }
    }

    @Synchronized fun presence(sid: String, tMs: Long, changed: Double, refChange: Double, present: Boolean, event: String, jpeg: ByteArray?) {
        open(sid)
        presenceW?.write("$tMs,${"%.3f".format(Locale.US, changed)},${"%.3f".format(Locale.US, refChange)},${if (present) 1 else 0},$event\n")
        if (jpeg != null && (event.isNotEmpty() || tMs - lastPhoto >= PHOTO_GAP_MS)) {
            lastPhoto = tMs
            try { File(dir ?: return, "ch7_${tMs}${if (event.isNotEmpty()) "_$event" else ""}.jpg").writeBytes(jpeg) } catch (e: Exception) { CamLog.e("تشخيص: حفظ لقطة القناة 7", e) }
        }
    }

    @Synchronized fun summary(sid: String, text: String) {
        open(sid)
        try { File(dir ?: return, "summary.txt").writeText(text) } catch (_: Exception) {}
        closeFiles()
    }

    private fun sizeOf(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { sizeOf(it) } ?: 0L)

    fun sizeMb(): Long = sizeOf(root) / (1024 * 1024)

    /** يحذف الأقدم ما زاد عن عدد الجلسات أو الحجم. */
    private fun cleanup() {
        try {
            val dirs = root.listFiles { f -> f.isDirectory }?.sortedBy { it.lastModified() }?.toMutableList() ?: return
            var total = dirs.sumOf { sizeOf(it) }
            while (dirs.size > 1 && (dirs.size > MAX_SESSIONS || total > MAX_BYTES)) { val o = dirs.removeAt(0); total -= sizeOf(o); o.deleteRecursively() }
        } catch (e: Exception) { CamLog.e("تشخيص: تنظيف", e) }
    }

    @Synchronized fun clear() { closeFiles(); root.deleteRecursively(); root.mkdirs() }

    /** يكتب zip بكل الجلسات + ملف `info.txt` (الإعدادات والمعايرة بلا كلمة مرور). */
    @Synchronized fun exportZip(out: OutputStream, info: String) {
        closeFiles()
        ZipOutputStream(out.buffered()).use { z ->
            z.putNextEntry(ZipEntry("info.txt")); z.write(info.toByteArray(Charsets.UTF_8)); z.closeEntry()
            root.walkTopDown().filter { it.isFile }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(root).path.replace('\\', '/')))
                f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
        }
    }

    fun sessions(): Int = root.listFiles { f -> f.isDirectory }?.size ?: 0
}
