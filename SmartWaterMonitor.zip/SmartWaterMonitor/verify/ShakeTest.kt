import com.smartwater.monitor.core.*
import java.io.File
import kotlin.math.abs
import kotlin.random.Random

/**
 * اختبار اهتزاز الكاميرا على إطارات الفيديو الحقيقي: نزيح كل إطار عشوائيًا ±A بكسل (ومعه تمويه حركة اختياري).
 *  (أ) عقرب ساكن: القيمة الصحيحة صفر، فأي درجات = دورات وهمية.
 *  (ب) عقرب متحرك: المقارنة بالقياس النظيف (584.6°).
 *  (ج) اهتزاز عنيف خارج مدى التعويض: يجب أن يفشل بأمان (نقص لا زيادة).
 */
object ShakeTest {
    private var failures = 0
    private fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }

    private fun shift(f: GrayFrame, dx: Int, dy: Int, blur: Int = 0): GrayFrame {
        val w = f.width; val h = f.height; val src = f.data
        val out = ByteArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            if (blur <= 1) {
                out[y * w + x] = src[(y - dy).coerceIn(0, h - 1) * w + (x - dx).coerceIn(0, w - 1)]
            } else { // تمويه حركة أفقي بطول blur
                var s = 0
                for (k in 0 until blur) s += src[(y - dy).coerceIn(0, h - 1) * w + (x - dx - k + blur / 2).coerceIn(0, w - 1)].toInt() and 255
                out[y * w + x] = (s / blur).toByte()
            }
        }
        return GrayFrame(w, h, out, f.originX, f.originY)
    }

    @JvmStatic fun main(a: Array<String>) {
        val dir = a[0]
        val cfg = MeterConfig("L", 505.0, 1232.0, 60.0)
        val frames = readFrames("$dir/frames_L.bin"); val ref = readFrames("$dir/ref_L.bin")[0]
        val times = File("$dir/times.txt").readLines().map { it.split(" ")[0].toDouble() }
        val tp = TrackerParams()
        val clean = MeterTracker(cfg, tp, ref).let { tr -> frames.indices.forEach { tr.update(frames[it], times[it]) }; tr.totalDegrees }
        println("القياس النظيف = %.1f°".format(clean))

        println("أ) عقرب ساكن + اهتزاز (60 إطارًا × 12 تجربة): الدرجات الوهمية = الخطأ")
        var worstStatic = 0.0
        for ((amp, blur) in listOf(2 to 0, 4 to 0, 6 to 0, 8 to 3, 12 to 5)) {
            val res = ArrayList<Double>()
            for (seed in 1..12) {
                val rnd = Random(seed * 31 + amp)
                val tr = MeterTracker(cfg, tp, ref)
                for (k in 0 until 60) tr.update(shift(frames[0], rnd.nextInt(-amp, amp + 1), rnd.nextInt(-amp, amp + 1), blur), k / 3.0)
                res.add(tr.totalDegrees)
            }
            worstStatic = maxOf(worstStatic, res.max())
            println("   ±%2d بكسل%s: متوسط %.1f° ، أسوأ %.1f°".format(amp, if (blur > 1) " + تمويه $blur" else "", res.average(), res.max()))
        }
        check("ساكن، اهتزاز حتى ±12 بكسل مع تمويه: لا دورات وهمية (≤ 15°)", worstStatic <= 15.0, "%.1f°".format(worstStatic))

        println("ب) عقرب متحرك + اهتزاز (12 تجربة): الخطأ عن النظيف")
        var worstMove = 0.0
        for ((amp, blur) in listOf(2 to 0, 4 to 0, 6 to 0, 8 to 3, 12 to 5)) {
            val errs = ArrayList<Double>()
            for (seed in 1..12) {
                val rnd = Random(seed * 17 + amp)
                val tr = MeterTracker(cfg, tp, ref)
                for (k in frames.indices) tr.update(shift(frames[k], rnd.nextInt(-amp, amp + 1), rnd.nextInt(-amp, amp + 1), blur), times[k])
                errs.add(tr.totalDegrees - clean)
            }
            worstMove = maxOf(worstMove, errs.maxOf { abs(it) })
            println("   ±%2d بكسل%s: متوسط %+.1f° ، أسوأ %+.1f° / %+.1f°".format(amp, if (blur > 1) " + تمويه $blur" else "", errs.average(), errs.max(), errs.min()))
        }
        check("متحرك، اهتزاز حتى ±12 بكسل مع تمويه: الخطأ ≤ 30° (أقل من نصف دورة)", worstMove <= 30.0, "%.1f°".format(worstMove))

        println("ج) اهتزاز عنيف خارج مدى التعويض: يجب أن يفشل بأمان (لا دورات وهمية موجبة)")
        var worstPos = 0.0
        for (amp in listOf(28, 40)) {
            val errs = ArrayList<Double>()
            for (seed in 1..10) {
                val rnd = Random(seed * 13 + amp)
                val tr = MeterTracker(cfg, tp, ref)
                for (k in frames.indices) tr.update(shift(frames[k], rnd.nextInt(-amp, amp + 1), rnd.nextInt(-amp, amp + 1), 3), times[k])
                errs.add(tr.totalDegrees - clean)
            }
            worstPos = maxOf(worstPos, errs.max())
            println("   ±%2d بكسل: متوسط %+.1f° ، أسوأ زيادة %+.1f° ، أسوأ نقص %+.1f°".format(amp, errs.average(), errs.max(), errs.min()))
        }
        check("اهتزاز عنيف: لا زيادة وهمية فوق 30° (الفشل نقصٌ لا زيادة)", worstPos <= 30.0, "%.1f°".format(worstPos))
        println(if (failures == 0) "اختبار الاهتزاز نجح" else "فشل $failures")
        if (failures > 0) System.exit(1)
    }
}
