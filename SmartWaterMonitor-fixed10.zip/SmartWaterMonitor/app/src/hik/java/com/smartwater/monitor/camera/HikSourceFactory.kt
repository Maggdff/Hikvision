package com.smartwater.monitor.camera

import android.content.Context
import android.os.SystemClock
import android.view.SurfaceHolder
import com.hikvision.netsdk.ExceptionCallBack
import com.hikvision.netsdk.HCNetSDK
import com.hikvision.netsdk.INT_PTR
import com.hikvision.netsdk.NET_DVR_JPEGPARA
import com.hikvision.netsdk.NET_DVR_DEVICEINFO_V30
import com.hikvision.netsdk.NET_DVR_PREVIEWINFO
import com.hikvision.netsdk.RealPlayCallBack
import org.MediaPlayer.PlayM4.Player
import org.MediaPlayer.PlayM4.PlayerCallBack
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.MatOfDouble
import org.opencv.imgproc.Imgproc
import org.opencv.core.Mat
import org.opencv.imgcodecs.Imgcodecs

object HikSourceFactory {
    const val AVAILABLE = true

    fun create(
        ctx: Context, ip: String, user: String, pass: String,
        channel: Int, streamType: Int, realChannelOverride: Int, holder: SurfaceHolder?,
    ): FrameSource = HikvisionSource(ip, user, pass, channel, streamType, realChannelOverride, holder)
}

/**
 * اتصال Hikvision SDK (HCNetSDK) على المنفذ 8000 وبث القناة المطلوبة، وفك الترميز بـ PlayM4 مع
 * استدعاء العرض (YV12) لأخذ قناة Y.
 *
 * تنبيه: كُتب هذا الصنف وفق واجهة SDK (HCNetSDK/PlayM4 للأندرويد) كما في العيّنة الرسمية، لكنه لم يُجرَّب
 * مع كاميرا حقيقية ولا مع الـ SDK في بيئة التطوير. راجع أي اختلاف في أسماء الدوال بحسب إصدار SDK لديك.
 */
class HikvisionSource(
    private val ip: String,
    private val user: String,
    private val pass: String,
    private val channel: Int,
    private val streamType: Int,
    private val realChannelOverride: Int,
    private val holder: SurfaceHolder?,
) : FrameSource {
    private var sdkObj: HCNetSDK? = null
    private val sdk get() = sdkObj!!
    private val player get() = Player.getInstance()

    @Volatile private var running = false
    private var userId = -1
    private var playId = -1
    private var port = -1
    private var listener: FrameSource.Listener? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var gotHead = false
    @Volatile private var gotData = false
    @Volatile private var firstFrameLogged = false
    private var watchdog: Thread? = null
    private var yBuf = ByteArray(0)
    private val pktCount = java.util.concurrent.atomic.AtomicLong()
    private val byteCount = java.util.concurrent.atomic.AtomicLong()
    private val inputFail = java.util.concurrent.atomic.AtomicLong()
    private val dispCb = java.util.concurrent.atomic.AtomicLong()
    private val decCb = java.util.concurrent.atomic.AtomicLong()
    private val otherTypes = java.util.concurrent.ConcurrentHashMap<Int, Int>()
    @Volatile private var lastInputErr = 0
    @Volatile private var strategy = 0          // 0 افتراضي، 1 فك برمجي، 2 فك عتادي
    @Volatile private var playStartMs = 0L
    private var realCh = 0
    @Volatile private var managed = true        // true: معاينة يديرها SDK (hHwnd) + لقطات JPEG للتحليل
    private var snapThread: Thread? = null
    // التقاط إطارات من سطح المعاينة نفسه (PixelCopy) لمعدل أعلى من لقطات JPEG (~2.4 إطار/ث)
    @Volatile private var pcActive = false
    @Volatile private var pcStarted = false
    private var pcThread: Thread? = null
    private var pcHandlerThread: android.os.HandlerThread? = null
    private val pcOk = java.util.concurrent.atomic.AtomicLong()
    private val pcFail = java.util.concurrent.atomic.AtomicLong()
    private val snapOk = java.util.concurrent.atomic.AtomicLong()
    private val snapFail = java.util.concurrent.atomic.AtomicLong()
    private fun strategyName() = if (managed) "معاينة SDK المُدارة (hHwnd) + لقطات JPEG" else "رد نداء PlayM4 (احتياطي)"

    /** يستقبل YV12 من أي من callbacks PlayM4 (عرض/فك) ويمرّر قناة Y. */
    private fun onYv12(buf: ByteArray, w: Int, h: Int) {
        val n = w * h
        if (n <= 0 || buf.size < n) { CamLog.e("إطار غير صالح: ${w}×${h} حجم=${buf.size}"); return }
        if (yBuf.size != n) yBuf = ByteArray(n)
        System.arraycopy(buf, 0, yBuf, 0, n)
        lastFrameMs = SystemClock.elapsedRealtime()
        if (!firstFrameLogged) { firstFrameLogged = true; info("وصل أول إطار ${w}×${h}") }
        listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
    }

    private fun stats(): String {
        val pr = port
        val extra = if (pr != -1) try {
            " | decoderType=${player.getDecoderType(pr)} fps=${player.getCurrentFrameRate(pr)} " +
            "مفكوك=${player.getPlayedFrames(pr)} bufRemain=${player.getSourceBufferRemain(pr)} plErr=${player.getLastError(pr)}"
        } catch (t: Throwable) { " | stats-err=${t.message}" } else ""
        return "PixelCopy نجح=${pcOk.get()} فشل=${pcFail.get()} فعّال=$pcActive | لقطاتJPEG نجحت=${snapOk.get()} فشلت=${snapFail.get()} | حزم=${pktCount.get()} بايت=${byteCount.get()} inputDataفشل=${inputFail.get()}(آخر خطأ $lastInputErr) " +
            "displayCB=${dispCb.get()} decodeCB=${decCb.get()} أنواع أخرى=$otherTypes$extra"
    }

    private fun info(m: String) { CamLog.i(m); listener?.onStatus(m) }
    private fun fail(m: String, t: Throwable? = null) { CamLog.e(m, t); listener?.onStatus("خطأ: $m") }

    private fun errName(code: Int) = when (code) {
        1 -> "كلمة المرور/المستخدم خاطئ"; 2 -> "صلاحيات غير كافية"; 3 -> "SDK غير مهيّأ"
        4 -> "رقم القناة خاطئ"; 5 -> "تجاوز عدد الاتصالات"; 6 -> "عدم توافق إصدار SDK مع الجهاز"
        7 -> "تعذّر الاتصال بالجهاز (IP/المنفذ/الشبكة)"; 8 -> "فشل الإرسال"; 9 -> "فشل الاستقبال"
        10 -> "انتهت مهلة الاستقبال"; 11 -> "بيانات خاطئة"; 17 -> "معامل خاطئ"; 23 -> "غير مدعوم"
        47 -> "المستخدم غير موجود"; 153 -> "الحساب مقفل (محاولات خاطئة كثيرة)"
        else -> "غير معروف"
    }
    private fun lastErr(): String { val c = sdk.NET_DVR_GetLastError(); return "رمز الخطأ $c (${errName(c)})" }

    override fun start(listener: FrameSource.Listener) {
        this.listener = listener
        running = true
        Thread({
            try { connect(listener) }
            catch (t: Throwable) {   // UnsatisfiedLinkError / NoSuchMethodError وغيرها: كانت تُسقط التطبيق بصمت
                fail("استثناء أثناء الاتصال (غالبًا مكتبات SDK .so أو نسخة jar لا تطابق)", t)
                listener.onDisconnected()
            }
        }, "hik-connect").start()
    }

    private fun connect(l: FrameSource.Listener) {
        CamLog.i("=== بدء الاتصال: $ip:8000 مستخدم=$user قناة=$channel بث=$streamType (CPU: ${android.os.Build.SUPPORTED_ABIS.joinToString()}) ===")
        sdkObj = HCNetSDK.getInstance()
            ?: run { fail("HCNetSDK.getInstance() أعادت null — مكتبات SDK لم تُحمَّل"); l.onDisconnected(); return }
        if (!sdk.NET_DVR_Init()) { fail("فشل NET_DVR_Init — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("NET_DVR_Init نجح")
        sdk.NET_DVR_SetConnectTime(5000)   // التوقيع في هذا الـ jar: (int) فقط
        sdk.NET_DVR_SetReconnect(10000, true)
        val dev = NET_DVR_DEVICEINFO_V30()
        userId = sdk.NET_DVR_Login_V30(ip, 8000, user, pass, dev)
        if (userId < 0) { fail("فشل تسجيل الدخول إلى $ip:8000 — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("تسجيل الدخول نجح userId=$userId — تناظرية=${dev.byChanNum} IP=${dev.byIPChanNum} " +
            "byStartChan=${dev.byStartChan} byStartDChan=${dev.byStartDChan}")
        // رقم القناة: تناظرية = byStartChan + n - 1، وإلا قنوات IP = byStartDChan + n - 1
        val real = when {
            realChannelOverride > 0 -> realChannelOverride
            dev.byChanNum.toInt() >= channel -> dev.byStartChan.toInt() + channel - 1
            else -> dev.byStartDChan.toInt() + channel - 1
        }
        info("تم الدخول. فتح القناة الفعلية $real (المطلوبة $channel) ...")
        sdk.NET_DVR_SetExceptionCallBack(ExceptionCallBack { type, handle, _ ->
            CamLog.e("استثناء SDK نوع=0x${Integer.toHexString(type)} handle=$handle — ${lastErr()}")
            l.onDisconnected()
        })

        val valid = holder?.surface?.isValid == true
        CamLog.i("سطح العرض لـ PlayM4: ${if (holder == null) "null" else if (valid) "صالح" else "غير صالح (لم يُنشأ بعد أو دُمّر)"}")

        realCh = real
        if (!startPlay()) {
            CamLog.e("المعاينة المُدارة فشلت — التحويل إلى رد نداء PlayM4")
            managed = false
            if (!startPlay()) { l.onDisconnected(); return }
        }
        if (managed) startSnapshots(l)
        watchdog = Thread({
            var alerted = false
            var lastStat = 0L
            while (running) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                val now = SystemClock.elapsedRealtime()
                val since = now - playStartMs
                if (since - lastStat >= 2000 && since < 17000) { lastStat = since - since % 2000; CamLog.i("[إحصاء ${since / 1000}ث | ${strategyName()}] ${stats()}") }
                val limit = if (managed) 20000 else if (firstFrameLogged) 6000 else 12000
                val silent = now - lastFrameMs > limit
                if (silent && !alerted) {
                    alerted = true
                    fail("لا إطارات منذ ${limit / 1000} ث (آخر استراتيجية: ${strategyName()}) — رأس النظام=${gotHead} بيانات=${gotData}\n${stats()}")
                    l.onDisconnected()
                }
                if (!silent) alerted = false
            }
        }, "hik-watchdog").also { it.start() }
    }

    /** لقطات JPEG من الجهاز عبر SDK (لا تعتمد على فك PlayM4) ← OpenCV ← قناة رمادية للتحليل. */
    private fun startSnapshots(l: FrameSource.Listener) {
        snapThread = Thread({
            val para = NET_DVR_JPEGPARA().apply { wPicSize = 0xff; wPicQuality = 0 }   // 0xff = دقة البث الحالية، أعلى جودة
            val buf = ByteArray(8 * 1024 * 1024)
            val ret = INT_PTR()
            while (running) {
                if (pcActive) { try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }; continue }
                val t0 = SystemClock.elapsedRealtime()
                try {
                    ret.iValue = 0
                    val ok = sdk.NET_DVR_CaptureJPEGPicture_NEW(userId, realCh, para, buf, buf.size, ret)
                    if (!ok || ret.iValue <= 0) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5 || n % 20 == 0L) CamLog.e("فشل التقاط JPEG (القناة $realCh، حجم=${ret.iValue}) — ${lastErr()}")
                        Thread.sleep(1000); continue
                    }
                    val len = ret.iValue
                    val raw = Mat(1, len, CvType.CV_8UC1)
                    raw.put(0, 0, buf, 0, len)
                    val g = Imgcodecs.imdecode(raw, Imgcodecs.IMREAD_GRAYSCALE)
                    raw.release()
                    if (g.empty()) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5) CamLog.e("تعذّر فك JPEG ($len بايت) بـ OpenCV")
                        g.release(); Thread.sleep(1000); continue
                    }
                    val w = g.cols(); val h = g.rows()
                    if (yBuf.size != w * h) yBuf = ByteArray(w * h)
                    g.get(0, 0, yBuf); g.release()
                    val n = snapOk.incrementAndGet()
                    lastFrameMs = SystemClock.elapsedRealtime()
                    val took = lastFrameMs - t0
                    if (n <= 20 || took > 2000) CamLog.i("لقطة #$n: ${w}×${h} JPEG=$len بايت، استغرقت ${took}ms")
                    if (!firstFrameLogged) { firstFrameLogged = true; info("وصلت أول لقطة ${w}×${h} (JPEG $len بايت، ${lastFrameMs - t0}ms)") }
                    listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
                    if (!pcStarted) startPixelCopy(w, h)
                } catch (_: InterruptedException) { return@Thread
                } catch (t: Throwable) { fail("استثناء في لقطات JPEG", t); try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread } }
                val rest = 400 - (SystemClock.elapsedRealtime() - t0)   // ≥ 400ms بين بدايتي لقطتين
                if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return@Thread }
            }
        }, "hik-snapshots").also { it.start() }
    }

    private fun pcName(c: Int) = when (c) {
        0 -> "SUCCESS"; 1 -> "ERROR_UNKNOWN"; 2 -> "ERROR_TIMEOUT"; 3 -> "ERROR_SOURCE_NO_DATA"
        4 -> "ERROR_SOURCE_INVALID"; 5 -> "ERROR_DESTINATION_INVALID"; -2 -> "مهلة الانتظار"; -3 -> "استثناء"; else -> "?"
    }

    /**
     * تجريبي: بعد أول لقطة JPEG (نعرف المقاس) نثبّت مقاس السطح على مقاس الصورة ونلتقط إطاراتها بـ PixelCopy بمعدل أعلى.
     * يُعتمد بعد 3 نجاحات متتالية بصورة غير فارغة؛ وإن توقف (مثلًا التطبيق في الخلفية) نعود للقطات JPEG تلقائيًا.
     */
    private fun startPixelCopy(w: Int, h: Int) {
        if (pcStarted) return
        pcStarted = true
        val hold = holder ?: run { CamLog.e("PixelCopy: لا يوجد سطح عرض"); return }
        android.os.Handler(android.os.Looper.getMainLooper()).post { try { hold.setFixedSize(w, h) } catch (_: Throwable) {} }
        val ht = android.os.HandlerThread("pc-callback").also { it.start() }
        pcHandlerThread = ht
        val cbHandler = android.os.Handler(ht.looper)
        pcThread = Thread({
            val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val rgba = Mat(); val gray = Mat()
            val meanM = MatOfDouble(); val stdM = MatOfDouble()
            val buf = ByteArray(w * h)
            var good = 0; var bad = 0
            var fpsT = SystemClock.elapsedRealtime(); var fpsN = 0
            try { Thread.sleep(800) } catch (_: InterruptedException) { return@Thread }
            CamLog.i("PixelCopy: بدء المحاولة على سطح ${w}×${h}")
            while (running) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    var code = -1
                    val surf = hold.surface
                    if (surf != null && surf.isValid) {
                        val latch = java.util.concurrent.CountDownLatch(1)
                        var r = -1
                        try {
                            android.view.PixelCopy.request(surf, bmp, { c -> r = c; latch.countDown() }, cbHandler)
                            if (!latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS)) r = -2
                        } catch (t: InterruptedException) { return@Thread
                        } catch (t: Throwable) { r = -3; if (pcFail.get() < 3) CamLog.e("PixelCopy استثناء", t) }
                        code = r
                    }
                    var ok = false
                    if (code == android.view.PixelCopy.SUCCESS) {
                        Utils.bitmapToMat(bmp, rgba)
                        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                        if (pcActive) ok = true
                        else {
                            Core.meanStdDev(gray, meanM, stdM)
                            val mean = meanM.toArray()[0]; val std = stdM.toArray()[0]
                            ok = std > 8.0 && mean > 3.0
                            if (!ok && pcFail.get() < 5) CamLog.e("PixelCopy: الصورة فارغة/سوداء (متوسط=%.1f انحراف=%.1f)".format(mean, std))
                        }
                    }
                    if (ok) {
                        pcOk.incrementAndGet(); good++; bad = 0
                        if (!pcActive && good >= 3) { pcActive = true; CamLog.i("PixelCopy يعمل ← التحويل من لقطات JPEG إلى إطارات السطح ${w}×${h}") }
                        if (pcActive) {
                            gray.get(0, 0, buf)
                            lastFrameMs = SystemClock.elapsedRealtime()
                            if (!firstFrameLogged) { firstFrameLogged = true }
                            listener?.onFrame(buf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
                            fpsN++
                            val nowT = SystemClock.elapsedRealtime()
                            if (nowT - fpsT >= 5000) { if (pcOk.get() < 400) CamLog.i("PixelCopy: %.1f إطار/ث".format(fpsN * 1000.0 / (nowT - fpsT))); fpsT = nowT; fpsN = 0 }
                        }
                    } else {
                        val n = pcFail.incrementAndGet()
                        if (n <= 5 || n % 50 == 0L) CamLog.e("PixelCopy فشل: النتيجة=$code (${pcName(code)}) سطح صالح=${hold.surface?.isValid}")
                        good = 0; bad++
                        if (pcActive && bad >= 5) { pcActive = false; CamLog.e("PixelCopy توقف (التطبيق في الخلفية؟) — العودة للقطات JPEG") }
                    }
                } catch (_: InterruptedException) { return@Thread
                } catch (t: Throwable) { CamLog.e("استثناء في PixelCopy", t) }
                val rest = (if (pcActive) 60L else 1000L) - (SystemClock.elapsedRealtime() - t0)
                if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return@Thread }
            }
            bmp.recycle(); rgba.release(); gray.release()
        }, "hik-pixelcopy").also { it.start() }
    }

    private fun startPlay(): Boolean {
        gotHead = false; gotData = false; firstFrameLogged = false
        pktCount.set(0); byteCount.set(0); inputFail.set(0); dispCb.set(0); decCb.set(0); otherTypes.clear()
        val pi = NET_DVR_PREVIEWINFO()
        pi.lChannel = realCh
        pi.dwStreamType = streamType   // 0 رئيسي، 1 فرعي
        pi.dwLinkMode = 0              // TCP
        pi.bBlocked = 1
        if (managed) {
            // المسار الذي تعتمده العيّنة الرسمية: SDK يفك ويرسم بنفسه على السطح (بلا رد نداء)
            pi.hHwnd = holder
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, null)
        } else {
            val cb = RealPlayCallBack { _, dataType, data, size -> onRealData(dataType, data, size) }
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, cb)
        }
        if (playId < 0) { fail("فشل NET_DVR_RealPlay_V40 للقناة $realCh (${strategyName()}) — ${lastErr()}"); return false }
        CamLog.i("بدأ البث playId=$playId — استراتيجية الفك: ${strategyName()}")
        playStartMs = SystemClock.elapsedRealtime(); lastFrameMs = playStartMs
        return true
    }

    private fun stopPlay() {
        try { if (playId >= 0) sdk.NET_DVR_StopRealPlay(playId) } catch (_: Throwable) {}
        try { if (port != -1) { player.stop(port); player.closeStream(port); player.freePort(port) } } catch (_: Throwable) {}
        playId = -1; port = -1
    }

    private fun onRealData(dataType: Int, data: ByteArray, size: Int) {
        try {
            when (dataType) {
                1 -> { // رأس النظام (NET_DVR_SYSHEAD)
                    gotHead = true
                    if (port != -1) return
                    val hex = data.take(minOf(size, 40)).joinToString(" ") { "%02x".format(it) }
                    CamLog.i("وصل رأس النظام ($size بايت): $hex")
                    port = player.getPort()
                    if (port == -1) { fail("PlayM4.getPort: لا منفذ متاح"); return }
                    CamLog.i("PlayM4 sdkVersion=${player.getSdkVersion()} منفذ=$port")
                    player.setStreamOpenMode(port, Player.STREAM_REALTIME)
                    when (strategy) {
                        1 -> CamLog.i("setHardDecode(منفذ,0)=${player.setHardDecode(port, 0)}")
                        2 -> CamLog.i("setHardDecode(منفذ,1)=${player.setHardDecode(port, 1)}")
                        else -> CamLog.i("بلا setHardDecode (السلوك الافتراضي لـ PlayM4)")
                    }
                    player.setEcnTypeChgCB(port, PlayerCallBack.PlayerEncTypeChgCB { t ->
                        CamLog.e("PlayM4: نوع التشفير تغيّر/اكتُشف = $t (قد يكون البث مشفّرًا ويحتاج رمز التحقق)")
                    })
                    if (!player.openStream(port, data, size, 4 * 1024 * 1024)) {
                        fail("PlayM4.openStream فشل: خطأ ${player.getLastError(port)}"); return
                    }
                    CamLog.i("openStream نجح، decoderType=${player.getDecoderType(port)}")
                    val okD = player.setDisplayCB(port, PlayerCallBack.PlayerDisplayCB { _, buf, _, w, h, _, _, _ ->
                        dispCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    val okC = player.setDecodeCB(port, PlayerCallBack.PlayerDecodeCB { _, buf, _, w, h, _, _, _ ->
                        decCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    CamLog.i("setDisplayCB=$okD setDecodeCB=$okC")
                    if (!player.play(port, holder)) fail("PlayM4.play فشل: خطأ ${player.getLastError(port)} (سطح صالح=${holder?.surface?.isValid})")
                    else CamLog.i("PlayM4.play نجح")
                }
                2 -> {
                    pktCount.incrementAndGet(); byteCount.addAndGet(size.toLong())
                    if (!gotData) { gotData = true; CamLog.i("وصلت أول بيانات بث ($size بايت)") }
                    if (port != -1 && !player.inputData(port, data, size)) {
                        inputFail.incrementAndGet(); lastInputErr = player.getLastError(port)
                        if (inputFail.get() <= 5) CamLog.e("PlayM4.inputData فشل: خطأ $lastInputErr")
                    }
                }
                else -> otherTypes.merge(dataType, 1) { a, b -> a + b }
            }
        } catch (t: Throwable) { fail("استثناء في معالجة بيانات البث", t) }
    }

    override fun stop() {
        running = false
        try {
            watchdog?.interrupt(); snapThread?.interrupt(); pcThread?.interrupt()
            try { snapThread?.join(3000); pcThread?.join(2000) } catch (_: InterruptedException) {}
            pcHandlerThread?.quitSafely(); pcHandlerThread = null; pcThread = null
            stopPlay()
            if (userId >= 0) sdk.NET_DVR_Logout_V30(userId)
            sdk.NET_DVR_Cleanup()
        } catch (_: Throwable) {}
        userId = -1; strategy = 0; managed = true; snapOk.set(0); snapFail.set(0); pcActive = false; pcStarted = false; pcOk.set(0); pcFail.set(0)
        CamLog.i("تم إيقاف المصدر")
    }
}
