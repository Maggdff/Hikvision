package com.smartwater.monitor.camera

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** سجل تشخيص الاتصال بالكاميرا: Logcat + ملف في filesDir + ذاكرة لعرضه في الواجهة. */
object CamLog {
    private const val TAG = "SmartWaterCam"
    private const val MAX_LINES = 400
    private const val MAX_FILE = 200_000L
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val ui = Handler(Looper.getMainLooper())
    private var file: File? = null
    @Volatile var onChange: (() -> Unit)? = null

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "camera_log.txt").also { if (it.length() > MAX_FILE) it.delete() }
    }

    @Synchronized fun i(msg: String) = add("I", msg)
    @Synchronized fun e(msg: String, t: Throwable? = null) =
        add("E", if (t == null) msg else "$msg — ${t.javaClass.name}: ${t.message}")

    private fun add(level: String, msg: String) {
        val line = "${fmt.format(Date())} $level $msg"
        if (level == "E") Log.e(TAG, msg) else Log.i(TAG, msg)
        lines.addLast(line)
        while (lines.size > MAX_LINES) lines.removeFirst()
        try { file?.appendText(line + "\n") } catch (_: Exception) {}
        ui.post { onChange?.invoke() }
    }

    @Synchronized fun text(): String = lines.joinToString("\n")
    @Synchronized fun clear() { lines.clear(); try { file?.delete() } catch (_: Exception) {}; ui.post { onChange?.invoke() } }
}
