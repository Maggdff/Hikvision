package com.smartwater.monitor.camera

import android.content.Context
import android.os.SystemClock
import android.view.SurfaceHolder
import com.hikvision.netsdk.ExceptionCallBack
import com.hikvision.netsdk.HCNetSDK
import com.hikvision.netsdk.NET_DVR_DEVICEINFO_V30
import com.hikvision.netsdk.NET_DVR_PREVIEWINFO
import com.hikvision.netsdk.RealPlayCallBack
import org.MediaPlayer.PlayM4.Player
import org.MediaPlayer.PlayM4.PlayerCallBack

object HikSourceFactory {
    const val AVAILABLE = true

    fun create(
        ctx: Context, ip: String, user: String, pass: String,
        channel: Int, streamType: Int, realChannelOverride: Int, holder: SurfaceHolder?,
    ): FrameSource = HikvisionSource(ip, user, pass, channel, streamType, realChannelOverride, holder)
}

/**
 * اتصال Hikvision SDK (HCNetSDK) على المنفذ 8000 وبث القناة المطلوبة، وفك الترميز بـ PlayM4 مع
 * استدعاء العرض (YV12) لأخذ قناة Y.
 *
 * تنبيه: كُتب هذا الصنف وفق واجهة SDK (HCNetSDK/PlayM4 للأندرويد) كما في العيّنة الرسمية، لكنه لم يُجرَّب
 * مع كاميرا حقيقية ولا مع الـ SDK في بيئة التطوير. راجع أي اختلاف في أسماء الدوال بحسب إصدار SDK لديك.
 */
class HikvisionSource(
    private val ip: String,
    private val user: String,
    private val pass: String,
    private val channel: Int,
    private val streamType: Int,
    private val realChannelOverride: Int,
    private val holder: SurfaceHolder?,
) : FrameSource {
    private var sdkObj: HCNetSDK? = null
    private val sdk get() = sdkObj!!
    private val player get() = Player.getInstance()

    @Volatile private var running = false
    private var userId = -1
    private var playId = -1
    private var port = -1
    private var listener: FrameSource.Listener? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var gotHead = false
    @Volatile private var gotData = false
    @Volatile private var firstFrameLogged = false
    private var watchdog: Thread? = null
    private var yBuf = ByteArray(0)

    private fun info(m: String) { CamLog.i(m); listener?.onStatus(m) }
    private fun fail(m: String, t: Throwable? = null) { CamLog.e(m, t); listener?.onStatus("خطأ: $m") }

    private fun errName(code: Int) = when (code) {
        1 -> "كلمة المرور/المستخدم خاطئ"; 2 -> "صلاحيات غير كافية"; 3 -> "SDK غير مهيّأ"
        4 -> "رقم القناة خاطئ"; 5 -> "تجاوز عدد الاتصالات"; 6 -> "عدم توافق إصدار SDK مع الجهاز"
        7 -> "تعذّر الاتصال بالجهاز (IP/المنفذ/الشبكة)"; 8 -> "فشل الإرسال"; 9 -> "فشل الاستقبال"
        10 -> "انتهت مهلة الاستقبال"; 11 -> "بيانات خاطئة"; 17 -> "معامل خاطئ"; 23 -> "غير مدعوم"
        47 -> "المستخدم غير موجود"; 153 -> "الحساب مقفل (محاولات خاطئة كثيرة)"
        else -> "غير معروف"
    }
    private fun lastErr(): String { val c = sdk.NET_DVR_GetLastError(); return "رمز الخطأ $c (${errName(c)})" }

    override fun start(listener: FrameSource.Listener) {
        this.listener = listener
        running = true
        Thread({
            try { connect(listener) }
            catch (t: Throwable) {   // UnsatisfiedLinkError / NoSuchMethodError وغيرها: كانت تُسقط التطبيق بصمت
                fail("استثناء أثناء الاتصال (غالبًا مكتبات SDK .so أو نسخة jar لا تطابق)", t)
                listener.onDisconnected()
            }
        }, "hik-connect").start()
    }

    private fun connect(l: FrameSource.Listener) {
        CamLog.i("=== بدء الاتصال: $ip:8000 مستخدم=$user قناة=$channel بث=$streamType (CPU: ${android.os.Build.SUPPORTED_ABIS.joinToString()}) ===")
        sdkObj = HCNetSDK.getInstance()
            ?: run { fail("HCNetSDK.getInstance() أعادت null — مكتبات SDK لم تُحمَّل"); l.onDisconnected(); return }
        if (!sdk.NET_DVR_Init()) { fail("فشل NET_DVR_Init — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("NET_DVR_Init نجح")
        sdk.NET_DVR_SetConnectTime(5000)   // التوقيع في هذا الـ jar: (int) فقط
        sdk.NET_DVR_SetReconnect(10000, true)
        val dev = NET_DVR_DEVICEINFO_V30()
        userId = sdk.NET_DVR_Login_V30(ip, 8000, user, pass, dev)
        if (userId < 0) { fail("فشل تسجيل الدخول إلى $ip:8000 — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("تسجيل الدخول نجح userId=$userId — تناظرية=${dev.byChanNum} IP=${dev.byIPChanNum} " +
            "byStartChan=${dev.byStartChan} byStartDChan=${dev.byStartDChan}")
        // رقم القناة: تناظرية = byStartChan + n - 1، وإلا قنوات IP = byStartDChan + n - 1
        val real = when {
            realChannelOverride > 0 -> realChannelOverride
            dev.byChanNum.toInt() >= channel -> dev.byStartChan.toInt() + channel - 1
            else -> dev.byStartDChan.toInt() + channel - 1
        }
        info("تم الدخول. فتح القناة الفعلية $real (المطلوبة $channel) ...")
        sdk.NET_DVR_SetExceptionCallBack(ExceptionCallBack { type, handle, _ ->
            CamLog.e("استثناء SDK نوع=0x${Integer.toHexString(type)} handle=$handle — ${lastErr()}")
            l.onDisconnected()
        })

        val valid = holder?.surface?.isValid == true
        CamLog.i("سطح العرض لـ PlayM4: ${if (holder == null) "null" else if (valid) "صالح" else "غير صالح (لم يُنشأ بعد أو دُمّر)"}")

        val pi = NET_DVR_PREVIEWINFO()
        pi.lChannel = real
        pi.dwStreamType = streamType   // 0 رئيسي، 1 فرعي
        pi.dwLinkMode = 0              // TCP
        pi.bBlocked = 1
        val cb = RealPlayCallBack { _, dataType, data, size -> onRealData(dataType, data, size) }
        playId = sdk.NET_DVR_RealPlay_V40(userId, pi, cb)
        if (playId < 0) { fail("فشل NET_DVR_RealPlay_V40 للقناة $real — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("بدأ البث playId=$playId — بانتظار رأس النظام والبيانات")
        lastFrameMs = SystemClock.elapsedRealtime()
        watchdog = Thread({
            var alerted = false
            while (running) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread }
                val silent = SystemClock.elapsedRealtime() - lastFrameMs > 3000
                if (silent && !alerted) {
                    alerted = true
                    fail("لا إطارات منذ 3 ث — رأس النظام=${gotHead} بيانات=${gotData} منفذ PlayM4=$port")
                    l.onDisconnected()
                }
                if (!silent) alerted = false
            }
        }, "hik-watchdog").also { it.start() }
    }

    private fun onRealData(dataType: Int, data: ByteArray, size: Int) {
        try {
            when (dataType) {
                1 -> { // رأس النظام (NET_DVR_SYSHEAD)
                    gotHead = true
                    if (port != -1) return
                    CamLog.i("وصل رأس النظام ($size بايت)")
                    port = player.getPort()
                    if (port == -1) { fail("PlayM4.getPort: لا منفذ متاح"); return }
                    player.setStreamOpenMode(port, Player.STREAM_REALTIME)
                    if (!player.openStream(port, data, size, 4 * 1024 * 1024)) {
                        fail("PlayM4.openStream فشل: خطأ ${player.getLastError(port)}"); return
                    }
                    player.setDisplayCB(port, PlayerCallBack.PlayerDisplayCB { _, buf, _, w, h, _, _, _ ->
                        // YV12: أول w*h بايت هي قناة Y (سطوع)
                        val n = w * h
                        if (yBuf.size != n) yBuf = ByteArray(n)
                        System.arraycopy(buf, 0, yBuf, 0, n)
                        lastFrameMs = SystemClock.elapsedRealtime()
                        if (!firstFrameLogged) { firstFrameLogged = true; info("وصل أول إطار ${w}×${h}") }
                        listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
                    })
                    if (!player.play(port, holder)) fail("PlayM4.play فشل: خطأ ${player.getLastError(port)} (سطح صالح=${holder?.surface?.isValid})")
                    else CamLog.i("PlayM4.play نجح")
                }
                2 -> {
                    if (!gotData) { gotData = true; CamLog.i("وصلت أول بيانات بث ($size بايت)") }
                    if (port != -1 && !player.inputData(port, data, size)) {
                        CamLog.e("PlayM4.inputData فشل: خطأ ${player.getLastError(port)}")
                    }
                }
            }
        } catch (t: Throwable) { fail("استثناء في معالجة بيانات البث", t) }
    }

    override fun stop() {
        running = false
        try {
            watchdog?.interrupt()
            if (playId >= 0) sdk.NET_DVR_StopRealPlay(playId)
            if (port != -1) { player.stop(port); player.closeStream(port); player.freePort(port) }
            if (userId >= 0) sdk.NET_DVR_Logout_V30(userId)
            sdk.NET_DVR_Cleanup()
        } catch (_: Throwable) {}
        playId = -1; port = -1; userId = -1; gotHead = false; gotData = false; firstFrameLogged = false
        CamLog.i("تم إيقاف المصدر")
    }
}
