package com.smartwater.monitor

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import android.content.ClipData
import android.content.ClipboardManager
import android.view.SurfaceHolder
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.data.AppConfig
import com.smartwater.monitor.camera.HikSourceFactory
import com.smartwater.monitor.core.MeterConfig
import com.smartwater.monitor.core.SwingParams
import com.smartwater.monitor.data.EbsImport
import com.smartwater.monitor.data.SwingRecord
import com.smartwater.monitor.data.Truck
import com.smartwater.monitor.data.TruckInputError
import com.smartwater.monitor.engine.MonitorEngine
import com.smartwater.monitor.engine.FillStatus
import com.smartwater.monitor.engine.TruckCoordinator
import com.smartwater.monitor.engine.TruckPrompt
import com.smartwater.monitor.engine.UiState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

/** خمس شاشات: المراقبة، المعايرة، السجل، الوايتات، الإعدادات. الواجهة مبنية برمجيًا لتقليل أخطاء الموارد. */
class MainActivity : AppCompatActivity(), MonitorEngine.UiListener {
    private lateinit var engine: MonitorEngine
    private lateinit var content: FrameLayout
    private lateinit var tabViews: List<View>
    private lateinit var hikSurface: SurfaceView

    // --- المراقبة
    private lateinit var tvStatus: TextView
    private lateinit var etIp: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etChannel: EditText
    private lateinit var etStream: EditText
    private lateinit var etTruckCh: EditText
    private lateinit var cbAuto: CheckBox
    private lateinit var cbSeries: CheckBox
    private lateinit var etBpt: EditText
    private lateinit var rbOne: RadioButton
    private lateinit var rbTwo: RadioButton
    private lateinit var etZone: EditText
    private lateinit var tvFill: TextView
    private lateinit var monView: FrameView
    private lateinit var tvM1: TextView
    private lateinit var tvM2: TextView
    private lateinit var btnM2: Button
    private lateinit var tvSwing: TextView
    private lateinit var tvDay: TextView
    private lateinit var tvCamLog: TextView
    private lateinit var tvCustomer: TextView

    // --- المعايرة
    private lateinit var calView: FrameView
    private lateinit var tvCal: TextView
    private var draft: MutableList<MeterConfig> = mutableListOf()
    private var selected = 0
    private var tapMode = 0          // 0 محور، 1 حافة القرص
    private var zoom = true

    // --- السجل
    private lateinit var logBox: LinearLayout
    private lateinit var tvLogTotal: TextView

    // --- الوايتات
    private lateinit var truckBox: LinearLayout
    private val promptQueue = ArrayDeque<TruckPrompt>()
    private var promptDialog: AlertDialog? = null
    private var promptId = -1L

    private val exportCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { engine.db.exportCsv(it) }
                toast("تم تصدير السجل")
            } catch (e: Exception) { toast("فشل التصدير: ${e.message}") }
        }
    }
    private val pickEbs = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importEbs(uri) }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val app = application as App
        engine = app.engine
        draft = engine.cfg.meters.toMutableList()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        hikSurface = SurfaceView(this)
        // سطح غير مرئي (1×1) يحتاجه SDK لفتح المعاينة؛ الصورة الظاهرة في «المراقبة» تأتي من لقطات JPEG
        root.addView(hikSurface, LinearLayout.LayoutParams(1, 1))
        hikSurface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { CamLog.i("سطح PlayM4 أُنشئ") }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { CamLog.e("سطح PlayM4 دُمّر (التطبيق في الخلفية؟)") }
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("المراقبة", "المعايرة", "السجل", "الوايتات", "الإعدادات")
        tabViews = listOf(buildMonitor(), buildCalibration(), buildLog(), buildTrucks(), buildSettings())
        names.forEachIndexed { i, n ->
            tabs.addView(Button(this).apply { text = n; setOnClickListener { showTab(i) } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)
        tabViews.forEach { content.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        setContentView(root)
        showTab(0)
        if (!app.openCvReady) tvStatus.text = "تحذير: فشل تحميل OpenCV"
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (!HikSourceFactory.AVAILABLE) tvStatus.text = "Hikvision SDK غير مضمّن في هذا البناء — الاتصال بالكاميرا غير متاح"
    }

    override fun onStart() {
        super.onStart(); engine.uiListener = this; refreshLog(); refreshTrucks()
        // أسئلة «أي وايت هذا؟» التي وصلت والتطبيق في الخلفية
        val open = engine.truckFlow.openPrompts()
        promptQueue.removeAll { q -> open.none { it.episodeId == q.episodeId } }
        if (promptId != -1L && open.none { it.episodeId == promptId }) promptDialog?.dismiss()
        open.forEach { onTruckPrompt(it) }
        CamLog.onChange = { tvCamLog.text = CamLog.text().takeLast(6000) }
        CamLog.onChange?.invoke()
    }
    override fun onStop() { super.onStop(); if (engine.uiListener === this) engine.uiListener = null; CamLog.onChange = null }

    private fun showTab(i: Int) {
        tabViews.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        if (i == 1) { draft = engine.cfg.meters.toMutableList(); selected = selected.coerceAtMost(engine.cfg.meterCount - 1); btnM2.visibility = if (engine.cfg.meterCount >= 2) View.VISIBLE else View.GONE; refreshCal() }
        if (i == 2) refreshLog()
        if (i == 3) refreshTrucks()
    }

    // ================= المراقبة =================
    private fun buildMonitor(): View {
        val c = col()
        tvStatus = text("غير متصل")
        c.addView(tvStatus)
        c.addView(row(
            btn("اتصال بالكاميرا") { connectCamera() },
            btn("إيقاف") { stopMonitoring() },
        ))
        tvFill = text("").apply { textSize = 17f }
        c.addView(tvFill)
        monView = FrameView(this)
        c.addView(monView, LinearLayout.LayoutParams(-1, -2))
        tvCustomer = text("لا زفة جارية — الكمية المقاسة 0.00 برميل").apply { textSize = 20f }
        tvM1 = text("—"); tvM2 = text("—"); tvSwing = text("لا زفات بعد").apply { textSize = 18f }
        tvDay = text("")
        listOf(tvCustomer, tvM1, tvM2, tvSwing, tvDay).forEach { c.addView(it) }
        return scroll(c)
    }

    // ================= الإعدادات =================
    private fun buildSettings(): View {
        val c = col()
        val cfg = engine.cfg
        c.addView(text("الاتصال").apply { textSize = 20f })
        c.addView(text("المنفذ: 8000 (Hikvision SDK)"))
        etIp = edit("IP الكاميرا/الجهاز", cfg.ip)
        etUser = edit("اسم المستخدم", cfg.user)
        etPass = edit("كلمة المرور", cfg.pass).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        etChannel = edit("رقم قناة كاميرا العدّادات", cfg.channel.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        etStream = edit("نوع البث (0 رئيسي ، 1 فرعي)", cfg.streamType.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        listOf(etIp, etUser, etPass, etChannel, etStream).forEach { c.addView(it) }

        c.addView(text("العدّادات في كاميرا العدّادات").apply { textSize = 20f; setPadding(0, 24, 0, 0) })
        rbOne = RadioButton(this).apply { text = "عدّاد واحد"; id = View.generateViewId() }
        rbTwo = RadioButton(this).apply { text = "عدّادان"; id = View.generateViewId() }
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; addView(rbOne); addView(rbTwo) }
        (if (cfg.meterCount >= 2) rbTwo else rbOne).isChecked = true
        c.addView(rg)
        cbSeries = CheckBox(this).apply { text = "العدّادان يقيسان الماء نفسه (توصيل تسلسلي): لا يُجمعان، يُؤخذ الأكبر"; isChecked = cfg.wiring == 1 }
        c.addView(cbSeries)
        cbSeries.visibility = if (rbTwo.isChecked) View.VISIBLE else View.GONE
        rg.setOnCheckedChangeListener { _, _ -> cbSeries.visibility = if (rbTwo.isChecked) View.VISIBLE else View.GONE }
        c.addView(text("بعد تغيير العدد عايِر العدّادات من تبويب «المعايرة» ثم اتصل من جديد."))
        etBpt = edit("كم برميلًا في الدورة الكاملة للعقرب الكبير (الافتراضي 0.5)", fmtBpt(cfg.barrelsPerTurn))
            .apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        c.addView(etBpt)
        c.addView(text("مثال: 0.5 تعني أن كل دورة كاملة = نصف برميل (720° للبرميل). لو كان عدّادك يزيد عن قياسك فاحسب: القيمة الصحيحة = القيمة الحالية × (قياسك ÷ ما أظهره البرنامج). يُطبَّق على التعبئات الجديدة فقط."))

        c.addView(text("الوايتات وبقاؤها تحت القصبة").apply { textSize = 20f; setPadding(0, 24, 0, 0) })
        c.addView(text("لا يتوقف العدّ ما دام الوايت تحت القصبة: تُلتقط لقطة من قناة الوايتات كل ثانيتين، وتبقى الجلسة «توقف مؤقت» وتُستأنف في السجل نفسه عند عودة الماء."))
        etTruckCh = edit("قناة كاميرا الوايتات (0 = معطّل)", cfg.truckChannel.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        cbAuto = CheckBox(this).apply { text = "التعرّف التلقائي على الوايت من شكله ولونه"; isChecked = cfg.autoRecognize }
        etZone = edit("منطقة تحت القصبة: x,y,w,h بالنسبة المئوية (الافتراضي ${AppConfig.DEFAULT_ZONE})", cfg.truckZone)
        listOf(etTruckCh, cbAuto, etZone).forEach { c.addView(it) }
        c.addView(row(
            btn("تعيين خلفية القناة (المنطقة فارغة الآن)") { toast(if (engine.resetPresenceBackground()) "ستُعتمد لقطتها التالية خلفية فارغة" else "اتصل بالكاميرا أولًا") },
        ))

        c.addView(row(
            btn("حفظ الإعدادات") {
                engine.store.save(readConfigFields()); engine.cfg = engine.store.load()
                toast("حُفظت الإعدادات — تُطبَّق عند الاتصال التالي")
            },
            btn("إعدادات الزفات") { swingDialog() },
        ))

        c.addView(text("سجل الاتصال والأخطاء").apply { textSize = 20f; setPadding(0, 24, 0, 0) })
        tvCamLog = text("").apply { textSize = 11f; setTextIsSelectable(true) }
        c.addView(tvCamLog)
        c.addView(row(
            btn("نسخ السجل") {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("camlog", CamLog.text()))
                toast("نُسخ السجل")
            },
            btn("مسح السجل") { CamLog.clear() },
        ))
        return scroll(c)
    }

    private fun readConfigFields() = engine.cfg.copy(
        ip = etIp.text.toString().trim(), user = etUser.text.toString().trim(), pass = etPass.text.toString(),
        channel = etChannel.text.toString().toIntOrNull() ?: 4, streamType = etStream.text.toString().toIntOrNull() ?: 0,
        truckChannel = (etTruckCh.text.toString().toIntOrNull() ?: 7).coerceAtLeast(0), autoRecognize = cbAuto.isChecked,
        barrelsPerTurn = normNum(etBpt.text.toString()).toDoubleOrNull()?.takeIf { it in 0.01..10.0 } ?: engine.cfg.barrelsPerTurn,
        meterCount = if (rbTwo.isChecked) 2 else 1, wiring = if (cbSeries.isChecked) 1 else 0,
        truckZone = etZone.text.toString().trim().ifBlank { AppConfig.DEFAULT_ZONE },
    )

    private fun connectCamera() {
        engine.store.save(readConfigFields()); engine.cfg = engine.store.load()
        MonitorService.start(this)
        engine.startCamera(hikSurface.holder)
        askBatteryExemption()
    }

    private var askedBattery = false

    /** بدون استثناء من توفير البطارية قد يعلّق النظام الشبكة عند إطفاء الشاشة (Doze) فيتوقف العد رغم الخدمة. */
    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (askedBattery || pm.isIgnoringBatteryOptimizations(packageName)) return
        askedBattery = true
        AlertDialog.Builder(this).setTitle("استمرار العدّ في الخلفية")
            .setMessage("لتستمر المراقبة بعد إغلاق التطبيق أو إطفاء الشاشة اسمح للتطبيق بتجاوز توفير البطارية. بدون ذلك قد يوقف النظام الشبكة ويتأخر العدّ.")
            .setPositiveButton("السماح") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName"))) }
                catch (e: Exception) { toast("افتح إعدادات البطارية للتطبيق وفعّل «بلا قيود»") }
            }.setNegativeButton("لاحقًا", null).show()
    }

    private fun stopMonitoring() { engine.stop(); MonitorService.stop(this) }

    override fun onStatus(msg: String) { tvStatus.text = msg }

    override fun onSwing(text: String) {
        tvSwing.text = text
        refreshLog()
    }

    override fun onState(s: UiState) {
        val fmt = { m: com.smartwater.monitor.engine.MeterState ->
            "${m.name}: " + (if (!m.valid) "لا قياس (ليس توقفًا) — " else "") +
                (if (m.active) "يتحرك" else "ساكن") +
                " — %.2f برميل".format(Locale.US, m.episodeDeg / engine.cfg.degPerBarrel) +
                "\n   الزاوية %.0f°".format(Locale.US, m.rawAngle)
        }
        if (s.meters.isNotEmpty()) tvM1.text = fmt(s.meters[0])
        tvM2.visibility = if (s.meters.size >= 2) View.VISIBLE else View.GONE
        if (s.meters.size >= 2) tvM2.text = fmt(s.meters[1])
        val bmp = engine.latestBitmap(1000)
        if (bmp != null && s.frameW > 0) {
            monView.bitmap = bmp
            monView.region = floatArrayOf(0f, 0f, s.frameW.toFloat(), s.frameH.toFloat())
            monView.meters = engine.cfg.activeMeters
            monView.rawAngles = DoubleArray(s.meters.size) { s.meters[it].rawAngle }
            monView.shifts = s.meters.map { Pair(it.shiftX, it.shiftY) }
            monView.requestLayout(); monView.invalidate()
        }
        if (s.running || s.connected) tvStatus.text =
            (if (s.connected) "متصل" else "انقطع البث — لا يُحتسب توقفًا") + " — %.1f إطار/ث".format(Locale.US, s.fps)
        // شاشة المعايرة: خطوط العقرب الحية فوق اللقطة
        calView.rawAngles = DoubleArray(s.meters.size) { s.meters[it].rawAngle }
        tvCal.text = s.meters.joinToString("\n") {
            "%s: زاوية %.1f° | مجموع %.1f° = %.3f برميل | تباين %.3f | إزاحة (%.1f, %.1f)".format(
                Locale.US, it.name, it.rawAngle, it.totalDeg, it.totalDeg / engine.cfg.degPerBarrel, it.contrast, it.shiftX, it.shiftY)
        }
    }

    // ================= المعايرة والتحقق =================
    private fun buildCalibration(): View {
        val c = col()
        c.addView(text("1) اتصل بالكاميرا ثم اضغط «التقاط من البث».  2) اختر العدّاد، ثم المس منتصف محور العقرب الكبير السفلي، ثم حافة القرص الصغير الذي يدور فيه." +
            "  3) احفظ.  الدائرتان الصفراوان تحددان حلقة البحث عن العقرب، ويجب أن تقعا فوق جسم العقرب لا فوق أرقام القرص."))
        c.addView(row(
            btn("التقاط من البث") {
                if (engine.setStillFromLatest()) refreshCal() else toast("لا يوجد بث حاليًا")
            },
        ))
        btnM2 = btn("العداد 2") { selected = 1; refreshCal() }
        c.addView(row(
            btn("العداد 1") { selected = 0; refreshCal() },
            btnM2,
            btn("تكبير/تصغير") { zoom = !zoom; refreshCal() },
        ))
        c.addView(row(
            btn("لمس = المحور") { tapMode = 0; toast("المس منتصف محور العقرب") },
            btn("لمس = الحافة") { tapMode = 1; toast("المس حافة القرص الصغير") },
            btn("−") { adjustRadius(-1.0) },
            btn("+") { adjustRadius(1.0) },
        ))
        calView = FrameView(this)
        calView.onTap = { fx, fy -> onCalTap(fx, fy) }
        c.addView(calView, LinearLayout.LayoutParams(-1, -2))
        tvCal = text("")
        c.addView(tvCal)
        c.addView(text("التحقق: راقب «المجموع» على البث الحي. كل دورة كاملة للعقرب يجب أن تزيد المجموع 360° (±3°) = "+ fmtBpt(engine.cfg.barrelsPerTurn) + " برميل بحسب إعداد «براميل الدورة الكاملة»."))
        c.addView(row(btn("حفظ المعايرة") { saveCalibration() }))
        return scroll(c)
    }

    /** المعايرة تُحرَّر على العدّادات الفعّالة فقط (الثاني مخفي إن كان العدّاد واحدًا وتبقى معايرته محفوظة). */
    private fun activeDraft() = draft.take(engine.cfg.meterCount.coerceIn(1, draft.size))

    private fun adjustRadius(d: Double) {
        val m = draft[selected]; draft[selected] = m.copy(radius = (m.radius + d).coerceAtLeast(10.0)); refreshCal()
    }

    private fun onCalTap(fx: Double, fy: Double) {
        val m = draft[selected]
        draft[selected] = if (tapMode == 0) m.copy(cx = fx, cy = fy)
        else m.copy(radius = hypot(fx - m.cx, fy - m.cy).coerceAtLeast(10.0))
        calView.meters = activeDraft()
        calView.invalidate()
    }

    private fun refreshCal() {
        selected = selected.coerceIn(0, activeDraft().size - 1)
        calView.selected = selected
        calView.meters = activeDraft()
        if (engine.stillWidth == 0) { calView.bitmap = null; calView.invalidate(); return }
        val m = draft[selected]
        val (x0, y0, x1, y1) = if (zoom) {
            val h = m.radius * 2.4
            listOf(m.cx - h, m.cy - h, m.cx + h, m.cy + h)
        } else listOf(0.0, 0.0, engine.stillWidth.toDouble(), engine.stillHeight.toDouble())
        val r = engine.stillBitmap(x0, y0, x1, y1, 1400) ?: return
        calView.bitmap = r.first
        calView.region = r.second
        calView.requestLayout(); calView.invalidate()
    }

    private fun saveCalibration() {
        val err = try { engine.saveCalibration(engine.cfg.copy(meters = draft.toList())) }
        catch (t: Throwable) { CamLog.e("حفظ المعايرة", t); "تعذّر الحفظ: ${t.message}" }
        toast(err ?: "حُفظت المعايرة (المواضع + مرجع تعويض الاهتزاز). تُطبَّق عند الاتصال التالي، وتبقى بعد إغلاق التطبيق")
    }

    private fun swingDialog() {
        val s = engine.cfg.swing
        val fields = listOf(
            "حركة حقيقية: أقل تقدّم لبدء الزفة (°)" to s.startDeg,
            "نافذة البدء (ث)" to s.startWindowSec,
            "التوقف: تقدّم أقل من (°)" to s.stopDeg,
            "التوقف: خلال (ث)" to s.stopWindowSec,
            "أقل زفة تُسجَّل (°)" to s.minSwingDeg,
        )
        val box = col()
        val edits = fields.map { (label, v) ->
            box.addView(text(label))
            edit(label, v.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }.also { box.addView(it) }
        }
        AlertDialog.Builder(this).setTitle("إعدادات الزفات").setView(scroll(box))
            .setPositiveButton("حفظ") { _, _ ->
                fun v(i: Int, d: Double) = edits[i].text.toString().toDoubleOrNull() ?: d
                val n = SwingParams(
                    startDeg = v(0, s.startDeg), startWindowSec = v(1, s.startWindowSec),
                    stopDeg = v(2, s.stopDeg), stopWindowSec = v(3, s.stopWindowSec),
                    minSwingDeg = v(4, s.minSwingDeg), endToleranceSec = s.endToleranceSec,
                    minOverlapSec = s.minOverlapSec, gapSec = s.gapSec,
                )
                engine.store.save(engine.cfg.copy(swing = n)); engine.cfg = engine.store.load()
            }.setNegativeButton("إلغاء", null).show()
    }

    // ================= السجل =================
    private fun buildLog(): View {
        val c = col()
        tvLogTotal = text("").apply { textSize = 20f }
        c.addView(tvLogTotal)
        c.addView(row(
            btn("تصدير CSV") {
                exportCsv.launch("water_log_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv")
            },
            btn("تحديث") { refreshLog() },
            btn("حذف السجل") {
                AlertDialog.Builder(this).setMessage("حذف كل الزفات المسجلة؟")
                    .setPositiveButton("حذف") { _, _ -> engine.db.clear(); refreshLog() }
                    .setNegativeButton("إلغاء", null).show()
            },
        ))
        logBox = col()
        c.addView(logBox)
        return scroll(c)
    }

    private fun refreshLog() {
        if (!::logBox.isInitialized) return
        val today = engine.db.today()
        val total = engine.db.dayTotal(today)
        val txt = "إجمالي براميل اليوم ($today): %.2f".format(Locale.US, total)
        tvLogTotal.text = txt
        tvDay.text = txt
        logBox.removeAllViews()
        val tf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        var thumbs = 0
        for (r in engine.db.query(null).take(300)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
            row.addView(text(
                "#${r.seq} (${r.day}) — ${r.typeAr}\n" +
                    "${tf.format(Date(r.startMs))}  →  ${tf.format(Date(r.endMs))}\n" +
                    "العداد 1: %.2f | العداد 2: %.2f | الإجمالي: %.2f برميل".format(Locale.US, r.m1Barrels, r.m2Barrels, r.total) +
                    (if (r.truckName.isNotEmpty()) "\nالوايت: ${r.truckName} (المقاس بالعدّادات: %.2f برميل)".format(Locale.US, r.measured)
                    else if (r.photo.isNotEmpty()) "\nالوايت: لم يُحدَّد بعد" else "") +
                    (if (r.notes.isNotEmpty()) "\n⚠ ${r.notes}" else "")
            ))
            if (r.photo.isNotEmpty() && thumbs < 40) {
                val bmp = loadBitmap(r.photo, 360)
                if (bmp != null) {
                    thumbs++
                    row.addView(ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_START },
                        LinearLayout.LayoutParams(360, -2))
                }
            }
            row.addView(btn(if (r.truckId == null) "ربط وايت" else "تغيير الوايت") { chooseTruckForRecord(r) })
            logBox.addView(row)
        }
    }

    private fun chooseTruckForRecord(r: SwingRecord) {
        fun assign(t: Truck) = engine.truckFlow.assignRecord(r.id, t.id) { msg -> toast(msg); refreshLog(); refreshTrucks() }
        val list = engine.trucks.list()
        if (list.isEmpty()) { toast("لا أسماء محفوظة — أضف وايتًا جديدًا"); truckDialog(null) { assign(it) }; return }
        val labels = list.map { "${it.name} — ${fmtQty(it.capacity)} برميل" } + "➕ وايت جديد"
        AlertDialog.Builder(this).setTitle("أي وايت هذا؟")
            .setItems(labels.toTypedArray()) { _, i -> if (i < list.size) assign(list[i]) else truckDialog(null) { assign(it) } }
            .setNegativeButton("إلغاء", null).show()
    }

    // ================= الوايتات =================
    private fun buildTrucks(): View {
        val c = col()
        c.addView(text("قائمة الوايتات: أضف اسم كل وايت وكميته الكاملة بالبراميل مسبقًا. عند بدء حركة أي عدّاد تُلتقط صورة الوايت من قناة الوايتات " +
            "(الافتراضية 7) ويُسألك التطبيق «أي وايت هذا؟»؛ وتُسجَّل الزفة بكمية الوايت المدخلة. كلما اخترتَ وايتًا زادت صوره المحفوظة فيتعرّف عليه تلقائيًا لاحقًا."))
        c.addView(row(
            btn("➕ إضافة وايت") { truckDialog(null) { refreshTrucks() } },
            btn("📥 استيراد من نسخة EBS") { pickEbs.launch(arrayOf("*/*")) },
        ))
        truckBox = col()
        c.addView(truckBox)
        return scroll(c)
    }

    private fun refreshTrucks() {
        if (!::truckBox.isInitialized) return
        truckBox.removeAllViews()
        val list = engine.trucks.list()
        if (list.isEmpty()) truckBox.addView(text("لا وايتات محفوظة بعد"))
        for (t in list) {
            truckBox.addView(text("${t.name} — ${fmtQty(t.capacity)} برميل — صور التعرّف: ${t.photos}").apply { textSize = 17f; setPadding(0, 16, 0, 0) })
            truckBox.addView(row(
                btn("تعديل") { truckDialog(t) { refreshTrucks(); refreshLog() } },
                btn("حذف") {
                    AlertDialog.Builder(this).setMessage("حذف الوايت «${t.name}» وصور التعرّف الخاصة به؟ (تبقى سجلات زفاته القديمة بالاسم)")
                        .setPositiveButton("حذف") { _, _ -> engine.trucks.delete(t.id); engine.truckFlow.deleted(t.id); refreshTrucks(); refreshLog() }
                        .setNegativeButton("إلغاء", null).show()
                },
            ))
        }
    }

    /** إضافة/تعديل وايت. النافذة تبقى مفتوحة عند خطأ إدخال (اسم فارغ/مكرر، كمية غير صالحة). */
    private fun truckDialog(existing: Truck?, onSaved: (Truck) -> Unit) {
        val box = col()
        val etName = edit("اسم الوايت", existing?.name ?: "")
        val etQty = edit("الكمية الكاملة بالبراميل", existing?.let { fmtQty(it.capacity) } ?: "")
            .apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        box.addView(text("الاسم")); box.addView(etName)
        box.addView(text("الكمية الكاملة (براميل)")); box.addView(etQty)
        if (existing != null) box.addView(text("تغيير الكمية يسري على الزفات القادمة فقط."))
        val dlg = AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة وايت" else "تعديل وايت")
            .setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val q = normNum(etQty.text.toString()).toDoubleOrNull() ?: Double.NaN
                try {
                    val t = if (existing == null) engine.trucks.add(etName.text.toString(), q)
                    else engine.trucks.update(existing.id, etName.text.toString(), q).also { engine.truckFlow.renamed(it) }
                    dlg.dismiss(); onSaved(t)
                } catch (e: TruckInputError) { toast(e.message ?: "إدخال غير صالح") }
            }
        }
        dlg.show()
    }

    /** استيراد الأسماء من نسخة EBS (.db): معاينة بقائمة تحديد، والأسماء الموجودة تُتخطّى. */
    private fun importEbs(uri: Uri) {
        toast("جارٍ قراءة النسخة ...")
        Thread {
            val res = try {
                val tmp = File(cacheDir, "ebs_import.db")
                contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } } ?: throw TruckInputError("تعذّر قراءة الملف")
                try { EbsImport.read(tmp, engine.trucks.list().map { it.name }.toSet()) } finally { tmp.delete() }
            } catch (e: TruckInputError) { runOnUiThread { toast(e.message ?: "فشل") }; return@Thread }
            catch (e: Throwable) { CamLog.e("استيراد EBS", e); runOnUiThread { toast("فشل الاستيراد: ${e.message}") }; return@Thread }
            runOnUiThread { showEbsPreview(res) }
        }.start()
    }

    private fun showEbsPreview(res: com.smartwater.monitor.data.EbsImportResult) {
        val list = res.candidates
        if (list.isEmpty()) { toast("لا أسماء لها فواتير في هذه النسخة"); return }
        val labels = list.map { "${it.name} — ${fmtQty(it.capacity)} برميل (${it.invoices} فاتورة)" + if (it.exists) " — موجود" else "" }.toTypedArray()
        val checked = BooleanArray(list.size) { !list[it].exists }
        AlertDialog.Builder(this)
            .setTitle("استيراد الوايتات (${list.size} اسم؛ ${res.customersWithoutInvoices} عميلًا بلا فواتير لم يُعرَض)")
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("استيراد المحدّد") { _, _ ->
                var added = 0; var skipped = 0
                list.forEachIndexed { i, c ->
                    if (checked[i]) try { engine.trucks.add(c.name, c.capacity); added++ } catch (e: TruckInputError) { skipped++ }
                }
                toast("أُضيف $added وايت" + (if (skipped > 0) " وتُخطّي $skipped (مكرر/غير صالح)" else "") + " — الكميات مقترحة من الفواتير، عدّلها إن لزم")
                refreshTrucks()
            }.setNegativeButton("إلغاء", null).show()
    }

    // ---- «أي وايت هذا؟»
    override fun onTruckPrompt(p: TruckPrompt) {
        if (p.episodeId == promptId || promptQueue.any { it.episodeId == p.episodeId }) return
        promptQueue.addLast(p)
        showNextPrompt()
    }

    override fun onTruckPromptClosed(episodeId: Long) {
        promptQueue.removeAll { it.episodeId == episodeId }
        if (promptId == episodeId) promptDialog?.dismiss()
    }

    override fun onTruckInfo(msg: String) { toast(msg) }

    private val hms = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** حالة التعبئة: الحالة، الوايت، الكمية التراكمية لكل عدّاد، مهلة الدقيقة. */
    override fun onFill(s: FillStatus) {
        val names = engine.cfg.activeMeters.map { it.name }
        val sb = StringBuilder("الحالة: ${s.label}")
        if (s.truckName.isNotEmpty()) sb.append("\nالوايت: ${s.truckName}")
        if (s.total > 0.0) {
            sb.append("\nالكمية التراكمية (مقاسة): %.2f برميل".format(Locale.US, s.total))
            if (s.perMeter.size > 1) s.perMeter.forEachIndexed { i, b -> sb.append("\n  • ${names.getOrElse(i) { "عداد ${i + 1}" }}: %.2f".format(Locale.US, b)) }
        }
        s.graceRemainingSec?.let { sb.append("\nمتبقٍ من مهلة الدقيقة: ${it.toInt()} ث") }
        if (s.note.isNotEmpty()) sb.append("\n⚠ ${s.note}")
        tvFill.text = sb.toString()
        tvCustomer.text = "الكمية المقاسة للزبون الحالي: %.2f برميل".format(Locale.US, s.total)
    }

    private fun showNextPrompt() {
        if (promptDialog != null || promptQueue.isEmpty() || isFinishing) return
        val p = promptQueue.removeFirst()
        promptId = p.episodeId
        val box = col()
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        if (p.note.isNotEmpty()) box.addView(text(p.note))
        val photo = p.photoPath?.let { loadBitmap(it, 1200) }
        if (photo != null) box.addView(ImageView(this).apply { setImageBitmap(photo); adjustViewBounds = true }, LinearLayout.LayoutParams(-1, -2))
        else box.addView(text("لا توجد صورة لهذه الزفة"))
        if (p.trucks.isEmpty()) box.addView(text("لا أسماء محفوظة — أضف وايتًا جديدًا."))
        lateinit var dlg: AlertDialog
        for (t in p.trucks) box.addView(btn("${t.name} — ${fmtQty(t.capacity)} برميل") {
            engine.truckFlow.choose(p.episodeId, t.id); dlg.dismiss()
        })
        box.addView(btn("➕ وايت جديد (غير موجود في القائمة)") {
            truckDialog(null) { nt -> engine.truckFlow.choose(p.episodeId, nt.id); dlg.dismiss() }
        })
        box.addView(btn("لاحقًا (أربطه من السجل)") { engine.truckFlow.dismiss(p.episodeId); dlg.dismiss() })
        dlg = AlertDialog.Builder(this).setTitle("أي وايت هذا؟").setView(scroll(box)).setCancelable(false).create()
        dlg.setOnDismissListener { promptDialog = null; promptId = -1L; showNextPrompt() }
        promptDialog = dlg
        dlg.show()
    }

    private fun loadBitmap(path: String, maxW: Int): Bitmap? = try {
        val f = File(path)
        if (!f.exists()) null else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var sample = 1
            while (o.outWidth > 0 && o.outWidth / (sample * 2) >= maxW) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    } catch (_: Throwable) { null }

    private fun fmtBpt(d: Double) = ((d * 10000).toLong() / 10000.0).toString().removeSuffix(".0")

    private fun fmtQty(d: Double) = if (d == Math.floor(d)) d.toLong().toString() else "%.2f".format(Locale.US, d)

    /** أرقام عربية/فاصلة عربية → أرقام لاتينية قبل التحويل. */
    private fun normNum(s: String): String = s.trim().map {
        when (it) { in '٠'..'٩' -> '0' + (it - '٠'); '٫', '،', ',' -> '.'; else -> it }
    }.joinToString("")

    // ================= أدوات واجهة =================
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
    private fun scroll(v: View) = ScrollView(this).apply { addView(v, ViewGroup.LayoutParams(-1, -2)) }
    private fun text(s: String) = TextView(this).apply { text = s; textSize = 15f; setPadding(0, 6, 0, 6) }
    private fun edit(hint: String, v: String) = EditText(this).apply { this.hint = hint; setText(v); setSingleLine() }
    private fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
    }
}
