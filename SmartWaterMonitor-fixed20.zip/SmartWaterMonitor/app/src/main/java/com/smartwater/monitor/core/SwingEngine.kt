package com.smartwater.monitor.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class SwingType { METER, FULL }

/** كل دورة كاملة للعقرب (360°) = نصف برميل، أي 720° = برميل واحد. */
const val DEG_PER_BARREL = 720.0

class MeterPart(
    val meter: Int,
    val degrees: Double,
    val startT: Double,
    val endT: Double,
    /** درجات العقرب لكل برميل (الافتراضي 720°: الدورة الكاملة = نصف برميل). يضبطها المستخدم من الإعدادات. */
    val degPerBarrel: Double = DEG_PER_BARREL,
) {
    val barrels: Double get() = degrees / degPerBarrel
}

class SwingResult(
    val type: SwingType,
    val parts: List<MeterPart>,
    val notes: String,
    /** إن وُجدت فهي الإجمالي المعتمد بدل مجموع العدّادين (عدّادان على الماء نفسه). */
    val totalOverride: Double? = null,
) {
    val startT: Double get() = parts.minOf { it.startT }
    val endT: Double get() = parts.maxOf { it.endT }
    val totalBarrels: Double get() = totalOverride ?: parts.sumOf { it.barrels }
}

data class SwingParams(
    val startDeg: Double = 6.0,        // حركة حقيقية: تقدّم ≥ هذا خلال startWindowSec
    val startWindowSec: Double = 2.0,
    val stopDeg: Double = 3.0,         // التوقف: تقدّم < هذا خلال stopWindowSec
    val stopWindowSec: Double = 3.0,
    val minSwingDeg: Double = 20.0,    // أقل من هذا يُعدّ اهتزازًا لا زفة
    val endToleranceSec: Double = 3.0, // لم يعد مستخدمًا؛ يبقى فقط لتوافق الإعدادات المحفوظة سابقًا
    val minOverlapSec: Double = 1.0,
    val gapSec: Double = 1.5,          // فاصل بين عيّنتين أطول من هذا = انقطاع (ليس توقفًا)
    /**
     * مهلة التوقف قبل اعتماد نهاية الزبون (0 = السلوك القديم: تُسجَّل الزفة فور سكون العدّادين).
     * إن كانت > 0 فلا تُسجَّل الزفة إلا بعد هذه المدة من الملاحَظ (لا من الغياب) بلا أي حركة؛ فإن عادت الحركة قبلها
     * تستمر الحلقة نفسها دون تصفير، وتُحسب نهاية الزفة عند آخر حركة فعلية لا عند نهاية المهلة.
     */
    val resolveGraceSec: Double = 0.0,
    /** درجات العقرب لكل برميل؛ تُنقل من إعداد «براميل الدورة الكاملة» (لا تُحفظ مع إعدادات الزفات). */
    val degPerBarrel: Double = DEG_PER_BARREL,
)

/**
 * آلة حالات الزفات.
 *  - لا تبدأ حركة عدّاد إلا بعد تقدّم ≥ startDeg (حركة حقيقية)، وتُحسب من نقطة السكون السابقة.
 *  - يتوقف العدّاد فقط بعد stopWindowSec من العيّنات *المرصودة* بلا تقدّم؛
 *    انقطاع البث أو فقدان التتبع يوقف الساعة ولا يُحسب توقفًا.
 *  - لا يعبّئ زبونان في وقت واحد: الحلقة (episode) = زبون واحد، تبدأ بأول حركة وتنتهي حين يسكن كل العدّادين
 *    (فيتصفّر عدّاد الزبون). إن تحرّك عدّاد واحد فقط = "زفة عداد"، وإن تحرّك العدّادان (متداخلين أو متتابعين
 *    داخل الحلقة) = "زفة كاملة" إجماليها مجموع العدّادين ولو توقف أحدهما قبل الآخر.
 */
class SwingEngine(
    private val meters: Int,
    private val p: SwingParams = SwingParams(),
    private val onResult: (SwingResult) -> Unit,
) {
    private class MS {
        var active = false
        var sa = Double.NaN; var st = 0.0          // مرساة البداية (وضع الخمول)
        var rise = Double.NaN                      // أول لحظة ارتفعت فيها الزاوية عن المرساة (بداية الحركة بدقة الإطار)
        var startA = 0.0; var startT = 0.0
        var xa = 0.0; var xt = 0.0                 // مرساة التوقف (وضع الحركة)
        var lastA = Double.NaN; var lastT = 0.0
        var pendingGap = false
        var uncertain = false
    }

    private class Seg(val meter: Int, val startT: Double, val endT: Double, val deg: Double, val uncertain: Boolean, val truncated: Boolean)

    private companion object { const val RISE_DEG = 0.5 }
    private val ms = Array(meters) { MS() }
    private val finished = ArrayList<Seg>()
    var ignoredBlips = 0
        private set

    /** تُستدعى عند بدء حلقة زبون جديدة: أول حركة حقيقية لأي من العدّادين (t = زمن الإطار بالثواني). */
    var onEpisodeStart: ((Double) -> Unit)? = null
    /** تُستدعى إن انتهت الحلقة دون زفة تُسجَّل (اهتزاز أقل من الحد الأدنى). */
    var onEpisodeCancel: (() -> Unit)? = null
    private var episodeOpen = false
    private var quiet = false
    private var graceElapsed = 0.0
    private var prevT = Double.NaN

    /** الثواني المتبقية من مهلة التوقف (null إن لم نكن في انتظارها). */
    fun graceRemaining(): Double? =
        if (p.resolveGraceSec > 0.0 && quiet && finished.isNotEmpty()) (p.resolveGraceSec - graceElapsed).coerceAtLeast(0.0) else null

    /** آخر لحظة حركة فعلية في الحلقة الجارية (للعرض)، أو null. */
    fun lastMotionT(): Double? = finished.maxOfOrNull { it.endT }

    fun isEpisodeOpen() = episodeOpen

    /** بداية أول حركة فعلية في الحلقة الجارية (سكون العدّاد السابق لا لحظة الاكتشاف)، أو null. */
    fun firstMotionT(): Double? {
        var r: Double? = null
        for (s in finished) r = minOf(r ?: s.startT, s.startT)
        for (m in ms) if (m.active) r = minOf(r ?: m.startT, m.startT)
        return r
    }

    fun isActive(i: Int) = ms[i].active

    /** درجات الزفة الجارية لهذا العدّاد (0 إن كان ساكنًا). */
    fun currentDegrees(i: Int): Double = if (ms[i].active) ms[i].lastA - ms[i].startA else 0.0

    /** درجات الزبون الحالي لهذا العدّاد: ما أنهاه في الحلقة الجارية + حركته الآن. تتصفّر عند انتهاء الحلقة. */
    fun episodeDegrees(i: Int): Double = finished.filter { it.meter == i }.sumOf { it.deg } + currentDegrees(i)

    /** تُستدعى لكل إطار؛ العنصر null أو غير صالح = لا قياس (لا يُعدّ توقفًا). */
    fun update(t: Double, samples: List<MeterSample?>) {
        val dt = if (prevT.isNaN()) 0.0 else t - prevT
        prevT = t
        for (i in 0 until meters) step(i, t, samples.getOrNull(i))
        if (!episodeOpen && ms.any { it.active }) { episodeOpen = true; onEpisodeStart?.invoke(t) }
        if (ms.any { it.active }) { quiet = false; graceElapsed = 0.0; return }
        if (p.resolveGraceSec <= 0.0) { endEpisode(); return }
        // وضع المهلة: الساعة تعدّ الوقت *المرصود* فقط؛ غياب الإطارات/التسجيل لا يُحتسب توقفًا
        if (finished.isEmpty()) {
            quiet = false
            if (episodeOpen) { episodeOpen = false; onEpisodeCancel?.invoke() }
            return
        }
        if (!quiet) { quiet = true; graceElapsed = (t - finished.maxOf { it.endT }).coerceAtLeast(0.0) }
        else if (dt > 0.0 && samples.any { it?.valid == true }) graceElapsed += min(dt, p.gapSec)
        if (graceElapsed >= p.resolveGraceSec) resolve()
    }

    /** كل العدّادين ساكنان: تُسجَّل الزفة إن وُجدت حركة معتبرة، وإلا تُلغى الحلقة. */
    private fun endEpisode() {
        if (finished.isNotEmpty()) resolve()
        else if (episodeOpen) { episodeOpen = false; onEpisodeCancel?.invoke() }
    }

    /** إشعار صريح بانقطاع البث. */
    fun markGap() { ms.forEach { it.pendingGap = true } }

    /** نهاية الجلسة/الفيديو: تُغلق الحركات الجارية وتُسجَّل مع ملاحظة. */
    fun flush() {
        for (i in 0 until meters) {
            val m = ms[i]
            if (m.active) close(i, m, m.lastA, m.xt.coerceAtLeast(m.lastT), "انتهى البث أثناء الحركة")
        }
        endEpisode()
    }

    private fun step(i: Int, t: Double, s: MeterSample?) {
        val m = ms[i]
        if (s == null || !s.valid) { m.pendingGap = true; return }
        val a = s.angleDeg
        if (m.lastA.isNaN()) { m.sa = a; m.st = t; m.rise = Double.NaN; m.lastA = a; m.lastT = t; return }
        val gap = m.pendingGap || (t - m.lastT) > p.gapSec
        if (s.uncertainJump) m.uncertain = true
        m.pendingGap = false

        if (!m.active) {
            if (m.rise.isNaN() && a - m.sa > RISE_DEG) m.rise = t
            if (a - m.sa >= p.startDeg) {
                m.active = true
                // الدرجات تُحسب من المرساة (فلا يضيع شيء)، أما زمن البداية فهو أول ارتفاع فعلي لا بداية نافذة السكون
                m.startA = m.sa; m.startT = if (m.rise.isNaN()) m.st else m.rise
                m.xa = a; m.xt = t
                m.uncertain = s.uncertainJump || gap
            } else if (t - m.st >= p.startWindowSec || gap) {
                m.sa = a; m.st = t; m.rise = Double.NaN
            }
        } else {
            if (a - m.xa >= p.stopDeg) {
                m.xa = a; m.xt = t
            } else if (gap) {
                // لا نحتسب الغياب سكونًا: نعيد تشغيل ساعة السكون من أول عيّنة بعد الانقطاع
                m.xa = a; m.xt = t
            } else if (t - m.xt >= p.stopWindowSec) {
                close(i, m, a, m.xt, "")
            }
        }
        m.lastA = a; m.lastT = t
    }

    private fun close(i: Int, m: MS, endA: Double, endT: Double, note: String) {
        val deg = endA - m.startA
        if (deg < p.minSwingDeg) ignoredBlips++
        else finished.add(Seg(i, m.startT, endT, deg, m.uncertain, note.isNotEmpty()))
        m.active = false
        m.sa = m.lastA; m.st = m.lastT; m.rise = Double.NaN
        m.uncertain = false
    }

    private fun resolve() {
        val segs = finished.sortedBy { it.startT }
        finished.clear()
        episodeOpen = false; quiet = false; graceElapsed = 0.0
        // حلقة واحدة = زبون واحد: نجمع درجات كل عدّاد داخلها
        val parts = segs.groupBy { it.meter }.toSortedMap().map { (meter, l) ->
            MeterPart(meter, l.sumOf { it.deg }, l.minOf { it.startT }, l.maxOf { it.endT }, p.degPerBarrel)
        }
        val type = if (parts.size >= 2) SwingType.FULL else SwingType.METER
        onResult(SwingResult(type, parts, noteOf(segs)))
    }

    private fun noteOf(l: List<Seg>): String {
        val n = ArrayList<String>()
        if (l.any { it.truncated }) n.add("انتهى البث أثناء الحركة (زفة غير مكتملة)")
        if (l.any { it.uncertain }) n.add("تحتوي فجوة/فقدان تتبع — الكمية تقريبية")
        return n.joinToString("؛ ")
    }
}
