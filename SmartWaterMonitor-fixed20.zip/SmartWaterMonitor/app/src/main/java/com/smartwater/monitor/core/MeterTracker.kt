package com.smartwater.monitor.core

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** معايرة عدّاد واحد (إحداثيات الإطار الكامل بالبكسل). */
data class MeterConfig(
    val name: String,
    val cx: Double,      // محور دوران العقرب الكبير السفلي
    val cy: Double,
    val radius: Double,  // نصف قطر قرص العدّاد الصغير الذي يدور فيه العقرب
)

data class TrackerParams(
    val bandInner: Double = 0.33,   // حلقة البحث عن العقرب (كسر من R) — خارج كتلة المحور
    val bandOuter: Double = 0.52,   // وقبل علامات الأرقام عند ~0.65R
    val smoothDeg: Int = 15,
    val minContrast: Double = 0.025, // أقل تباين مقبول للعقرب أثناء التتبع
    val lockContrast: Double = 0.05, // أقل تباين للالتقاط الأول/البحث الواسع بعد فقدان
    val maxDegPerSec: Double = 900.0,   // يُستخدم فقط للبحث الواسع بعد انقطاع طويل
    val baseFwdDeg: Double = 12.0,      // هامش أمامي ثابت لنافذة التنبؤ
    val accelFactor: Double = 3.0,      // هامش التسارع: نضرب السرعة المقدّرة × dt × هذا العامل
    val wideAfterSec: Double = 1.0,     // بعد هذا الفقدان تُفتح نافذة بحث واسعة (بتباين أشد)
    val backDeg: Double = 8.0,       // العقرب لا يرجع؛ نسمح فقط بتذبذب صغير للخلف
    val deadbandDeg: Double = 1.5,   // لا تتقدّم الزاوية المثبّتة إلا بعد تجاوز هذا الحد
    val shakeSearch: Int = 6,
    val restAccelDegPerSec: Double = 150.0, // العقرب قد ينطلق من السكون: هامش أمامي إضافي لكل ثانية منذ آخر قياس
    val backWideDeg: Double = 20.0,        // بعد فقدان طويل: تراجع حتى هذا المقدار ضجيج، وما فوقه دورة أمامية
    val relLow: Double = 0.5,              // أثناء التتبّع: قاع أضعف من هذا الكسر من تباين العقرب المعتاد ليس العقرب (ضجيج/علامة ثابتة)
    val relHigh: Double = 3.0,             // وأقوى من هذا المضاعف ليس العقرب (بقعة/ظل/انعكاس عابر)
)

class MeterSample(
    val t: Double,
    val valid: Boolean,        // false: لا قياس موثوق في هذا الإطار (ليس توقفًا!)
    val angleDeg: Double,      // الحركة المتراكمة المثبّتة بالدرجات (تتزايد فقط)
    val rawAngleDeg: Double,   // زاوية العقرب 0..360 (0=أعلى)
    val contrast: Double,
    val shiftX: Double,
    val shiftY: Double,
    val uncertainJump: Boolean, // قفزة بعد فقدان طويل (بحث واسع) — الدقة أقل
)

/**
 * يتتبّع العقرب الكبير لعدّاد واحد ويحسب الحركة المتراكمة.
 *  - تعويض الاهتزاز (ShakeCompensator)
 *  - ملف زاوي ثم اختيار القاع ضمن نافذة تنبؤ (للأمام فقط) لتفادي علامات الأرقام الثابتة
 *  - فكّ اللف (unwrap) فيعالج عبور الصفر بدقة
 *  - منطقة ميتة صغيرة تمنع تراكم ضجيج القياس
 */
class MeterTracker(val cfg: MeterConfig, val p: TrackerParams = TrackerParams(), reference: GrayFrame? = null) {
    private val profile = HandProfile(p.smoothDeg)
    private val shake = ShakeCompensator(search = p.shakeSearch)
    private val prof = DoubleArray(HandProfile.N)

    private var sx = 0.0
    private var sy = 0.0
    private var locked = false
    private var lastMod = 0.0
    private var lastValidT = 0.0
    private var rawCum = 0.0
    private var committed = 0.0

    private var vEst = 0.0   // سرعة مقدّرة (°/ث)
    private var handC = 0.0  // تباين العقرب المعتاد (متوسط متحرك للقياسات المقبولة)

    init {
        // المرجع من لحظة المعايرة يضمن أن المحور المعاير يطابق إزاحة الاهتزاز المقدّرة
        if (reference != null) shake.setReference(reference, cfg.cx, cfg.cy, cfg.radius)
    }

    val totalDegrees: Double get() = committed

    fun reset() {
        locked = false; rawCum = 0.0; committed = 0.0; sx = 0.0; sy = 0.0; vEst = 0.0; handC = 0.0
    }

    fun update(f: GrayFrame, t: Double): MeterSample {
        if (!shake.hasRef) shake.setReference(f, cfg.cx, cfg.cy, cfg.radius)
        else shake.estimate(f, sx, sy)?.let { sx = it.x; sy = it.y }

        val ok = profile.compute(f, cfg.cx + sx, cfg.cy + sy, cfg.radius, p.bandInner, p.bandOuter, prof)
        if (!ok) return invalid(t)

        if (!locked) {
            var bi = 0
            for (a in 1 until HandProfile.N) if (prof[a] < prof[bi]) bi = a
            val c = -prof[bi]
            if (c < p.lockContrast) return invalid(t)
            locked = true
            lastMod = refine(bi)
            lastValidT = t
            handC = c
            return valid(t, c, false)
        }

        val lost = t - lastValidT
        val wide = lost > p.wideAfterSec
        val fwd = if (wide) min(359.0, p.maxDegPerSec * lost + 10.0)
                  else min(120.0, p.baseFwdDeg + p.accelFactor * vEst * lost + p.restAccelDegPerSec * lost)
        val center = lastMod.roundToInt()
        val lo = -p.backDeg.roundToInt()
        val hi = ceil(fwd).toInt()
        var best = -1
        var bv = Double.MAX_VALUE
        if (wide || handC <= 0.0) {
            for (d in lo..hi) {
                val a = ((center + d) % 360 + 360) % 360
                if (prof[a] < bv) { bv = prof[a]; best = a }
            }
        } else {
            // أثناء التتبّع: أعمق قاع محلي *يشبه العقرب* (تباين بين relLow و relHigh من المعتاد)؛ البقعة الأغمق بكثير تُتجاهل
            // ويُؤخذ العقرب الحقيقي إن ظهر في النافذة، والعناصر الأضعف بكثير (علامات ثابتة/ضجيج) لا تُطارَد.
            val lowC = max(p.minContrast, p.relLow * handC); val highC = p.relHigh * handC
            for (d in lo..hi) {
                val a = ((center + d) % 360 + 360) % 360
                val c = -prof[a]
                if (c < lowC || c > highC || !isLocalMin(a)) continue
                if (prof[a] < bv) { bv = prof[a]; best = a }
            }
            if (best < 0) return invalid(t)
        }
        val contrast = -bv
        if (contrast < (if (wide) p.lockContrast else p.minContrast)) return invalid(t)

        val ang = refine(best)
        var d = ang - lastMod
        d = if (wide) {
            // بعد فقدان طويل: تراجع صغير = ضجيج (لا يُحسب دورة)، وتراجع كبير = دورة أمامية
            (((d + p.backWideDeg) % 360.0) + 360.0) % 360.0 - p.backWideDeg
        } else {
            // النافذة الضيقة تحصر المرشح في [−8°, +fwd] لكن refine() قد يدفع الزاوية خارج حافتها قليلًا؛
            // فنفك اللف بالفرق الأصغر بالإشارة. (كان −8.9° يُقرأ +351° = دورة وهمية كاملة = نصف برميل زائد)
            (((d + 180.0) % 360.0) + 360.0) % 360.0 - 180.0
        }
        if (!wide && handC > 0.0) {
            // قفزة أكبر بكثير من المعقول *وأقوى* من العقرب المعتاد = بقعة/انعكاس لا عقرب: تُرفض (والعقرب الحقيقي سيظهر في النافذة)
            val gate = max(30.0, 2.0 * vEst * lost + 25.0)
            if (d > gate && contrast > 2.0 * handC) return invalid(t)
        }
        if (!wide && lost > 1e-3) {
            val step = max(0.0, d) / lost
            vEst = max(0.75 * vEst + 0.25 * step, step)   // صعود سريع، هبوط تدريجي
        } else if (wide) vEst = min(p.maxDegPerSec, max(0.0, d) / lost)   // السرعة من القفزة المقاسة فتتابع النافذة العقرب بعد الالتقاط
        rawCum += d
        lastMod = ((ang % 360.0) + 360.0) % 360.0
        lastValidT = t
        handC = if (wide) contrast else 0.8 * handC + 0.2 * contrast
        if (rawCum - committed > p.deadbandDeg) committed = rawCum
        return valid(t, contrast, wide)
    }

    /** مركز ثقل القاع (فوق نصف العمق) حول الفهرس: أثبت من أدنى نقطة لأن قاع الملف المنعَّم مسطّح. */
    private fun refine(i: Int): Double {
        val n = HandProfile.N
        var c = i.toDouble()
        repeat(2) {
            val ci = Math.round(c).toInt()
            val depth = -prof[((ci % n) + n) % n]
            val thr = 0.5 * depth
            var sw = 0.0; var sd = 0.0
            for (d in -CENTROID_HALF..CENTROID_HALF) {
                val w = -prof[(((ci + d) % n) + n) % n] - thr
                if (w > 0) { sw += w; sd += w * d }
            }
            if (sw > 0) c = ci + sd / sw
        }
        return c
    }

    private companion object { const val CENTROID_HALF = 22 }

    /** قاع محلي حقيقي ضمن ±8° (الملف منعَّم فقيعانه عريضة). */
    private fun isLocalMin(a: Int): Boolean {
        val v = prof[a]
        for (k in 1..8) { if (prof[((a - k) % 360 + 360) % 360] < v || prof[(a + k) % 360] < v) return false }
        return true
    }

    private fun valid(t: Double, c: Double, wide: Boolean) =
        MeterSample(t, true, committed, lastMod, c, sx, sy, wide)

    private fun invalid(t: Double) =
        MeterSample(t, false, committed, lastMod, 0.0, sx, sy, false)
}
