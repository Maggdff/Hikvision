import com.smartwater.monitor.core.*
import java.io.File
import javax.imageio.ImageIO

/**
 * اختبار كاشف وجود الوايت على لقطات حقيقية من «Camera 07» (فيديو 62ث، لقطة كل ثانيتين كما يلتقطها التطبيق).
 * المشهد: وايت داكن واقف تحت القصبة 0–6ث ثم يخرج؛ وايت أبيض يظهر بعيدًا في الخلفية (لا يُعدّ تحت القصبة)؛
 * ثم وايت بخزان أزرق يدخل ~34ث ويقف تحت القصبة حتى نهاية الفيديو.
 */
object CamTest {
    private var failures = 0
    private fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }
    private fun gray(f: File): Triple<ByteArray, Int, Int> {
        val bi = ImageIO.read(f); val w = bi.width; val h = bi.height
        val g = ByteArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = bi.getRGB(x, y); g[y * w + x] = ((((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000).toByte()
        }
        return Triple(g, w, h)
    }

    private fun events(frames: List<Triple<ByteArray, Int, Int>>, bgIndex: Int?, zone: DoubleArray?): List<Pair<String, Int>> {
        val d = TruckPresenceDetector(PresenceParams(zone = zone))
        if (bgIndex != null) frames[bgIndex].let { d.setBackground(it.first, it.second, it.third) }
        val out = ArrayList<Pair<String, Int>>()
        frames.forEachIndexed { i, f ->
            val e = d.update(i * 2000L, f.first, f.second, f.third)
            when (e) { is PresenceEvent.Entered -> out.add("دخل" to (e.tMs / 1000).toInt()); is PresenceEvent.Left -> out.add("غادر" to (e.tMs / 1000).toInt())
                is PresenceEvent.Replaced -> out.add("استُبدل" to (e.tMs / 1000).toInt()); null -> {} }
        }
        return out
    }

    @JvmStatic fun main(a: Array<String>) {
        val files = File(a[0]).listFiles { f -> f.name.endsWith(".jpg") }!!.sortedBy { it.name }
        val frames = files.map { gray(it) }
        val zone = doubleArrayOf(0.44, 0.28, 0.46, 0.47)           // منطقة القصبة المعتمدة افتراضيًا
        println("لقطات: ${frames.size} (${frames[0].second}×${frames[0].third})")

        println("A) خلفية فارغة معيَّنة (لقطة ثانية 24) + منطقة القصبة")
        val ev = events(frames, 12, zone)
        println("   الأحداث: " + ev.joinToString { "${it.first}@${it.second}ث" })
        check("وايت واقف تحت القصبة من البداية: دخول مبكر (≤ 2ث)", ev.getOrNull(0)?.first == "دخل" && ev[0].second <= 2)
        check("خروجه يُرصد بعد ابتعاده (14–26ث) ولا يُعدّ الوايت البعيد في الخلفية", ev.getOrNull(1)?.first == "غادر" && ev[1].second in 8..26, "${ev.getOrNull(1)}")
        check("الوايت الثاني يدخل (30–38ث)", ev.getOrNull(2)?.first == "دخل" && ev[2].second in 30..38, "${ev.getOrNull(2)}")
        check("وقوفه حتى نهاية الفيديو لا يولّد خروجًا ولا استبدالًا (بقاؤه تحت القصبة)", ev.size == 3, "${ev.size} أحداث")

        println("B) بلا منطقة (كل الصورة): الوايت البعيد والقريب لا يُميَّزان — لذلك المنطقة مطلوبة")
        val evAll = events(frames, 12, null)
        println("   الأحداث: " + evAll.joinToString { "${it.first}@${it.second}ث" })
        check("بلا منطقة لا يكتشف الوايت الواقف أصلًا (نسبته ≤ 9% من الصورة)", evAll.none { it.first == "دخل" })

        println("C) بلا خلفية معيَّنة والوايت واقف عند التشغيل (أول لقطة تُعدّ فارغة): سلوك معروف")
        val evAuto = events(frames, null, zone)
        println("   الأحداث: " + evAuto.joinToString { "${it.first}@${it.second}ث" })
        println("   (لذلك زر «تعيين الخلفية الفارغة» + إعادة الضبط التلقائية عند بقاء الحالة عالقة)")

        println(if (failures == 0) "اختبار القناة 7 على لقطات حقيقية نجح" else "فشل $failures")
        if (failures > 0) System.exit(1)
    }
}
