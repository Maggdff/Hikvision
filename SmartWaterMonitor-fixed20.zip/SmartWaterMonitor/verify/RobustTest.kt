import com.smartwater.monitor.core.*
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * اختبار ضغط للمتتبّع على إطارات الفيديو الحقيقية: إسقاط إطارات (تأخر اللقطات) وبقع داكنة عابرة فوق حلقة البحث
 * (انعكاس/رذاذ/ظل). المرجع = القياس النظيف. أي انحراف قرب مضاعفات 360° = دورة وهمية = نصف برميل زائد.
 */
object RobustTest {
    private var failures = 0
    private fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }

    @JvmStatic fun main(a: Array<String>) {
        val dir = a[0]
        val cfg = MeterConfig("L", 505.0, 1232.0, 60.0)
        val frames = readFrames("$dir/frames_L.bin")
        val ref = readFrames("$dir/ref_L.bin")[0]
        val times = File("$dir/times.txt").readLines().map { it.split(" ")[0].toDouble() }
        val dt = (times.last() - times.first()) / (times.size - 1)

        val tp = TrackerParams()
        fun run(drop: (Int) -> Boolean = { false }, blob: (Int) -> Double? = { null }): Double {
            val tr = MeterTracker(cfg, tp, ref)
            for (k in frames.indices) {
                if (drop(k)) continue
                val b = blob(k)
                val f = if (b == null) frames[k] else addBlob(frames[k], cfg, b)
                tr.update(f, times[k])
            }
            return tr.totalDegrees
        }

        val clean = run()
        println("إطارات=${frames.size} فاصل≈%.2f ث؛ القياس النظيف = %.1f° = %.3f برميل".format(dt, clean, clean / DEG_PER_BARREL))
        // مدى الحركة الفعلية
        val tr0 = MeterTracker(cfg, tp, ref); val cum = DoubleArray(frames.size)
        for (k in frames.indices) cum[k] = tr0.update(frames[k], times[k]).angleDeg
        val first = cum.indexOfFirst { it > 5 }; val last = cum.indexOfFirst { it >= cum.last() - 5 }

        println("A) إسقاط إطارات (تأخر اللقطات) — الخطأ بالدرجات عن النظيف")
        var worst = 0.0; var bad = 0; var n = 0
        for (g in listOf(0.8, 1.2, 1.6, 2.5, 4.0)) {
            val gf = (g / dt).toInt().coerceAtLeast(1)
            var gw = 0.0; var gb = 0; var gn = 0
            // نوافذ يتبعها رصد (فجوة تمتد إلى نهاية الفيديو = حركة لم تُرصد أصلًا ولا يمكن استرجاعها)
            for (s in first until (frames.size - gf - 4) step 3) {
                val e = run(drop = { it in s until s + gf }) - clean
                gn++; if (abs(e) > 30) gb++; if (abs(e) > abs(gw)) gw = e
            }
            println("   فجوة %.1f ث: %d حالة، %d منحرفة >30°، أسوأ خطأ %+.0f°".format(g, gn, gb, gw))
            worst = maxOf(worst, abs(gw)); bad += gb; n += gn
        }
        check("الفجوات: لا انحراف يتجاوز 30° (لا دورات وهمية)", bad == 0, "منحرفة $bad من $n، الأسوأ %.0f°".format(worst))

        println("B) بقعة داكنة عابرة فوق حلقة البحث (1–3 إطارات)")
        var worstB = 0.0; var badB = 0; var nB = 0
        for (len in 1..3) for (ang in listOf(20.0, 80.0, 140.0, 200.0, 260.0, 320.0)) {
            for (s in first until last step 4) {
                val e = run(blob = { if (it in s until s + len) ang else null }) - clean
                nB++; if (abs(e) > 30) badB++; if (abs(e) > worstB) worstB = abs(e)
            }
        }
        println("   $nB حالة، $badB منحرفة >30°، أسوأ خطأ %.0f°".format(worstB))
        check("البقع العابرة: لا انحراف يتجاوز 30°", badB == 0, "منحرفة $badB من $nB، الأسوأ %.0f°".format(worstB))

        println("C) سرعات أعلى (ضغط الزمن: إطار كل k إطارات): لا زيادة ولا نقص كبير حتى ≈240°/ث (3 إطارات/ث)")
        for (k in listOf(1, 2, 3, 4, 5, 6, 7, 8)) {
            val tr = MeterTracker(cfg, tp, ref); var i = 0; var idx = 0
            while (idx < frames.size) { tr.update(frames[idx], i * dt); i++; idx += k }
            val t = tr.totalDegrees
            println("   ×%d (≈%d°/ث): %.1f°".format(k, 30 * k, t))
            check("×$k: ضمن [500°، 600°] (لا دورة وهمية ولا فقد كبير)", t in 500.0..600.0, "%.1f".format(t))
        }

        check("القياس النظيف ما زال 584.6° ± 10", abs(clean - 584.6) < 10, "%.1f".format(clean))
        println(if (failures == 0) "اختبار الصلابة نجح" else "فشل $failures")
        if (failures > 0) System.exit(1)
    }

    /** بقعة داكنة (أغمق من العقرب) على حلقة البحث (0.42R) بزاوية ang مقيسة من الأعلى مع عقارب الساعة. */
    private fun addBlob(f: GrayFrame, c: MeterConfig, angDeg: Double): GrayFrame {
        val d = f.data.copyOf()
        val rr = 0.42 * c.radius
        val bx = (c.cx - f.originX) + rr * sin(angDeg * PI / 180)
        val by = (c.cy - f.originY) - rr * cos(angDeg * PI / 180)
        for (y in 0 until f.height) for (x in 0 until f.width) {
            val dx = x - bx; val dy = y - by
            if (dx * dx + dy * dy <= 36.0) d[y * f.width + x] = 0
        }
        return GrayFrame(f.width, f.height, d, f.originX, f.originY)
    }
}
