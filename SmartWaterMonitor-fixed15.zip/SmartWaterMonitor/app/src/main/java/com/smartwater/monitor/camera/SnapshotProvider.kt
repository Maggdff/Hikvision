package com.smartwater.monitor.camera

/** مصدر قادر على التقاط لقطة JPEG واحدة من قناة أخرى على الجهاز نفسه (كاميرا الوايتات). لا يستخدم RTSP. */
interface SnapshotProvider {
    /** يعيد بايتات JPEG أو null عند الفشل. يُستدعى من خيط خلفي (قد يحجب بضع ثوانٍ). */
    fun snapshotJpeg(channel: Int): ByteArray?
}
