package com.smartwater.monitor.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.camera.SnapshotProvider
import com.smartwater.monitor.core.MatchResult
import com.smartwater.monitor.core.RgbImage
import com.smartwater.monitor.core.SwingResult
import com.smartwater.monitor.core.TruckFeatures
import com.smartwater.monitor.core.TruckMatcher
import com.smartwater.monitor.data.AppConfig
import com.smartwater.monitor.data.SwingDb
import com.smartwater.monitor.data.SwingRecord
import com.smartwater.monitor.data.Truck
import com.smartwater.monitor.data.TruckDb
import java.io.File
import kotlin.math.max

/** ما تعرضه الواجهة للسؤال «أي وايت هذا؟». */
class TruckPrompt(
    val episodeId: Long,
    /** مسار صورة اللقطة (null إن تعذّر الالتقاط). */
    val photoPath: String?,
    /** كل الوايتات المحفوظة، الأشبه أولًا. */
    val trucks: List<Truck>,
    val note: String,
)

/**
 * سير عمل الوايت لكل «حلقة» (زبون):
 *  بدء حركة أي عدّاد → لقطة من قناة الوايتات (7) → محاولة تعرّف من الشكل واللون → إن لم نتأكد نسأل المستخدم →
 *  عند انتهاء الزفة تُسجَّل بكمية الوايت المدخلة (زفة كاملة) وتُحفظ الصورة، وتُضاف للتعلّم عند اختيار المستخدم.
 *
 * لا يُفقَد أي شيء إن تأخر الجواب: الزفة تُسجَّل فورًا بالكمية المقاسة، ثم تُحدَّث عند اختيار الوايت
 * (من النافذة أو من تبويب السجل لاحقًا). كل عملية مرتبطة بحلقة واحدة فلا تتكرر.
 */
class TruckCoordinator(
    private val ctx: Context,
    private val trucks: TruckDb,
    private val swings: SwingDb,
    private val config: () -> AppConfig,
    /** مصدر اللقطات الحالي، أو null إن لم يكن هناك اتصال حقيقي (فيديو اختبار / بدون SDK). */
    private val snapshotSource: () -> SnapshotProvider?,
) {
    interface Listener {
        fun onPrompt(p: TruckPrompt)
        fun onPromptClosed(episodeId: Long)
        fun onInfo(msg: String)
    }

    private class Episode(val id: Long) {
        @Volatile var photoPath: String? = null
        @Volatile var feat: FloatArray? = null
        @Volatile var truck: Truck? = null
        @Volatile var recordId: Long = -1
        @Volatile var ready = false        // انتهت مرحلة اللقطة/التعرّف (حان وقت السؤال إن لزم)
        @Volatile var resulted = false     // وصلت نتيجة الزفة وسُجّلت
        @Volatile var dismissed = false    // اختار المستخدم «لاحقًا»
        @Volatile var cancelled = false    // انتهت الحلقة بلا زفة تُسجَّل
        @Volatile var ranking: List<Long> = emptyList()
        @Volatile var note: String = ""
        val answered: Boolean get() = truck != null || dismissed || cancelled
    }

    @Volatile var listener: Listener? = null
    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val episodes = ArrayList<Episode>()
    private var nextId = 1L
    private val snapDir = File(ctx.filesDir, "truck_snaps").also { it.mkdirs() }

    private fun info(m: String) { CamLog.i(m); main.post { listener?.onInfo(m) } }

    // ---------------- أحداث المحرك ----------------

    /** بدأت حركة أحد العدّادين (أو كليهما): التقط صورة الوايت. تُستدعى من خيط المعالجة فلا تحجبه. */
    fun onEpisodeStart() {
        val cfg = config()
        if (cfg.truckChannel <= 0 || snapshotSource() == null) return
        val ep = Episode(nextId++)
        synchronized(lock) { episodes.add(ep) }
        CamLog.i("بدأت زفة: التقاط صورة الوايت من القناة ${cfg.truckChannel} (حلقة ${ep.id})")
        Thread({ capture(ep, cfg) }, "truck-capture-${ep.id}").start()
    }

    /** انتهت الحلقة بلا زفة (اهتزاز): ألغِ السؤال المعلّق. */
    fun onEpisodeCancel() {
        val ep = synchronized(lock) { episodes.lastOrNull { !it.resulted && !it.cancelled } } ?: return
        ep.cancelled = true
        synchronized(lock) { episodes.remove(ep) }
        if (ep.truck == null) ep.photoPath?.let { try { File(it).delete() } catch (_: Exception) {} }
        main.post { listener?.onPromptClosed(ep.id) }
        CamLog.i("أُلغيت الحلقة ${ep.id}: لا زفة معتبرة")
    }

    /**
     * نتيجة زفة جاهزة: تُسجَّل مرة واحدة. إن عُرف الوايت تُسجَّل بكميته المدخلة كزفة كاملة؛
     * وإلا بالكمية المقاسة وتُربط لاحقًا. تُستدعى من خيط المعالجة.
     */
    fun record(r: SwingResult, startMs: Long, endMs: Long): SwingRecord {
        val ep = synchronized(lock) { episodes.firstOrNull { !it.resulted && !it.cancelled } }
        if (ep == null) return swings.insert(r, startMs, endMs)
        synchronized(ep) {
            ep.resulted = true
            val rec = swings.insert(r, startMs, endMs, ep.truck, ep.photoPath)
            ep.recordId = rec.id
            // لو كان قد وُجد سجل مطابق (مكرر) ولم يكن له وايت وكان عندنا وايت: اربطه
            if (rec.duplicate && ep.truck != null && rec.truckId == null) swings.assignTruck(rec.id, ep.truck!!, ep.photoPath)
            if (ep.answered) synchronized(lock) { episodes.remove(ep) }
            return rec
        }
    }

    // ---------------- اللقطة والتعرّف ----------------

    private fun capture(ep: Episode, cfg: AppConfig) {
        try {
            val jpeg = snapshotSource()?.snapshotJpeg(cfg.truckChannel)
            if (ep.cancelled) return
            if (jpeg == null) {
                ep.note = "تعذّر التقاط صورة القناة ${cfg.truckChannel} (راجع سجل الاتصال). اختر الوايت يدويًا."
                info("تعذّر التقاط صورة الوايت من القناة ${cfg.truckChannel}")
                finishCapture(ep); return
            }
            val bmp = decode(jpeg, 960)
            if (bmp == null) {
                ep.note = "تعذّر قراءة الصورة الملتقطة. اختر الوايت يدويًا."
                finishCapture(ep); return
            }
            val f = File(snapDir, "snap_${System.currentTimeMillis()}_${ep.id}.jpg")
            try { f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }; ep.photoPath = f.absolutePath }
            catch (e: Exception) { CamLog.e("تعذّر حفظ صورة الوايت", e) }
            val feat = TruckFeatures.describe(toRgb(bmp))
            bmp.recycle()
            ep.feat = feat

            val res = TruckMatcher.match(feat, trucks.samples())
            ep.ranking = res.ranking.map { it.first }
            if (config().autoRecognize && res.truckId != null) {
                val t = trucks.get(res.truckId)
                if (t != null) {
                    CamLog.i("تعرّف تلقائي: ${t.name} (%.2f مقابل %.2f)".format(res.best, res.second))
                    if (apply(ep, t, learn = false)) {
                        info("تعرّفت على الوايت: ${t.name} — ${fmt(t.capacity)} برميل (يمكن تغييره من تبويب السجل)")
                        finishCapture(ep); return
                    }
                }
            }
            ep.note = noteFor(res)
            finishCapture(ep)
        } catch (t: Throwable) {
            CamLog.e("خطأ في سير الوايت", t)
            ep.note = "حدث خطأ أثناء التعرّف. اختر الوايت يدويًا."
            finishCapture(ep)
        }
    }

    private fun noteFor(res: MatchResult) =
        if (res.reason.isEmpty() || res.ranking.isEmpty()) "" else "لم أتأكد من الوايت — ${res.reason}"

    private fun finishCapture(ep: Episode) {
        ep.ready = true
        if (ep.answered || ep.cancelled) return
        val p = prompt(ep)
        main.post { listener?.onPrompt(p) }
    }

    private fun prompt(ep: Episode): TruckPrompt = TruckPrompt(ep.id, ep.photoPath, ordered(ep.ranking), ep.note)

    /** الوايتات المحفوظة بترتيب التشابه (إن وُجد) ثم الباقي أبجديًا. */
    fun ordered(ranking: List<Long>): List<Truck> {
        val all = trucks.list()
        val byId = all.associateBy { it.id }
        val first = ranking.mapNotNull { byId[it] }
        val rest = all.filter { it.id !in ranking.toSet() }
        return first + rest
    }

    /** أسئلة لم تُجَب بعد (تُعاد للواجهة عند عودتها من الخلفية). */
    fun openPrompts(): List<TruckPrompt> = synchronized(lock) { episodes.filter { it.ready && !it.answered } }.map { prompt(it) }

    // ---------------- جواب المستخدم ----------------

    /** اختار المستخدم وايتًا لهذه الحلقة (آمنة عند التكرار: الجواب الأول هو المعتمد). */
    fun choose(episodeId: Long, truckId: Long): Boolean {
        val ep = synchronized(lock) { episodes.firstOrNull { it.id == episodeId } } ?: return false
        val t = trucks.get(truckId) ?: return false
        if (!apply(ep, t, learn = true)) return false
        main.post { listener?.onPromptClosed(ep.id) }
        return true
    }

    /** «لاحقًا»: تبقى الزفة بلا وايت ويمكن ربطها من السجل. */
    fun dismiss(episodeId: Long) {
        val ep = synchronized(lock) { episodes.firstOrNull { it.id == episodeId } } ?: return
        synchronized(ep) {
            if (ep.truck != null) return
            ep.dismissed = true
            if (ep.resulted) synchronized(lock) { episodes.remove(ep) }
        }
        main.post { listener?.onPromptClosed(ep.id) }
    }

    /** يطبّق الوايت على الحلقة مرة واحدة فقط (الجواب الأول هو المعتمد). يعيد false إن سبق الجواب أو أُلغيت الحلقة. */
    private fun apply(ep: Episode, t: Truck, learn: Boolean): Boolean {
        synchronized(ep) {
            if (ep.truck != null || ep.cancelled) return false
            ep.truck = t
            if (learn) {
                val f = ep.feat; val p = ep.photoPath
                if (f != null && p != null) trucks.addPhoto(t.id, p, f)
            }
            if (ep.resulted) {
                if (ep.recordId > 0) swings.assignTruck(ep.recordId, t, ep.photoPath)
                synchronized(lock) { episodes.remove(ep) }
            }
            // لم تصل نتيجة الزفة بعد: يُطبَّق الوايت عند record()
            return true
        }
    }

    // ---------------- ربط/تصحيح سجل موجود (من تبويب السجل) ----------------

    /** يربط سجلًا قديمًا بوايت (أو يصحّح الربط) ويضيف صورته للتعلّم. يعمل في خيط خلفي ويُبلغ الواجهة. */
    fun assignRecord(recordId: Long, truckId: Long, done: (String) -> Unit) {
        Thread({
            val msg = try {
                val rec = swings.byId(recordId)
                val t = trucks.get(truckId)
                when {
                    rec == null -> "السجل غير موجود"
                    t == null -> "الوايت غير موجود"
                    else -> {
                        val photo = rec.photo.takeIf { it.isNotEmpty() && File(it).exists() }
                        if (photo != null) learnFrom(photo, t)
                        swings.assignTruck(recordId, t, photo)
                        closeEpisodeOf(recordId, t)
                        "رُبطت الزفة بالوايت «${t.name}» — ${fmt(t.capacity)} برميل"
                    }
                }
            } catch (e: Throwable) { CamLog.e("فشل ربط السجل", e); "تعذّر الربط: ${e.message}" }
            main.post { done(msg) }
        }, "truck-assign").start()
    }

    /** إن كان لهذا السجل سؤال معلّق فقد أُجيب الآن من السجل: أغلقه كي لا يُسأل مرتين. */
    private fun closeEpisodeOf(recordId: Long, t: Truck) {
        val ep = synchronized(lock) { episodes.firstOrNull { it.recordId == recordId } } ?: return
        synchronized(ep) { if (ep.truck == null) ep.truck = t }
        synchronized(lock) { episodes.remove(ep) }
        main.post { listener?.onPromptClosed(ep.id) }
    }

    private fun learnFrom(path: String, t: Truck) {
        val bmp = decode(File(path).readBytes(), 960) ?: return
        val feat = TruckFeatures.describe(toRgb(bmp)); bmp.recycle()
        trucks.addPhoto(t.id, path, feat)
    }

    /** إعادة تسمية: تتحدّث الأسماء في سجلاته. */
    fun renamed(t: Truck) = swings.renameTruck(t.id, t.name)

    /** حذف وايت: تبقى أسماؤه في السجلات القديمة لكن بلا ارتباط. */
    fun deleted(id: Long) { swings.detachTruck(id) }

    /** يحذف صور اللقطات الأقدم من 60 يومًا ما لم تكن صور تعلّم لوايت. */
    fun cleanup() {
        try {
            val keep = trucks.allPhotoPaths()
            val limit = System.currentTimeMillis() - 60L * 24 * 3600 * 1000
            snapDir.listFiles()?.forEach { if (it.lastModified() < limit && it.absolutePath !in keep) it.delete() }
        } catch (e: Throwable) { CamLog.e("تنظيف الصور", e) }
    }

    // ---------------- أدوات ----------------

    private fun fmt(d: Double) = if (d == Math.floor(d)) d.toLong().toString() else "%.2f".format(java.util.Locale.US, d)

    companion object {
        /** فك JPEG بتصغير يقرّب العرض إلى maxW. */
        fun decode(bytes: ByteArray, maxW: Int): Bitmap? {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            if (o.outWidth <= 0) return null
            var s = 1
            while (o.outWidth / (s * 2) >= maxW) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = max(1, s) }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        }

        fun toRgb(b: Bitmap): RgbImage {
            val px = IntArray(b.width * b.height)
            b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
            return RgbImage(b.width, b.height, px)
        }
    }
}
