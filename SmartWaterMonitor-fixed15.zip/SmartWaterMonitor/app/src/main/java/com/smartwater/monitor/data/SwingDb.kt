package com.smartwater.monitor.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.smartwater.monitor.core.SwingResult
import com.smartwater.monitor.core.SwingType
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class SwingRecord(
    val id: Long, val day: String, val seq: Int, val full: Boolean, val meters: String,
    val startMs: Long, val endMs: Long, val m1Barrels: Double, val m2Barrels: Double,
    val total: Double, val notes: String,
    /** الوايت المرتبط (null = لم يُحدَّد بعد). */
    val truckId: Long? = null,
    val truckName: String = "",
    /** مسار صورة الوايت الملتقطة عند بدء الحركة (فارغ إن لم تُلتقط). */
    val photo: String = "",
    /** الكمية التي قاستها العدّادات (total يصبح كمية الوايت المدخلة عند ربطه). */
    val measured: Double = total,
    /** true: وُجدت زفة مسجّلة تغطي العملية نفسها فلم تُسجَّل مرة ثانية؛ هذا هو السجل الموجود. */
    val duplicate: Boolean = false,
) {
    val typeAr: String get() = if (full) "زفة كاملة" else "زفة عداد"
}

/** سجل الزفات: رقم الزفة (يومي) ونوعها ووقتها وكمية البراميل (+ الوايت المرتبط وصورته). */
class SwingDb(ctx: Context) : SQLiteOpenHelper(ctx, "swings.db", null, 2) {
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE swings(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, seq INTEGER NOT NULL," +
                "full INTEGER NOT NULL, meters TEXT NOT NULL, start_ms INTEGER, end_ms INTEGER," +
                "m1 REAL, m2 REAL, total REAL, notes TEXT," +
                "truck_id INTEGER, truck_name TEXT, photo TEXT, measured REAL)"
        )
    }

    /** ترقية من النسخة 1: إضافة أعمدة الوايت فقط؛ كل السجلات القديمة تبقى كما هي. */
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            for (col in listOf("truck_id INTEGER", "truck_name TEXT", "photo TEXT", "measured REAL")) {
                try { db.execSQL("ALTER TABLE swings ADD COLUMN $col") } catch (_: Exception) {}
            }
        }
    }

    private val cols = "id,day,seq,full,meters,start_ms,end_ms,m1,m2,total,notes,truck_id,truck_name,photo,measured"

    /**
     * يسجّل الزفة مرة واحدة فقط: إن وُجد سجل يتداخل زمنيًا (≥ نصف المدة الأقصر) ويشترك معه في العدّاد
     * فهي العملية نفسها (إعادة إرسال/إعادة اتصال/نقر مزدوج)، فيُرجَع السجل الموجود بـ duplicate=true.
     * إن مُرِّر truck تُحفظ كمية الوايت المدخلة كقيمة للزفة (زفة كاملة)، وتبقى الكمية المقاسة في measured.
     */
    @Synchronized
    fun insert(r: SwingResult, startMs: Long, endMs: Long, truck: Truck? = null, photo: String? = null): SwingRecord {
        val db = writableDatabase
        val meters = r.parts.joinToString("+") { (it.meter + 1).toString() }
        findDuplicate(db, meters, startMs, endMs)?.let { return it.withDuplicate() }

        val day = dayFmt.format(Date(endMs))
        val seq = db.rawQuery("SELECT COUNT(*) FROM swings WHERE day=?", arrayOf(day)).use { it.moveToFirst(); it.getInt(0) } + 1
        val m1 = r.parts.firstOrNull { it.meter == 0 }?.barrels ?: 0.0
        val m2 = r.parts.firstOrNull { it.meter == 1 }?.barrels ?: 0.0
        val full = truck != null || r.type == SwingType.FULL
        val total = truck?.capacity ?: r.totalBarrels
        val cv = ContentValues().apply {
            put("day", day); put("seq", seq); put("full", if (full) 1 else 0)
            put("meters", meters); put("start_ms", startMs); put("end_ms", endMs)
            put("m1", m1); put("m2", m2); put("total", total); put("notes", r.notes)
            put("measured", r.totalBarrels)
            if (photo != null) put("photo", photo)
            if (truck != null) { put("truck_id", truck.id); put("truck_name", truck.name) }
        }
        val id = db.insert("swings", null, cv)
        return SwingRecord(id, day, seq, full, meters, startMs, endMs, m1, m2, total, r.notes,
            truck?.id, truck?.name ?: "", photo ?: "", r.totalBarrels)
    }

    private fun SwingRecord.withDuplicate() = SwingRecord(id, day, seq, full, meters, startMs, endMs, m1Barrels, m2Barrels,
        total, notes, truckId, truckName, photo, measured, duplicate = true)

    private fun findDuplicate(db: SQLiteDatabase, meters: String, startMs: Long, endMs: Long): SwingRecord? {
        val mine = meters.split("+").toSet()
        db.rawQuery("SELECT $cols FROM swings WHERE start_ms < ? AND end_ms > ?", arrayOf(endMs.toString(), startMs.toString())).use { c ->
            while (c.moveToNext()) {
                val o = read(c)
                if (o.meters.split("+").none { it in mine }) continue
                val overlap = min(endMs, o.endMs) - max(startMs, o.startMs)
                val shorter = min(endMs - startMs, o.endMs - o.startMs).coerceAtLeast(1)
                if (overlap * 2 >= shorter) return o
            }
        }
        return null
    }

    /** يربط سجلًا بوايت (أو يصحّح الربط): الكمية = كمية الوايت المدخلة، زفة كاملة. آمنة عند التكرار. */
    @Synchronized
    fun assignTruck(recordId: Long, t: Truck, photo: String?) {
        val cv = ContentValues()
        cv.put("truck_id", t.id); cv.put("truck_name", t.name); cv.put("total", t.capacity); cv.put("full", 1)
        if (!photo.isNullOrEmpty()) cv.put("photo", photo)
        val db = writableDatabase
        // measured يحفظ القيمة المقاسة قبل أول استبدال (COALESCE تُقيَّم على القيم القديمة للصف)
        db.execSQL("UPDATE swings SET measured=COALESCE(measured,total) WHERE id=?", arrayOf<Any>(recordId))
        db.update("swings", cv, "id=?", arrayOf(recordId.toString()))
    }

    @Synchronized
    fun byId(id: Long): SwingRecord? =
        readableDatabase.rawQuery("SELECT $cols FROM swings WHERE id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) read(it) else null }

    /** عند إعادة تسمية وايت تتحدّث الأسماء في سجلاته (الكميات القديمة لا تتغيّر). */
    @Synchronized
    fun renameTruck(truckId: Long, name: String) {
        writableDatabase.execSQL("UPDATE swings SET truck_name=? WHERE truck_id=?", arrayOf<Any>(name, truckId))
    }

    /** عند حذف وايت يبقى اسمه في السجلات القديمة لكن يُفكّ ارتباطه. */
    @Synchronized
    fun detachTruck(truckId: Long) {
        writableDatabase.execSQL("UPDATE swings SET truck_id=NULL WHERE truck_id=?", arrayOf<Any>(truckId))
    }

    private fun read(c: android.database.Cursor): SwingRecord {
        val total = c.getDouble(9)
        return SwingRecord(
            c.getLong(0), c.getString(1), c.getInt(2), c.getInt(3) == 1, c.getString(4),
            c.getLong(5), c.getLong(6), c.getDouble(7), c.getDouble(8), total, c.getString(10) ?: "",
            if (c.isNull(11)) null else c.getLong(11), c.getString(12) ?: "", c.getString(13) ?: "",
            if (c.isNull(14)) total else c.getDouble(14),
        )
    }

    @Synchronized
    fun query(day: String?): List<SwingRecord> {
        val out = ArrayList<SwingRecord>()
        val c = if (day == null) readableDatabase.rawQuery("SELECT $cols FROM swings ORDER BY id DESC", null)
        else readableDatabase.rawQuery("SELECT $cols FROM swings WHERE day=? ORDER BY id DESC", arrayOf(day))
        c.use { while (it.moveToNext()) out.add(read(it)) }
        return out
    }

    fun today(): String = dayFmt.format(Date())

    @Synchronized
    fun dayTotal(day: String): Double =
        readableDatabase.rawQuery("SELECT COALESCE(SUM(total),0) FROM swings WHERE day=?", arrayOf(day)).use { it.moveToFirst(); it.getDouble(0) }

    @Synchronized
    fun clear() { writableDatabase.execSQL("DELETE FROM swings") }

    /** مسارات صور السجلات (لتنظيف الصور القديمة غير المستخدمة). */
    @Synchronized
    fun photoPaths(): Set<String> =
        readableDatabase.rawQuery("SELECT photo FROM swings WHERE photo IS NOT NULL AND photo<>''", null).use { c ->
            val s = HashSet<String>(); while (c.moveToNext()) s.add(c.getString(0)); s
        }

    /** CSV بترميز UTF-8 مع BOM ليفتح العربي صحيحًا في Excel. الأعمدة القديمة بترتيبها، والجديدة في النهاية. */
    fun exportCsv(out: OutputStream) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("\uFEFF")
        w.write("رقم الزفة (يومي),التاريخ,نوع الزفة,العدّادات,وقت البدء,وقت الانتهاء,المدة (ث),براميل العداد 1,براميل العداد 2,إجمالي البراميل,ملاحظات,اسم الوايت,الكمية المقاسة (براميل)\n")
        for (r in query(null).reversed()) {
            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            w.write(listOf(
                r.seq.toString(), r.day, q(r.typeAr), r.meters,
                timeFmt.format(Date(r.startMs)), timeFmt.format(Date(r.endMs)),
                ((r.endMs - r.startMs) / 1000).toString(),
                "%.3f".format(Locale.US, r.m1Barrels), "%.3f".format(Locale.US, r.m2Barrels),
                "%.3f".format(Locale.US, r.total), q(r.notes),
                q(r.truckName), "%.3f".format(Locale.US, r.measured),
            ).joinToString(",") + "\n")
        }
        w.flush()
    }
}
