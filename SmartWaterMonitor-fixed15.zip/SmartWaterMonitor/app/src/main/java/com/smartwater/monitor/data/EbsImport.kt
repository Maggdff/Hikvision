package com.smartwater.monitor.data

import android.database.sqlite.SQLiteDatabase
import java.io.File

/** مرشّح للاستيراد: اسم عميل من نسخة EBS + كمية مقترحة (الأكثر تكرارًا في فواتيره). */
class EbsCandidate(val name: String, val capacity: Double, val invoices: Int, val exists: Boolean)

class EbsImportResult(val candidates: List<EbsCandidate>, val customersWithoutInvoices: Int)

/**
 * يقرأ أسماء الوايتات من نسخة قاعدة بيانات EBS الاحتياطية (جدولا customers و invoices) — قراءة فقط.
 * الكمية المقترحة لكل اسم = عدد البراميل الأكثر تكرارًا في فواتيره (وعند التساوي الأحدث). يمكن تعديلها بعد الاستيراد.
 */
object EbsImport {
    fun read(dbFile: File, existingNames: Set<String>): EbsImportResult {
        val db = try { SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY) }
        catch (e: Exception) { throw TruckInputError("تعذّر فتح الملف كقاعدة بيانات: ${e.message}") }
        db.use {
            val tables = it.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                val s = HashSet<String>(); while (c.moveToNext()) s.add(c.getString(0)); s
            }
            if ("customers" !in tables || "invoices" !in tables)
                throw TruckInputError("الملف ليس نسخة EBS: لا يحوي الجدولين customers و invoices")
            val total = it.rawQuery("SELECT COUNT(*) FROM customers", null).use { c -> c.moveToFirst(); c.getInt(0) }

            // لكل (عميل، كمية): عدد التكرار وآخر وقت
            val best = LinkedHashMap<String, DoubleArray>()   // الاسم -> [الكمية، تكرارها، آخر وقت، مجموع الفواتير]
            it.rawQuery(
                "SELECT c.theName, i.barrels, COUNT(*), MAX(i.createdAtEpochMillis) FROM customers c " +
                    "JOIN invoices i ON i.customerName = c.theName WHERE i.barrels > 0 " +
                    "GROUP BY c.theName, i.barrels ORDER BY c.theName", null,
            ).use { c ->
                while (c.moveToNext()) {
                    val name = norm(c.getString(0))
                    if (name.isEmpty()) continue
                    val b = c.getDouble(1); val n = c.getInt(2).toDouble(); val last = c.getDouble(3)
                    val cur = best.getOrPut(name) { doubleArrayOf(0.0, 0.0, 0.0, 0.0) }
                    cur[3] += n
                    if (n > cur[1] || (n == cur[1] && last > cur[2])) { cur[0] = b; cur[1] = n; cur[2] = last }
                }
            }
            val ex = existingNames.map { n -> norm(n).lowercase() }.toSet()
            val list = best.map { (name, v) -> EbsCandidate(name, v[0], v[3].toInt(), name.lowercase() in ex) }
            return EbsImportResult(list, total - best.size)
        }
    }

    private fun norm(s: String?) = (s ?: "").trim().replace(Regex("\\s+"), " ")
}
