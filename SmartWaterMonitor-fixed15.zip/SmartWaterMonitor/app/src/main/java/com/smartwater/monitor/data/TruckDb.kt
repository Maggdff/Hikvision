package com.smartwater.monitor.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.smartwater.monitor.core.TruckMatcher
import com.smartwater.monitor.core.TruckSample

class Truck(val id: Long, val name: String, val capacity: Double, val photos: Int = 0)

/** خطأ إدخال بسبب اسم/كمية غير صالحة؛ الرسالة جاهزة للعرض للمستخدم. */
class TruckInputError(msg: String) : Exception(msg)

/**
 * قائمة الوايتات المحفوظة محليًا (SQLite): الاسم + الكمية الكاملة بالبراميل + صور التعلّم وبصماتها.
 * لا يحتاج إنترنت. الاسم فريد (بلا اعتبار لحالة الأحرف).
 */
class TruckDb(private val ctx: Context) : SQLiteOpenHelper(ctx, "trucks.db", null, 1) {
    companion object { const val MAX_PHOTOS_PER_TRUCK = 10 }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE trucks(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL COLLATE NOCASE UNIQUE, capacity REAL NOT NULL, created_ms INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE truck_photos(id INTEGER PRIMARY KEY AUTOINCREMENT, truck_id INTEGER NOT NULL, path TEXT NOT NULL, feat BLOB NOT NULL, created_ms INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_truck_photos_truck ON truck_photos(truck_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    private fun clean(name: String, capacity: Double): String {
        val n = name.trim().replace(Regex("\\s+"), " ")
        if (n.isEmpty()) throw TruckInputError("اكتب اسم الوايت")
        if (!capacity.isFinite() || capacity <= 0.0) throw TruckInputError("اكتب كمية صحيحة بالبراميل (أكبر من صفر)")
        if (capacity > 1000.0) throw TruckInputError("الكمية كبيرة جدًا — تأكد أنها بالبراميل")
        return n
    }

    @Synchronized
    fun add(name: String, capacity: Double): Truck {
        val n = clean(name, capacity)
        val cv = ContentValues().apply { put("name", n); put("capacity", capacity); put("created_ms", System.currentTimeMillis()) }
        val id = try { writableDatabase.insertOrThrow("trucks", null, cv) }
        catch (e: SQLiteConstraintException) { throw TruckInputError("الاسم «$n» موجود مسبقًا") }
        return Truck(id, n, capacity, 0)
    }

    /** تعديل الاسم/الكمية. الكمية الجديدة تُطبَّق على الزفات القادمة فقط. */
    @Synchronized
    fun update(id: Long, name: String, capacity: Double): Truck {
        val n = clean(name, capacity)
        val cv = ContentValues().apply { put("name", n); put("capacity", capacity) }
        val rows = try { writableDatabase.update("trucks", cv, "id=?", arrayOf(id.toString())) }
        catch (e: SQLiteConstraintException) { throw TruckInputError("الاسم «$n» موجود مسبقًا") }
        if (rows == 0) throw TruckInputError("الوايت غير موجود (ربما حُذف)")
        return get(id)!!
    }

    @Synchronized
    fun delete(id: Long) {
        val db = writableDatabase
        // ملفات الصور تبقى على القرص لأن سجلات زفات قديمة قد تشير إليها؛ التنظيف الدوري (cleanup) يحذف القديم منها
        db.delete("truck_photos", "truck_id=?", arrayOf(id.toString()))
        db.delete("trucks", "id=?", arrayOf(id.toString()))
    }

    private val listSql = "SELECT t.id,t.name,t.capacity,(SELECT COUNT(*) FROM truck_photos p WHERE p.truck_id=t.id) FROM trucks t"

    @Synchronized
    fun list(): List<Truck> = readableDatabase.rawQuery("$listSql ORDER BY t.name COLLATE NOCASE", null).use { c ->
        val out = ArrayList<Truck>(); while (c.moveToNext()) out.add(Truck(c.getLong(0), c.getString(1), c.getDouble(2), c.getInt(3))); out
    }

    @Synchronized
    fun get(id: Long): Truck? = readableDatabase.rawQuery("$listSql WHERE t.id=?", arrayOf(id.toString())).use {
        if (it.moveToFirst()) Truck(it.getLong(0), it.getString(1), it.getDouble(2), it.getInt(3)) else null
    }

    /** يضيف صورة تعلّم مع بصمتها، ويحذف الأقدم إن تجاوزت الحد. */
    @Synchronized
    fun addPhoto(truckId: Long, path: String, feat: FloatArray) {
        val db = writableDatabase
        val exists = db.rawQuery("SELECT 1 FROM truck_photos WHERE truck_id=? AND path=?", arrayOf(truckId.toString(), path)).use { it.moveToFirst() }
        if (exists) return   // نفس الصورة لا تُضاف مرتين
        val cv = ContentValues().apply {
            put("truck_id", truckId); put("path", path); put("feat", TruckMatcher.toBytes(feat)); put("created_ms", System.currentTimeMillis())
        }
        db.insert("truck_photos", null, cv)
        db.execSQL(
            "DELETE FROM truck_photos WHERE truck_id=? AND id NOT IN (SELECT id FROM truck_photos WHERE truck_id=? ORDER BY id DESC LIMIT $MAX_PHOTOS_PER_TRUCK)",
            arrayOf<Any>(truckId, truckId),
        )
    }

    @Synchronized
    fun samples(): List<TruckSample> = readableDatabase.rawQuery("SELECT truck_id,feat FROM truck_photos", null).use { c ->
        val out = ArrayList<TruckSample>()
        while (c.moveToNext()) TruckMatcher.fromBytes(c.getBlob(1))?.let { out.add(TruckSample(c.getLong(0), it)) }
        out
    }

    @Synchronized
    fun photoPaths(truckId: Long): List<String> =
        readableDatabase.rawQuery("SELECT path FROM truck_photos WHERE truck_id=? ORDER BY id DESC", arrayOf(truckId.toString())).use { c ->
            val l = ArrayList<String>(); while (c.moveToNext()) l.add(c.getString(0)); l
        }

    @Synchronized
    fun allPhotoPaths(): Set<String> = readableDatabase.rawQuery("SELECT path FROM truck_photos", null).use { c ->
        val s = HashSet<String>(); while (c.moveToNext()) s.add(c.getString(0)); s
    }
}
