package com.smartwater.monitor.core

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** صورة ملوّنة ARGB. النواة بلا اعتماد على أندرويد كي تُختبر على JVM. */
class RgbImage(val width: Int, val height: Int, val argb: IntArray) {
    init { require(argb.size >= width * height) { "حجم البكسلات لا يطابق الأبعاد" } }
}

/**
 * بصمة مظهر الوايت من «الشكل واللون» فقط (بلا قراءة لوحات ولا تعلّم آلي ثقيل):
 *  1) توزيع الألوان (تدرّج اللون + درجات الرمادي) في شبكة 4×3 — يميّز لون الكابينة عن لون الخزان ومكانهما.
 *  2) توزيع اتجاهات الحواف (HOG مبسّط) في شبكة 4×3 — يميّز شكل الهيكل (خزان أسطواني/مسطّح/ارتفاع الكابينة...).
 * الإضاءة تُطبَّع قبل الحساب حتى لا يؤثر الليل/النهار كثيرًا.
 */
object TruckFeatures {
    const val W = 64
    const val H = 48
    private const val GX = 4
    private const val GY = 3
    private const val COLOR_BINS = 16     // 12 تدرّج لون + 4 درجات رمادي
    private const val ORI_BINS = 8
    const val DIM = GX * GY * COLOR_BINS + COLOR_BINS + GX * GY * ORI_BINS

    private const val W_LAYOUT = 1.0f
    private const val W_GLOBAL = 0.6f
    private const val W_SHAPE = 1.0f

    fun describe(img: RgbImage): FloatArray {
        val (r, g, b) = downscale(img)
        // تطبيع الإضاءة: متوسط السطوع → 128
        var lum = 0.0
        for (i in r.indices) lum += 0.299 * r[i] + 0.587 * g[i] + 0.114 * b[i]
        lum /= r.size
        val gain = if (lum < 1.0) 1.0 else (128.0 / lum).coerceIn(0.6, 1.6)
        for (i in r.indices) {
            r[i] = (r[i] * gain).coerceAtMost(255.0)
            g[i] = (g[i] * gain).coerceAtMost(255.0)
            b[i] = (b[i] * gain).coerceAtMost(255.0)
        }

        // --- توزيع الألوان لكل خلية
        val cw = W / GX; val ch = H / GY
        val layout = FloatArray(GX * GY * COLOR_BINS)
        val global = FloatArray(COLOR_BINS)
        for (y in 0 until H) for (x in 0 until W) {
            val i = y * W + x
            val bin = colorBin(r[i], g[i], b[i])
            val cell = (y / ch).coerceAtMost(GY - 1) * GX + (x / cw).coerceAtMost(GX - 1)
            layout[cell * COLOR_BINS + bin] += 1f
            global[bin] += 1f
        }
        for (c in 0 until GX * GY) hellinger(layout, c * COLOR_BINS, COLOR_BINS)
        hellinger(global, 0, COLOR_BINS)

        // --- اتجاهات الحواف (Sobel)
        val gray = DoubleArray(W * H) { 0.299 * r[it] + 0.587 * g[it] + 0.114 * b[it] }
        val shape = FloatArray(GX * GY * ORI_BINS)
        for (y in 1 until H - 1) for (x in 1 until W - 1) {
            fun p(dx: Int, dy: Int) = gray[(y + dy) * W + x + dx]
            val gx = (p(1, -1) + 2 * p(1, 0) + p(1, 1)) - (p(-1, -1) + 2 * p(-1, 0) + p(-1, 1))
            val gy = (p(-1, 1) + 2 * p(0, 1) + p(1, 1)) - (p(-1, -1) + 2 * p(0, -1) + p(1, -1))
            val mag = hypot(gx, gy)
            if (mag < 8.0) continue                       // تجاهل الضجيج الخفيف
            var ang = atan2(gy, gx); if (ang < 0) ang += PI
            val ob = ((ang / PI) * ORI_BINS).toInt().coerceIn(0, ORI_BINS - 1)
            val cell = (y / ch).coerceAtMost(GY - 1) * GX + (x / cw).coerceAtMost(GX - 1)
            shape[cell * ORI_BINS + ob] += mag.toFloat()
        }
        l2(shape, 0, shape.size)

        l2(layout, 0, layout.size); l2(global, 0, global.size)
        val out = FloatArray(DIM)
        var o = 0
        for (v in layout) out[o++] = v * W_LAYOUT
        for (v in global) out[o++] = v * W_GLOBAL
        for (v in shape) out[o++] = v * W_SHAPE
        return out
    }

    private fun colorBin(r: Double, g: Double, b: Double): Int {
        val mx = max(r, max(g, b)); val mn = minOf(r, minOf(g, b))
        val v = mx / 255.0
        val s = if (mx <= 0.0) 0.0 else (mx - mn) / mx
        if (s >= 0.25 && v >= 0.2) {
            val d = mx - mn
            var h = when (mx) {
                r -> ((g - b) / d) % 6.0
                g -> (b - r) / d + 2.0
                else -> (r - g) / d + 4.0
            } * 60.0
            if (h < 0) h += 360.0
            return (h / 30.0).toInt().coerceIn(0, 11)
        }
        return 12 + when { v < 0.25 -> 0; v < 0.5 -> 1; v < 0.75 -> 2; else -> 3 }
    }

    private fun hellinger(a: FloatArray, off: Int, n: Int) {
        var s = 0f; for (i in off until off + n) s += a[i]
        if (s <= 0f) return
        for (i in off until off + n) a[i] = sqrt(a[i] / s)
    }

    private fun l2(a: FloatArray, off: Int, n: Int) {
        var s = 0.0; for (i in off until off + n) s += a[i] * a[i]
        if (s <= 1e-12) return
        val k = (1.0 / sqrt(s)).toFloat()
        for (i in off until off + n) a[i] *= k
    }

    /** تصغير بمتوسط المساحة إلى 64×48. */
    private fun downscale(img: RgbImage): Triple<DoubleArray, DoubleArray, DoubleArray> {
        val r = DoubleArray(W * H); val g = DoubleArray(W * H); val b = DoubleArray(W * H)
        for (dy in 0 until H) {
            val sy0 = dy * img.height / H
            val sy1 = max(sy0 + 1, (dy + 1) * img.height / H).coerceAtMost(img.height)
            for (dx in 0 until W) {
                val sx0 = dx * img.width / W
                val sx1 = max(sx0 + 1, (dx + 1) * img.width / W).coerceAtMost(img.width)
                var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
                for (y in sy0 until sy1) for (x in sx0 until sx1) {
                    val p = img.argb[y * img.width + x]
                    sr += (p shr 16) and 0xFF; sg += (p shr 8) and 0xFF; sb += p and 0xFF; n++
                }
                val i = dy * W + dx
                r[i] = sr.toDouble() / n; g[i] = sg.toDouble() / n; b[i] = sb.toDouble() / n
            }
        }
        return Triple(r, g, b)
    }
}

class TruckSample(val truckId: Long, val feat: FloatArray)

data class MatchParams(
    val minScore: Double = 0.60,       // أقل تشابه للقبول التلقائي
    val minMargin: Double = 0.12,      // أقل فارق عن ثاني أقرب وايت
    val minTrucks: Int = 2,            // لا تعرّف تلقائيًا قبل وجود وايتين على الأقل لهما صور
    val minSamples: Int = 2,           // ولا تقبل وايتًا له أقل من صورتين محفوظتين
)

class MatchResult(
    /** الوايت المقبول تلقائيًا، أو null إن لم نكن متأكدين (فتُسأل المستخدم). */
    val truckId: Long?,
    val best: Double,
    val second: Double,
    /** كل الوايتات التي لها صور، من الأشبه إلى الأقل (لترتيب القائمة المعروضة). */
    val ranking: List<Pair<Long, Double>>,
    val reason: String,
)

/**
 * مطابقة صورة جديدة مع صور الوايتات السابقة.
 * الكاميرا ثابتة فالخلفية متشابهة في كل الصور؛ لذلك نطرح «متوسط كل الصور» (متوسط متوسطات الوايتات)
 * قبل حساب التشابه، فيبقى ما يميّز الوايتات عن بعضها لا ما يشتركون فيه (الأرض/السماء/المبنى).
 */
object TruckMatcher {
    fun match(query: FloatArray, samples: List<TruckSample>, p: MatchParams = MatchParams()): MatchResult {
        if (samples.isEmpty()) return MatchResult(null, 0.0, 0.0, emptyList(), "لا صور محفوظة بعد")
        val byTruck = samples.groupBy { it.truckId }
        val dim = query.size

        // الخلفية المشتركة = متوسط متوسطات الوايتات (وزن متساوٍ لكل وايت)
        val mean = FloatArray(dim)
        for ((_, l) in byTruck) {
            val tm = FloatArray(dim)
            for (s in l) for (i in 0 until dim) tm[i] += s.feat[i] / l.size
            for (i in 0 until dim) mean[i] += tm[i] / byTruck.size
        }
        fun centered(f: FloatArray) = FloatArray(dim) { f[it] - mean[it] }
        val q = centered(query)

        val scores = byTruck.mapValues { (_, l) -> l.maxOf { cosine(q, centered(it.feat)) } }
        val ranking = scores.entries.sortedByDescending { it.value }.map { it.key to it.value }

        val best = ranking[0]
        val second = ranking.getOrNull(1)?.second ?: -1.0
        val why = when {
            byTruck.size < p.minTrucks -> "تعلّم أولي: يلزم وايتان على الأقل لهما صور"
            byTruck.getValue(best.first).size < p.minSamples -> "الوايت الأقرب له صورة واحدة فقط"
            best.second < p.minScore -> "التشابه منخفض (%.2f)".format(best.second)
            best.second - second < p.minMargin -> "وايتان متقاربان (%.2f مقابل %.2f)".format(best.second, second)
            else -> ""
        }
        return MatchResult(if (why.isEmpty()) best.first else null, best.second, second, ranking, why)
    }

    fun cosine(a: FloatArray, b: FloatArray): Double {
        var d = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return if (na <= 1e-12 || nb <= 1e-12) 0.0 else d / (sqrt(na) * sqrt(nb))
    }

    fun toBytes(f: FloatArray): ByteArray {
        val bb = java.nio.ByteBuffer.allocate(f.size * 4)
        for (v in f) bb.putFloat(v)
        return bb.array()
    }

    fun fromBytes(b: ByteArray): FloatArray? {
        if (b.size != TruckFeatures.DIM * 4) return null
        val bb = java.nio.ByteBuffer.wrap(b)
        return FloatArray(TruckFeatures.DIM) { bb.getFloat() }
    }
}
