import com.smartwater.monitor.core.*
import java.io.File
import javax.imageio.ImageIO

/** يختبر منطق التعرّف على الوايتات على صور اصطناعية: يجب أن يعرّف بصحة، وألا يقبل وايتًا غريبًا بثقة. */
private fun load(f: File): RgbImage {
    val bi = ImageIO.read(f)
    val px = IntArray(bi.width * bi.height)
    bi.getRGB(0, 0, bi.width, bi.height, px, 0, bi.width)
    return RgbImage(bi.width, bi.height, px)
}

object TruckTest {
@JvmStatic fun main(args: Array<String>) {
    val dir = File(args[0])
    var failures = 0
    fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }
    fun feat(f: File) = TruckFeatures.describe(load(f))
    val ids = mapOf("T1" to 1L, "T2" to 2L, "T3" to 3L, "T4" to 4L, "T5" to 5L)
    val samples = ArrayList<TruckSample>()
    for ((n, id) in ids) dir.listFiles { f -> f.name.startsWith("train_${n}_") }!!.sorted().forEach { samples.add(TruckSample(id, feat(it))) }

    var ok = 0; var wrong = 0; var asked = 0; var total = 0
    for ((n, id) in ids) for (f in dir.listFiles { x -> x.name.startsWith("test_${n}_") }!!.sorted()) {
        val r = TruckMatcher.match(feat(f), samples); total++
        when (r.truckId) { id -> ok++; null -> asked++; else -> { wrong++; println("   خطأ: ${f.name} عُرِّف ${r.truckId} (%.2f / %.2f)".format(r.best, r.second)) } }
    }
    println("وايتات معروفة: تعرّف صحيح=$ok  سؤال=$asked  خطأ=$wrong  من $total")
    check("لا تعريف خاطئ بثقة", wrong == 0)
    check("يتعرّف تلقائيًا على 80% على الأقل", ok >= total * 0.8, "$ok/$total")

    var unkAuto = 0; var unkTotal = 0
    for (f in dir.listFiles { x -> x.name.startsWith("test_UNK_") }!!.sorted()) {
        val r = TruckMatcher.match(feat(f), samples); unkTotal++
        if (r.truckId != null) { unkAuto++; println("   وايت غريب قُبل كـ ${r.truckId}: %.2f / %.2f".format(r.best, r.second)) }
    }
    check("الوايت الغريب لا يُقبل تلقائيًا", unkAuto == 0, "قُبل $unkAuto من $unkTotal")

    // مرحلة التعلّم: وايت واحد فقط أو صورة واحدة -> يسأل دائمًا
    val one = samples.filter { it.truckId == 1L }
    check("وايت واحد فقط -> يسأل", TruckMatcher.match(feat(dir.listFiles { x -> x.name.startsWith("test_T1_") }!!.first()), one).truckId == null)
    val single = ids.values.map { id -> samples.first { it.truckId == id } }
    check("صورة واحدة لكل وايت -> يسأل", TruckMatcher.match(feat(dir.listFiles { x -> x.name.startsWith("test_T1_") }!!.first()), single).truckId == null)
    check("لا صور -> يسأل", TruckMatcher.match(FloatArray(TruckFeatures.DIM), emptyList()).truckId == null)
    // ترتيب القائمة: الأقرب أولًا حتى عند عدم التأكد
    val rk = TruckMatcher.match(feat(dir.listFiles { x -> x.name.startsWith("test_T3_") }!!.first()), samples).ranking
    check("ترتيب القائمة يضع الوايت الصحيح أولًا", rk.first().first == 3L)
    // تسلسل البصمة
    val ff = samples[0].feat
    check("تسلسل/استرجاع البصمة", TruckMatcher.fromBytes(TruckMatcher.toBytes(ff))!!.contentEquals(ff))
    println(if (failures == 0) "اختبارات التعرّف على الوايتات نجحت" else "فشل $failures اختبار")
    if (failures > 0) System.exit(1)
}
}
