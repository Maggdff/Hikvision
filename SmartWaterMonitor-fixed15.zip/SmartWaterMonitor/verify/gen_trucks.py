"""يولّد صور وايتات اصطناعية (خلفية ثابتة + وايتات بألوان/أشكال مختلفة + تغيّر إضاءة وإزاحة وضجيج)
لاختبار منطق التعرّف على الشكل واللون. ليست بديلًا عن صور كاميرتك الحقيقية."""
import sys, os
import numpy as np, cv2

out = sys.argv[1]; os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(7)
W, H = 640, 480

def background():
    img = np.zeros((H, W, 3), np.float32)
    for y in range(H):
        t = y / H
        img[y, :] = (200 - 40 * t, 190 - 30 * t, 170 - 20 * t) if y < 300 else (95, 95, 100)   # BGR: سماء ثم أرض
    cv2.rectangle(img, (0, 120), (160, 300), (120, 130, 140), -1)     # مبنى ثابت
    cv2.rectangle(img, (500, 80), (640, 300), (110, 120, 125), -1)
    return img

# (cab BGR, tank BGR, tank length factor, tank height factor, stripe)
TRUCKS = {
    "T1": ((200, 80, 30),  (235, 235, 235), 1.0, 1.0, None),
    "T2": ((40, 40, 200),  (190, 190, 195), 1.1, 0.9, None),
    "T3": ((30, 200, 220), (180, 90, 30),   0.9, 1.1, None),
    "T4": ((235, 235, 235),(60, 150, 60),   1.0, 1.0, (30, 30, 30)),
    "T5": ((30, 130, 240), (235, 235, 235), 1.0, 1.0, None),
    "UNK": ((160, 50, 140),(120, 120, 125), 1.2, 0.8, (40, 200, 220)),
}

def draw(name):
    cab, tank, lf, hf, stripe = TRUCKS[name]
    img = background()
    s = rng.uniform(0.9, 1.1); dx = rng.integers(-40, 40); dy = rng.integers(-20, 20)
    x0 = int(110 + dx); y0 = int(230 + dy)
    cabw, cabh = int(110 * s), int(130 * s)
    tl, th = int(300 * s * lf), int(110 * s * hf)
    cv2.rectangle(img, (x0, y0 + 40), (x0 + tl + cabw + 20, y0 + 80 + 40), (50, 50, 55), -1)            # هيكل
    cv2.rectangle(img, (x0, y0 + 40 - cabh + 80), (x0 + cabw, y0 + 120), cab, -1)                        # كابينة
    cv2.rectangle(img, (x0 + 10, y0 + 5), (x0 + cabw - 15, y0 + 40), (220, 220, 200), -1)                # زجاج
    cv2.ellipse(img, (x0 + cabw + 20 + tl // 2, y0 + 120 - th // 2), (tl // 2, th // 2), 0, 0, 360, tank, -1)
    if stripe:
        cv2.rectangle(img, (x0 + cabw + 20, y0 + 120 - th // 2 - 6), (x0 + cabw + 20 + tl, y0 + 120 - th // 2 + 6), stripe, -1)
    for wx in (x0 + 40, x0 + cabw + 60, x0 + cabw + tl - 20):
        cv2.circle(img, (wx, y0 + 135), int(26 * s), (15, 15, 15), -1)
    gain = rng.uniform(0.7, 1.3)
    tint = rng.uniform(0.93, 1.07, 3)
    img = img * gain * tint + rng.normal(0, 6, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)

for name in TRUCKS:
    n_train, n_test = (0, 8) if name == "UNK" else (3, 8)
    for k in range(n_train): cv2.imwrite(f"{out}/train_{name}_{k}.png", draw(name))
    for k in range(n_test):  cv2.imwrite(f"{out}/test_{name}_{k}.png", draw(name))
print("تم توليد الصور في", out)
