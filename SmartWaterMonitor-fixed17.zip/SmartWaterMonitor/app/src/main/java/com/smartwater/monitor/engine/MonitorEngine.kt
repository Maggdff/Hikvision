package com.smartwater.monitor.engine

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.SurfaceHolder
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.camera.FrameSource
import com.smartwater.monitor.camera.HikSourceFactory
import com.smartwater.monitor.camera.RecordingProbe
import com.smartwater.monitor.camera.RecordingProvider
import com.smartwater.monitor.camera.SnapshotProvider
import com.smartwater.monitor.camera.VideoFileSource
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.core.DEG_PER_BARREL
import com.smartwater.monitor.core.SwingResult
import com.smartwater.monitor.core.SwingType
import com.smartwater.monitor.data.AppConfig
import com.smartwater.monitor.data.Store
import com.smartwater.monitor.data.SwingDb
import com.smartwater.monitor.data.SwingRecord
import com.smartwater.monitor.data.TruckDb
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MeterState(
    val name: String, val valid: Boolean, val active: Boolean,
    val totalDeg: Double, val rawAngle: Double, val currentDeg: Double,
    val contrast: Double, val shiftX: Double, val shiftY: Double,
    val episodeDeg: Double = 0.0,   // درجات الزبون الحالي (تتصفّر عند انتهاء الزفة)
)

class UiState(val connected: Boolean, val running: Boolean, val frameW: Int, val frameH: Int, val meters: List<MeterState>, val fps: Double)

/** المحرك المشترك بين الواجهة والخدمة: مصدر إطارات -> Pipeline -> سجل الزفات. */
class MonitorEngine(private val ctx: Context) : FrameSource.Listener {
    interface UiListener {
        fun onState(s: UiState)
        fun onSwing(text: String)
        fun onStatus(msg: String)
        /** سؤال «أي وايت هذا؟» (صورة + قائمة الأسماء). */
        fun onTruckPrompt(p: TruckPrompt) {}
        /** أُجيب السؤال أو أُلغي (أغلق نافذته إن كانت معروضة). */
        fun onTruckPromptClosed(episodeId: Long) {}
        /** رسالة قصيرة عن سير الوايت (تعرّف تلقائي، فشل لقطة...). */
        fun onTruckInfo(msg: String) {}
        /** حالة الحساب من تسجيلات الجهاز (الحالة الحالية، الكمية التراكمية، المهلة ...). */
        fun onFill(s: RecStatus) {}
    }

    val store = Store(ctx)
    val db = SwingDb(ctx)
    val trucks = TruckDb(ctx)
    @Volatile var cfg: AppConfig = store.load()
    var uiListener: UiListener? = null
        set(v) { field = v; truckFlow.listener = if (v == null) null else truckListener }

    /** الوايتات: لقطة القناة 7 عند بدء الحركة، التعرّف، الربط بالزفة، ومنع التكرار. */
    val truckFlow = TruckCoordinator(ctx, trucks, db, { cfg }) { if (persist) source as? SnapshotProvider else null }
    private val truckListener = object : TruckCoordinator.Listener {
        override fun onPrompt(p: TruckPrompt) { uiListener?.onTruckPrompt(p) }
        override fun onPromptClosed(episodeId: Long) { uiListener?.onTruckPromptClosed(episodeId) }
        override fun onInfo(msg: String) { uiListener?.onTruckInfo(msg) }
    }
    init { Thread({ truckFlow.cleanup() }, "truck-cleanup").start() }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("monitor-proc").also { it.start() }
    private val wh = Handler(worker.looper)
    private val busy = AtomicBoolean(false)
    private var inBuf = ByteArray(0)

    @Volatile private var source: FrameSource? = null
    @Volatile private var pipeline: Pipeline? = null
    @Volatile private var persist = false
    @Volatile private var recMode = false          // الحساب من تسجيلات الجهاز؛ البث المباشر للمعاينة والمعايرة فقط
    private var recMon: RecordingMonitor? = null
    @Volatile var running = false
        private set
    @Volatile private var connected = false
    private var lastT = 0.0
    private var lastUi = 0L
    private var fpsCount = 0
    private var fpsT = 0L
    private var fps = 0.0

    // آخر إطار كامل (للمعايرة) ولقطة المعايرة
    private val lock = Any()
    private var latestMat: Mat? = null
    private var stillMat: Mat? = null
    val stillWidth: Int get() = synchronized(lock) { stillMat?.cols() ?: 0 }
    val stillHeight: Int get() = synchronized(lock) { stillMat?.rows() ?: 0 }

    // ---------- التشغيل ----------
    private fun newPipeline(): Pipeline {
        cfg = store.load()
        val refs = List(cfg.meters.size) { store.loadReference(it) }
        return Pipeline(cfg.meters, cfg.swing, refs) { onSwingResult(it) }.also { p ->
            // بدء حركة أي عدّاد (أو كليهما) → التقاط صورة الوايت؛ تُهمل في فيديو الاختبار (persist=false)
            p.swing.onEpisodeStart = { if (persist && !recMode) truckFlow.onEpisodeStart() }
            p.swing.onEpisodeCancel = { if (persist && !recMode) truckFlow.onEpisodeCancel() }
        }
    }

    fun startCamera(holder: SurfaceHolder?) {
        stop()
        pipeline = newPipeline()
        persist = true; running = true; connected = false
        val c = cfg
        CamLog.i("طلب الاتصال: ${c.ip}:8000 قناة ${c.channel} (SDK متوفر=${HikSourceFactory.AVAILABLE})")
        status("جارٍ الاتصال بـ ${c.ip}:8000 ، القناة ${c.channel} ...")
        recMode = c.useRecordings && HikSourceFactory.AVAILABLE
        // بلا شاشة (خدمة في الخلفية بعد إغلاق التطبيق) وفي وضع التسجيلات: لا حاجة لبث مباشر
        source = HikSourceFactory.create(ctx, c.ip, c.user, c.pass, c.channel, c.streamType, c.realChannel, holder, livePreview = holder != null || !recMode)
            .also { it.start(this) }
        if (recMode) {
            status("وضع التسجيلات: الكمية تُحسب من تسجيلات الجهاز (البث المباشر للمعاينة والمعايرة فقط)")
            recMon = RecordingMonitor(ctx, { source as? RecordingProvider }, { source as? SnapshotProvider }, { cfg }, { newBank() }, truckFlow) { st ->
                ui.post { uiListener?.onFill(st) }
            }.also { it.start() }
        }
    }

    private fun newBank(): MeterBank {
        val c = store.load()
        return MeterBank(c.meters, List(c.meters.size) { store.loadReference(it) }, c.calW, c.calH)
    }

    /** يعتمد صورة قناة الوايتات الحالية خلفيةً فارغة لكاشف الوجود (والمنطقة خالية). */
    fun resetPresenceBackground(): Boolean { val m = recMon ?: return false; m.resetBackground(); return true }

    /** فحص التسجيلات على الجهاز: ساعة الجهاز، البحث، تشغيل بالوقت وفك الإطارات للقناتين. */
    fun probeRecordings(line: (String) -> Unit) {
        val prov = source as? RecordingProvider
        if (prov == null) { line("اتصل بالكاميرا أولًا ثم أعد الفحص (يحتاج جلسة SDK مفتوحة)"); return }
        val c = cfg
        Thread({
            try { RecordingProbe.run(prov, listOf("كاميرا العدّادات" to c.channel, "كاميرا الوايتات" to c.truckChannel), c.streamType, line) }
            catch (t: Throwable) { CamLog.e("فحص التسجيلات", t); line("✗ استثناء أثناء الفحص: ${t.message}") }
        }, "rec-probe").start()
    }

    /** فيديو محلي كمصدر: لا يُكتب في السجل الحقيقي (للتجربة فقط). */
    fun startVideo(uri: Uri) {
        stop()
        pipeline = newPipeline()
        persist = false; recMode = false; running = true; connected = true
        status("تشغيل فيديو اختبار (لا يُسجَّل في السجل)")
        source = VideoFileSource(ctx, uri, 100, realtime = true).also { it.start(this) }
    }

    fun stop() {
        recMon?.stop(); recMon = null
        val s = source ?: return
        source = null
        s.stop()
        wh.post {
            pipeline?.swing?.flush()
            running = false; connected = false
            ui.post { uiListener?.onStatus("متوقف") }
        }
    }

    // ---------- استقبال الإطارات ----------
    override fun onFrame(gray: ByteArray, width: Int, height: Int, tSec: Double) {
        if (!busy.compareAndSet(false, true)) return          // المعالج مشغول: نُسقط الإطار (الزمن حقيقي فلا يتأثر الحساب)
        val n = width * height
        if (inBuf.size != n) inBuf = ByteArray(n)
        System.arraycopy(gray, 0, inBuf, 0, n)
        wh.post {
            try { process(inBuf, width, height, tSec) } catch (e: Exception) { CamLog.e("خطأ معالجة الإطار", e); status("خطأ معالجة: ${e.message}") }
            finally { busy.set(false) }
        }
    }

    override fun onStatus(message: String) = status(message)

    override fun onDisconnected() {
        connected = false
        wh.post { pipeline?.swing?.markGap() }   // انقطاع البث ليس توقف عدّاد
        status("انقطع البث — لا يُحتسب توقفًا للعدّادين")
        publish()
    }

    override fun onFinished() {
        wh.post {
            pipeline?.swing?.flush()
            running = false
            status("انتهى الفيديو")
            publish()
        }
    }

    private var roiWarnKey = 0L
    private var sizeWarnKey = 0L

    private fun process(gray: ByteArray, w: Int, h: Int, t: Double) {
        val p = pipeline ?: return
        connected = true
        val full = Roi.toMat(gray, w, h)
        // الإعدادات الافتراضية مأخوذة من فيديو 2560×1944؛ إن كانت حلقة أي عدّاد خارج حدود إطار الكاميرا الفعلي
        // لا نعالج (كان يرمي CvException من OpenCV) بل نعرض الصورة ليعاير المستخدم عليها.
        val outside = p.meters.withIndex().filter { (_, m) ->
            val r = 1.02 * m.radius
            m.cx - r < 0 || m.cy - r < 0 || m.cx + r > w || m.cy + r > h
        }.map { it.index }
        val cc = cfg
        if (cc.calW > 0 && (cc.calW != w || cc.calH != h) && sizeWarnKey != w.toLong() * 100000 + h) {
            sizeWarnKey = w.toLong() * 100000 + h
            val msg = "تنبيه: عُويرت المواضع على إطار ${cc.calW}×${cc.calH} والبث الآن ${w}×${h} — أعد المعايرة إن اختلفت الصورة."
            CamLog.e(msg); status(msg)
        }
        if (outside.isEmpty()) { roiWarnKey = 0L; p.process(full, t) }
        else {
            val key = w.toLong() * 100000 + h
            if (roiWarnKey != key) {
                roiWarnKey = key
                val msg = "المعايرة خارج حدود الصورة ${w}×${h} (العدّاد ${outside.map { it + 1 }}). افتح تبويب المعايرة وحدّد العدّادين على صورة الكاميرا."
                CamLog.e(msg); status(msg)
            }
        }
        lastT = t
        val now = System.currentTimeMillis()
        if (now - lastUi > 200) {
            lastUi = now
            synchronized(lock) { latestMat?.release(); latestMat = full }
            publish(w, h)
        } else full.release()
        fpsCount++
        if (fpsT == 0L) fpsT = now
        if (now - fpsT >= 2000) { fps = fpsCount * 1000.0 / (now - fpsT); fpsCount = 0; fpsT = now }
    }

    private fun publish(w: Int = 0, h: Int = 0) {
        val p = pipeline ?: return
        val smp = p.samples
        val ms = p.meters.indices.map { i ->
            val s = smp.getOrNull(i)
            MeterState(
                p.meters[i].name, s?.valid ?: false, p.swing.isActive(i),
                p.trackers[i].totalDegrees, s?.rawAngleDeg ?: 0.0, p.swing.currentDegrees(i),
                s?.contrast ?: 0.0, s?.shiftX ?: 0.0, s?.shiftY ?: 0.0,
                p.swing.episodeDegrees(i),
            )
        }
        val st = UiState(connected, running, w, h, ms, fps)
        ui.post { uiListener?.onState(st) }
    }

    private fun status(m: String) { ui.post { uiListener?.onStatus(m) } }

    // ---------- نتائج الزفات ----------
    private fun wallAt(t: Double) = System.currentTimeMillis() - ((lastT - t) * 1000).toLong()

    private fun onSwingResult(r: SwingResult) {
        if (recMode) return      // في وضع التسجيلات لا يُسجَّل شيء من البث المباشر
        val names = cfg.meters.map { it.name }
        val kind = if (r.type == SwingType.FULL) "زفة كاملة" else "زفة عداد"
        val parts = r.parts.joinToString("\n") { "• ${names[it.meter]}: %.2f برميل (%.0f°)".format(Locale.US, it.barrels, it.degrees) }
        var seqTxt = ""
        var rec: SwingRecord? = null
        if (persist) {
            // تسجّل مرة واحدة فقط: العملية نفسها لا تتكرر (إعادة إرسال/إعادة اتصال)
            rec = truckFlow.record(r, wallAt(r.startT), wallAt(r.endT))
            if (rec.duplicate) {
                CamLog.i("تجاهل تسجيل مكرر لزفة موجودة (رقم ${rec.seq})")
                status("زفة مكررة لم تُسجَّل مرة ثانية (رقم ${rec.seq})")
                return
            }
            seqTxt = "زفة رقم ${rec.seq} — "
        }
        val truckTxt = when {
            rec == null -> ""
            rec.truckName.isNotEmpty() -> "\nالوايت: ${rec.truckName} — المسجَّل %.2f برميل (الكمية المدخلة)".format(Locale.US, rec.total)
            rec.photo.isNotEmpty() -> "\nالوايت: لم يُحدَّد بعد (الكمية المقاسة مسجّلة، وتُستبدل بكمية الوايت عند اختياره)"
            else -> ""
        }
        val kindShown = if (rec != null && rec.truckName.isNotEmpty()) "زفة كاملة" else kind
        val shownTotal = if (rec != null && rec.truckName.isNotEmpty()) "مقاس %.2f برميل".format(Locale.US, r.totalBarrels) else "الإجمالي: %.2f برميل".format(Locale.US, r.totalBarrels)
        val text = "$seqTxt$kindShown\n$parts\n$shownTotal$truckTxt" +
            (if (r.notes.isNotEmpty()) "\n⚠ ${r.notes}" else "")
        ui.post { uiListener?.onSwing(text) }
    }

    // ---------- المعايرة ----------
    fun setStillFromLatest(): Boolean = synchronized(lock) {
        val l = latestMat ?: return false
        stillMat?.release(); stillMat = l.clone(); true
    }

    /** معاينة آخر إطار حي بتصغير يناسب العرض. */
    fun latestBitmap(maxDim: Int): Bitmap? = synchronized(lock) {
        val m = latestMat ?: return null
        val sc = min(1.0, maxDim.toDouble() / max(m.cols(), m.rows()))
        val out = Mat()
        Imgproc.resize(m, out, Size(m.cols() * sc, m.rows() * sc), 0.0, 0.0, Imgproc.INTER_AREA)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        out.release()
        bmp
    }

    fun setStill(gray: ByteArray, w: Int, h: Int) = synchronized(lock) {
        stillMat?.release(); stillMat = Roi.toMat(gray, w, h)
    }

    /** بتصغير يناسب العرض؛ المنطقة بإحداثيات الإطار الكامل. تُرجع البتماب والمنطقة الفعلية المقصوصة. */
    fun stillBitmap(x0: Double, y0: Double, x1: Double, y1: Double, maxDim: Int): Pair<Bitmap, FloatArray>? = synchronized(lock) {
        val m = stillMat ?: return null
        val rx0 = max(0, x0.roundToInt()); val ry0 = max(0, y0.roundToInt())
        val rx1 = min(m.cols(), x1.roundToInt()); val ry1 = min(m.rows(), y1.roundToInt())
        if (rx1 - rx0 < 8 || ry1 - ry0 < 8) return null
        val sub = Mat(m, Rect(rx0, ry0, rx1 - rx0, ry1 - ry0))
        val sc = min(1.0, maxDim.toDouble() / max(sub.cols(), sub.rows()))
        val out = Mat()
        Imgproc.resize(sub, out, Size(sub.cols() * sc, sub.rows() * sc), 0.0, 0.0, Imgproc.INTER_AREA)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        sub.release(); out.release()
        Pair(bmp, floatArrayOf(rx0.toFloat(), ry0.toFloat(), rx1.toFloat(), ry1.toFloat()))
    }

    /** يحفظ مرجع كل عدّاد (ROI) من لقطة المعايرة الحالية مع المعايرة الجديدة. */
    /** يعيد null عند النجاح، وإلا نص الخطأ. المواضع تُحفظ أولًا (تبقى حتى لو فشل حفظ المرجع). */
    fun saveCalibration(newCfg: AppConfig): String? = synchronized(lock) {
        val m = stillMat ?: return "التقط لقطة أولًا (زر «التقاط من البث»)"
        val w = m.cols(); val h = m.rows()
        val outside = newCfg.meters.withIndex().filter { (_, mc) ->
            val r = 1.02 * mc.radius
            mc.cx - r < 0 || mc.cy - r < 0 || mc.cx + r > w || mc.cy + r > h
        }.map { it.index + 1 }
        if (outside.isNotEmpty())
            return "العدّاد ${outside.joinToString("، ")} خارج حدود الصورة ${w}×${h} — المس موضعه على الصورة ثم احفظ"
        try {
            val saved = newCfg.copy(calW = w, calH = h)
            store.save(saved)
            newCfg.meters.forEachIndexed { i, mc -> store.saveReference(i, Roi.extract(m, mc)) }
            cfg = saved
            CamLog.i("حُفظت المعايرة على إطار ${w}×${h}: " + saved.meters.joinToString { "%s(%.0f,%.0f,r=%.0f)".format(Locale.US, it.name, it.cx, it.cy, it.radius) })
            null
        } catch (t: Throwable) {
            CamLog.e("فشل حفظ المعايرة", t)
            "فشل حفظ المعايرة: ${t.message}"
        }
    }

    // ---------- فحص الدقة على فيديو ----------
    /** يشغّل المعايرة الحالية على كل إطارات فيديو (مستقل عن البث الحي) ويعيد تقريرًا نصيًا. */
    fun analyzeVideo(uri: Uri, progress: (Int) -> Unit, done: (String) -> Unit) {
        Thread({
            val c = store.load()
            val refs = List(c.meters.size) { store.loadReference(it) }
            val results = ArrayList<SwingResult>()
            val p = Pipeline(c.meters, c.swing, refs) { results.add(it) }
            val dur = VideoFileSource.durationMs(ctx, uri)
            val latch = CountDownLatch(1)
            val src = VideoFileSource(ctx, uri, 100, realtime = false)
            src.start(object : FrameSource.Listener {
                override fun onFrame(gray: ByteArray, width: Int, height: Int, tSec: Double) {
                    val full = Roi.toMat(gray, width, height)
                    p.process(full, tSec); full.release()
                    if (dur > 0) progress(min(100, (tSec * 1000 * 100 / dur).toInt()))
                }
                override fun onStatus(message: String) {}
                override fun onDisconnected() {}
                override fun onFinished() { latch.countDown() }
            })
            latch.await()
            p.swing.flush()
            val sb = StringBuilder()
            sb.append("إطارات معالجة: ${p.frames}\n")
            c.meters.forEachIndexed { i, m ->
                val d = p.trackers[i].totalDegrees
                sb.append("%s: %.1f° = %.3f برميل (إطارات بلا قياس: %d)\n".format(Locale.US, m.name, d, d / DEG_PER_BARREL, p.invalid[i]))
            }
            sb.append("زفات مكتشفة: ${results.size}\n")
            results.forEach { r ->
                sb.append("• ${if (r.type == SwingType.FULL) "زفة كاملة" else "زفة عداد"}: ")
                sb.append(r.parts.joinToString(" | ") { "${c.meters[it.meter].name} %.3f".format(Locale.US, it.barrels) })
                sb.append(" = %.3f برميل".format(Locale.US, r.totalBarrels))
                if (r.notes.isNotEmpty()) sb.append("  (${r.notes})")
                sb.append('\n')
            }
            ui.post { done(sb.toString()) }
        }, "analyze-video").start()
    }
}
