package com.smartwater.monitor.camera

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** مقطع تسجيل على الجهاز (بوقت الجهاز المحلي معبَّرًا عنه بميلي ثانية). */
class RecSegment(val startMs: Long, val endMs: Long)

fun interface RecordingFrameSink {
    /** إطار رمادي (Y) مفكوك من التسجيل. tMs = وقت التسجيل بتوقيت جهاز Hikvision. المصفوفة تُعاد استخدامها بعد العودة. */
    fun onFrame(gray: ByteArray, width: Int, height: Int, tMs: Long)
}

enum class ReadEnd { REACHED_END, NO_DATA, ERROR, CANCELLED }

class ReadOutcome(val end: ReadEnd, val lastFrameMs: Long, val frames: Int, val message: String)

/**
 * القراءة من تسجيلات جهاز Hikvision (بحث + تشغيل بالوقت + فك الإطارات) — دون RTSP.
 * كل الأوقات بتوقيت الجهاز نفسه (لا ساعة الهاتف) فتبقى متسقة مع التسجيل.
 */
interface RecordingProvider {
    /** الوقت الحالي لساعة الجهاز (ms) أو null إن تعذّر قراءتها. */
    fun deviceNowMs(): Long?

    /** مقاطع التسجيل التي تتقاطع مع [fromMs, toMs] على القناة المنطقية، أو null عند فشل البحث. */
    fun findRecordings(channel: Int, fromMs: Long, toMs: Long): List<RecSegment>?

    /**
     * يشغّل التسجيل من fromMs إلى toMs ويسلّم الإطارات إلى [sink] (إطار واحد على الأكثر كل minStepMs من وقت التسجيل).
     * يحجب حتى نهاية المقطع أو الإلغاء. fastWhen: متى true يُسرَّع التشغيل (للّحاق) وإلا بسرعة عادية.
     */
    fun readFrames(
        channel: Int, streamType: Int, fromMs: Long, toMs: Long, minStepMs: Long,
        fastWhen: () -> Boolean, cancel: () -> Boolean, sink: RecordingFrameSink,
    ): ReadOutcome
}

/** تقرير فحص قدرات التسجيل على جهازك الفعلي (زر «فحص التسجيلات»). */
object RecordingProbe {
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private fun t(ms: Long) = fmt.format(Date(ms))

    fun run(p: RecordingProvider, channels: List<Pair<String, Int>>, streamType: Int, log: (String) -> Unit) {
        val now = p.deviceNowMs()
        if (now == null) { log("✗ تعذّرت قراءة ساعة الجهاز (NET_DVR_GetDVRConfig/GET_TIMECFG) — لا يمكن حساب أوقات التسجيل"); return }
        val phone = System.currentTimeMillis()
        log("✓ ساعة الجهاز: ${t(now)} (فرقها عن ساعة الهاتف ${(now - phone) / 1000} ث)")
        for ((name, ch) in channels) {
            log("— $name (القناة $ch)")
            val segs = p.findRecordings(ch, now - 30 * 60_000L, now)
            if (segs == null) { log("  ✗ فشل البحث في التسجيلات (NET_DVR_FindFile_V30) — راجع سجل الاتصال لرمز الخطأ"); continue }
            if (segs.isEmpty()) { log("  ✗ لا تسجيلات خلال آخر 30 دقيقة (هل التسجيل مفعّل لهذه القناة؟ جدول التسجيل؟ القرص؟)"); continue }
            val last = segs.maxOf { it.endMs }
            log("  ✓ ${segs.size} مقطع؛ أقدمها ${t(segs.minOf { it.startMs })}، وآخرها ينتهي ${t(last)}")
            val lag = (now - last) / 1000
            log("  • تأخر آخر تسجيل متاح عن الوقت الحالي: ${lag} ث" + if (lag > 60) " (أكبر من مهلة الدقيقة — قد تتأخر النتائج)" else "")
            // اختبار تشغيل فعلي: 8 ثوانٍ قبل نهاية آخر مقطع (أو قبل 90ث من الآن إن كان الأحدث)
            val to = minOf(last, now - 15_000L)
            val from = to - 8_000L
            var n = 0; var first = -1L; var lastT = -1L; var w = 0; var h = 0
            val t0 = System.currentTimeMillis()
            val out = p.readFrames(ch, streamType, from, to, 200L, { false }, { System.currentTimeMillis() - t0 > 40_000 }) { _, fw, fh, tMs ->
                n++; if (first < 0) first = tMs; lastT = tMs; w = fw; h = fh
            }
            if (n == 0) { log("  ✗ التشغيل بالوقت لم يُنتج إطارات: ${out.end} — ${out.message}"); continue }
            val span = (lastT - first).coerceAtLeast(1)
            log("  ✓ فُكّ $n إطارًا ${w}×$h (≈%.1f إطار/ث من وقت التسجيل)".format(Locale.US, n * 1000.0 / span))
            log("  • أول إطار ${t(first)} (المطلوب ${t(from)}، الفرق ${(first - from) / 1000.0} ث)، وآخر إطار ${t(lastT)}")
            log("  • زمن التحميل الفعلي ${(System.currentTimeMillis() - t0) / 1000.0} ث لمقطع 8 ث، النتيجة ${out.end}")
        }
        log("انتهى الفحص. أي ✗ أعلاه يعني أن وضع «التسجيلات» لن يعمل على هذه القناة قبل معالجته.")
    }
}
