package com.smartwater.monitor.engine

import android.content.Context
import android.graphics.BitmapFactory
import android.os.SystemClock
import com.smartwater.monitor.camera.CamLog
import com.smartwater.monitor.camera.ReadEnd
import com.smartwater.monitor.camera.RecordingFrameSink
import com.smartwater.monitor.camera.RecordingProvider
import com.smartwater.monitor.camera.SnapshotProvider
import com.smartwater.monitor.core.FillSession
import com.smartwater.monitor.core.FillSnapshot
import com.smartwater.monitor.core.FillState
import com.smartwater.monitor.core.GrayFrame
import com.smartwater.monitor.core.MeterConfig
import com.smartwater.monitor.core.MeterSample
import com.smartwater.monitor.core.MeterTracker
import com.smartwater.monitor.core.PresenceEvent
import com.smartwater.monitor.core.PresenceParams
import com.smartwater.monitor.core.SwingResult
import com.smartwater.monitor.core.TrackerParams
import com.smartwater.monitor.core.TruckPresenceDetector
import com.smartwater.monitor.core.Wiring
import com.smartwater.monitor.data.AppConfig
import org.json.JSONObject
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.concurrent.ConcurrentLinkedQueue

/** حالة الحساب المعروضة للمستخدم. */
class RecStatus(
    val label: String,
    val state: FillState?,
    val truckName: String,
    val perMeter: List<Double>,
    val total: Double,
    val flowStartMs: Long?,
    val lastFlowMs: Long?,
    val processedMs: Long?,
    val deviceNowMs: Long?,
    val graceRemainingSec: Double?,
    val note: String,
)

/** تتبّع العدّادين على إطارات مسجَّلة بأي دقة: تُحوَّل الصورة إلى مقاس المعايرة كي تبقى مواضع العدّادين صحيحة. */
class MeterBank(private val meters: List<MeterConfig>, refs: List<GrayFrame?>, private val calW: Int, private val calH: Int) {
    private val trackers = meters.mapIndexed { i, m -> MeterTracker(m, TrackerParams(), refs.getOrNull(i)) }

    /** null = مواضع العدّادين خارج الصورة (لا قياس؛ يُعامَل كفجوة لا كتوقف). */
    fun samples(gray: ByteArray, w: Int, h: Int, tSec: Double): List<MeterSample>? {
        var full = Roi.toMat(gray, w, h)
        try {
            if (calW > 0 && (calW != w || calH != h)) {
                val r = Mat(); Imgproc.resize(full, r, Size(calW.toDouble(), calH.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
                full.release(); full = r
            }
            val fw = full.cols(); val fh = full.rows()
            if (meters.any { m -> val r = 1.02 * m.radius; m.cx - r < 0 || m.cy - r < 0 || m.cx + r > fw || m.cy + r > fh }) return null
            return meters.indices.map { trackers[it].update(Roi.extract(full, meters[it]), tSec) }
        } finally { full.release() }
    }
}

/**
 * حساب الماء من تسجيلات جهاز Hikvision (لا من البث المباشر):
 *  1) خيط الوجود: لقطة من القناة 7 كل ~2ث ← كاشف وجود الوايت ← وقت الدخول بوقت الجهاز + تعرّف على الهوية.
 *  2) خيط الجلسات: بعد دقيقة من الدخول (مهلة جاهزية التسجيل) يقرأ تسجيل قناة العدّادات *من قبيل الدخول*،
 *     فلا تضيع حركة الدقيقة الأولى، ويحدّد بدء التدفق الفعلي من حركة العدّادات لا من دخول الوايت.
 *  3) القراءة تتابع من آخر إطار معالَج (يُحفظ)، وغياب التسجيل ينتظر ولا يعني توقف الماء.
 */
class RecordingMonitor(
    ctx: Context,
    private val provider: () -> RecordingProvider?,
    private val snapshots: () -> SnapshotProvider?,
    private val config: () -> AppConfig,
    private val bankFactory: () -> MeterBank,
    private val truckFlow: TruckCoordinator,
    private val onStatus: (RecStatus) -> Unit,
) {
    companion object {
        const val PRE_MS = 15_000L          // نبدأ القراءة قبل دخول الوايت (تغطية أي تأخر في الكشف)
        const val START_DELAY_MS = 60_000L  // مهلة الدقيقة الأولى لجاهزية التسجيل/عرض النتائج
        const val TAIL_LAG_MS = 10_000L     // لا نقرأ آخر ثوانٍ لم يكتمل تسجيلها
        const val POST_LEAVE_MS = 5_000L    // نعالج قليلًا بعد مغادرة الوايت
        const val MIN_CHUNK_MS = 8_000L
        const val MAX_CHUNK_MS = 300_000L
        const val STEP_MS = 200L            // إطار كل 200ms من وقت التسجيل (5 إطارات/ث)
        const val GRACE_SEC = 60.0          // مهلة التوقف قبل اعتماد النهاية
        const val GIVE_UP_MS = 30 * 60_000L // وايت غادر والتسجيل لا يصل منذ 30 دقيقة: أغلق بملاحظة
    }

    private sealed class Ev {
        class Entered(val tMs: Long, val jpeg: ByteArray?) : Ev()
        class Left(val tMs: Long) : Ev()
    }

    private class Pending(val enterMs: Long, val epId: Long)

    private inner class Live(val id: String, val enterMs: Long, val epId: Long, val resumed: Boolean) {
        val bank = bankFactory()
        var readPos = enterMs - PRE_MS
        var backoffUntil = 0L
        var streak = 0
        var note = ""
        var recSeq = 0
        @Volatile var abort = false
        val fill = FillSession(id, enterMs, config().meters.size, if (config().wiring == 1) Wiring.SERIES else Wiring.PARALLEL,
            config().swing, GRACE_SEC) { snap, res -> onFinalized(this, snap, res) }
    }

    private val prefs = ctx.getSharedPreferences("rec_state", Context.MODE_PRIVATE)
    private val events = ConcurrentLinkedQueue<Ev>()
    private val pending = java.util.ArrayDeque<Pending>()
    @Volatile private var cur: Live? = null
    @Volatile private var lastDone: RecStatus? = null
    @Volatile private var running = false
    @Volatile private var resetBg = false
    @Volatile private var presenceNote = ""
    private var th1: Thread? = null
    private var th2: Thread? = null
    private var lastCkpt = 0L

    fun start() {
        if (running) return
        running = true
        th1 = Thread({ presenceLoop() }, "rec-presence").also { it.start() }
        th2 = Thread({ mainLoop() }, "rec-main").also { it.start() }
        CamLog.i("بدأ وضع التسجيلات: كشف الوايت على القناة ${config().truckChannel} + قراءة تسجيل القناة ${config().channel}")
    }

    fun stop() {
        running = false
        cur?.abort = true
        th1?.interrupt(); th2?.interrupt()
    }

    /** يعتمد صورة القناة 7 الحالية خلفيةً فارغة (استدعِها والمنطقة خالية). */
    fun resetBackground() { resetBg = true }

    // ------------------------------------------------------------------ خيط الوجود
    private fun presenceLoop() {
        var det = TruckPresenceDetector(PresenceParams(zone = parseZone(config().truckZone)))
        var zoneKey = config().truckZone
        while (running) {
            val t0 = SystemClock.elapsedRealtime()
            try {
                val c = config()
                if (c.truckZone != zoneKey) { zoneKey = c.truckZone; det = TruckPresenceDetector(PresenceParams(zone = parseZone(zoneKey))) }
                val prov = provider(); val snap = snapshots()
                if (c.truckChannel <= 0) presenceNote = "كشف الوايت معطّل (قناة الوايتات = 0)"
                else if (prov == null || snap == null) presenceNote = "بانتظار الاتصال بالجهاز"
                else {
                    val dev = prov.deviceNowMs()
                    val jpeg = if (dev != null) snap.snapshotJpeg(c.truckChannel) else null
                    if (dev == null) presenceNote = "تعذّرت قراءة ساعة الجهاز"
                    else if (jpeg == null) presenceNote = "تعذّر التقاط صورة القناة ${c.truckChannel}"
                    else {
                        val g = decodeGray(jpeg)
                        if (g == null) presenceNote = "تعذّر فك لقطة الوايت"
                        else {
                            presenceNote = ""
                            if (resetBg) { resetBg = false; det.setBackground(g.first, g.second, g.third); CamLog.i("اعتُمدت صورة القناة ${c.truckChannel} خلفية فارغة") }
                            when (val e = det.update(dev, g.first, g.second, g.third)) {
                                is PresenceEvent.Entered -> events.add(Ev.Entered(e.tMs, jpeg))
                                is PresenceEvent.Left -> events.add(Ev.Left(e.tMs))
                                is PresenceEvent.Replaced -> { events.add(Ev.Left(e.tMs)); events.add(Ev.Entered(e.tMs, jpeg)) }
                                null -> {}
                            }
                        }
                    }
                }
            } catch (_: InterruptedException) { return
            } catch (t: Throwable) { CamLog.e("خيط كشف الوايت", t); presenceNote = "خطأ في كشف الوايت: ${t.message}" }
            val rest = 2000 - (SystemClock.elapsedRealtime() - t0)
            if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return }
        }
    }

    private fun decodeGray(jpeg: ByteArray): Triple<ByteArray, Int, Int>? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= 640) s *= 2
        val b = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h); b.recycle()
        val g = ByteArray(w * h)
        for (i in px.indices) { val p = px[i]; g[i] = ((((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000).toByte() }
        return Triple(g, w, h)
    }

    private fun parseZone(s: String): DoubleArray? {
        val v = s.split(",").mapNotNull { it.trim().toDoubleOrNull() }
        if (v.size != 4 || v[2] <= 0 || v[3] <= 0) return null
        return doubleArrayOf(v[0] / 100, v[1] / 100, v[2] / 100, v[3] / 100)
    }

    // ------------------------------------------------------------------ خيط الجلسات
    private fun mainLoop() {
        restore()
        while (running) {
            try { tick() } catch (_: InterruptedException) { return }
            catch (t: Throwable) { CamLog.e("خطأ في حلقة التسجيلات", t); cur?.note = "خطأ: ${t.message}" }
            try { Thread.sleep(500) } catch (_: InterruptedException) { return }
        }
    }

    private fun tick() {
        drainEvents()
        if (cur == null) pending.poll()?.let { begin(it.enterMs, it.epId, false, null) }
        val c = cur
        if (c == null) { publishIdle(); return }
        step(c)
    }

    private fun drainEvents() {
        while (true) {
            when (val e = events.poll() ?: return) {
                is Ev.Entered -> {
                    CamLog.i("دخل وايت بوقت الجهاز ${e.tMs}")
                    lastDone = null
                    pending.add(Pending(e.tMs, truckFlow.beginEpisode(e.jpeg)))
                }
                is Ev.Left -> {
                    val c = cur
                    if (c != null && c.fill.truckLeftMs == null) { c.fill.truckLeft(e.tMs); checkpoint(c, true); CamLog.i("غادر الوايت ${c.id}") }
                    else pending.pollLast()?.let { truckFlow.closeEpisode(it.epId, false) }
                }
            }
        }
    }

    private fun begin(enterMs: Long, epId: Long, resumed: Boolean, leftMs: Long?) {
        val c = Live("S$enterMs", enterMs, epId, resumed)
        if (leftMs != null) c.fill.truckLeft(leftMs)
        cur = c
        checkpoint(c, true)
        CamLog.i("جلسة تعبئة ${c.id}${if (resumed) " (مستأنفة بعد إعادة التشغيل: تُعاد المعالجة من قبيل الدخول)" else ""}")
    }

    private fun step(c: Live) {
        val prov = provider() ?: run { c.note = "بانتظار الاتصال بالجهاز"; publish(c, null); return }
        val now = prov.deviceNowMs() ?: run { c.note = "ساعة الجهاز غير متاحة — العملية مفتوحة"; publish(c, null); return }
        val wait = c.enterMs + START_DELAY_MS - now
        if (wait > 0 && !c.resumed) { c.note = "مهلة الدقيقة الأولى: القراءة بعد ${wait / 1000} ث"; publish(c, now); return }
        val left = c.fill.truckLeftMs
        val avail = now - TAIL_LAG_MS
        val limit = if (left != null) minOf(avail, left + POST_LEAVE_MS) else avail

        // الإغلاق النهائي: غادر الوايت وقُرئ التسجيل حتى ما بعد مغادرته
        if (left != null && avail >= left + POST_LEAVE_MS && c.readPos >= left + POST_LEAVE_MS - 1500) { finishSession(c, ""); return }
        if (left != null && now - left > GIVE_UP_MS) { finishSession(c, "تعذّر قراءة بقية التسجيل (30 دقيقة)"); return }
        if (SystemClock.elapsedRealtime() < c.backoffUntil) { publish(c, now); return }
        val gap = limit - c.readPos
        if (gap < MIN_CHUNK_MS && !(left != null && gap >= 1500)) { publish(c, now); return }

        val cfg = config()
        val from = c.readPos
        val to = minOf(limit, from + MAX_CHUNK_MS)
        val sink = RecordingFrameSink { gray, w, h, tMs ->
            try {
                val s = c.bank.samples(gray, w, h, (tMs - c.enterMs) / 1000.0)
                if (s == null) c.fill.markGap() else c.fill.feed(tMs, s)
            } catch (t: Throwable) { CamLog.e("معالجة إطار مسجَّل", t) }
        }
        val fastWhen = {
            cfg.fastCatchUp && (c.fill.snapshot().state == FillState.WAITING_FLOW || c.fill.snapshot().state == FillState.TRUCK_DETECTED) &&
                (limit - c.readPos) > 45_000L
        }
        publish(c, now)
        val out = prov.readFrames(cfg.channel, cfg.streamType, from, to, STEP_MS, fastWhen, { !running || c.abort }, sink)
        if (out.frames > 0) {
            c.readPos = maxOf(c.readPos, out.lastFrameMs + 1); c.streak = 0; c.note = ""
            checkpoint(c, false)
        } else if (out.end != ReadEnd.CANCELLED) {
            c.streak++
            c.backoffUntil = SystemClock.elapsedRealtime() + minOf(5_000L * c.streak, 60_000L)
            c.note = "التسجيل غير متاح بعد أو متأخر — العملية مفتوحة وتُستأنف عند عودته (${out.message})"
            CamLog.e("قراءة التسجيل بلا إطارات ${out.end}: ${out.message}")
            // فجوة حقيقية في التسجيل (ما بعدها ماضٍ بعيد): نتجاوزها كفجوة لا كتوقف
            if (c.streak >= 3 && now - to > 120_000L) {
                c.fill.markGap(); c.readPos = to; c.streak = 0
                c.note = "فجوة في التسجيل تجاوزناها (لا تُحتسب توقفًا للماء)"
            }
        }
    }

    private fun finishSession(c: Live, why: String) {
        c.fill.finish()
        val snap = c.fill.snapshot()
        val flowed = c.fill.hasFlowed || snap.finalizedOnce
        truckFlow.closeEpisode(c.epId, flowed)
        prefs.edit().remove("session").apply()
        lastDone = statusOf(c, snap, null, if (why.isNotEmpty()) why else if (flowed) "" else "لم يتدفق ماء أثناء وجود الوايت — لا سجل")
        CamLog.i("أُغلقت الجلسة ${c.id}: ${snap.totalBarrels} برميل مقاس، تدفق=$flowed $why")
        cur = null
        onStatus(lastDone!!)
    }

    /** اعتماد (أو تحديث) سجل الجلسة: يحدث بعد انتهاء مهلة الدقيقة أو عند الإغلاق؛ والاستئناف يحدّث السجل نفسه. */
    private fun onFinalized(c: Live, snap: FillSnapshot, res: SwingResult) {
        val (st, en) = c.fill.flowWindowMs()
        val rec = truckFlow.recordSession(c.epId, c.id, res, st, en)
        c.recSeq = rec.seq
        CamLog.i("اعتُمدت الجلسة ${c.id} → سجل #${rec.seq}: مقاس %.3f برميل، المسجَّل %.3f${if (rec.truckName.isNotEmpty()) " (${rec.truckName})" else ""}"
            .format(java.util.Locale.US, snap.totalBarrels, rec.total))
    }

    // ------------------------------------------------------------------ الحالة والحفظ
    private fun statusOf(c: Live, s: FillSnapshot, now: Long?, extra: String = ""): RecStatus {
        val name = truckFlow.episodeTruck(c.epId)?.name ?: ""
        val st = s.state
        val label = when (st) {
            FillState.TRUCK_DETECTED -> "تم التعرف على الوايت" + if (c.epId < 0 || name.isNotEmpty()) "" else " (الهوية بانتظار اختيارك)"
            else -> st.ar
        }
        val note = listOf(extra, c.note, s.notes).filter { it.isNotEmpty() }.joinToString(" • ")
        return RecStatus(label, st, name, s.meterBarrels, s.totalBarrels, s.flowStartMs, s.lastFlowMs,
            if (s.lastProcessedMs == Long.MIN_VALUE) null else s.lastProcessedMs, now, s.graceRemainingSec, note)
    }

    private fun publish(c: Live, now: Long?) = onStatus(statusOf(c, c.fill.snapshot(), now))

    private fun publishIdle() {
        val d = lastDone
        if (d != null) { onStatus(d); return }
        val n = pending.size
        onStatus(RecStatus(if (n > 0) FillState.TRUCK_DETECTED.ar else FillState.IDLE.ar, FillState.IDLE, "", emptyList(), 0.0, null, null, null, null, null,
            presenceNote.ifEmpty { if (provider() == null) "بانتظار الاتصال بالجهاز" else "" }))
    }

    /** نقطة استئناف بعد إغلاق التطبيق: الجلسة وآخر وقت معالَج. عند الاستئناف تُعاد المعالجة من قبيل الدخول فلا يضيع إطار ولا يتكرر احتساب. */
    private fun checkpoint(c: Live, force: Boolean) {
        val t = SystemClock.elapsedRealtime()
        if (!force && t - lastCkpt < 5000) return
        lastCkpt = t
        try {
            prefs.edit().putString("session", JSONObject().put("id", c.id).put("enterMs", c.enterMs)
                .put("leftMs", c.fill.truckLeftMs ?: JSONObject.NULL).put("readPos", c.readPos)
                .put("lastProcessedMs", if (c.fill.lastProcessedMs == Long.MIN_VALUE) JSONObject.NULL else c.fill.lastProcessedMs).toString()).apply()
        } catch (_: Exception) {}
    }

    private fun restore() {
        val js = prefs.getString("session", null) ?: return
        try {
            val j = JSONObject(js)
            val left = if (j.isNull("leftMs")) null else j.getLong("leftMs")
            begin(j.getLong("enterMs"), -1L, true, left)
        } catch (e: Exception) { CamLog.e("تعذّر استرجاع الجلسة", e); prefs.edit().remove("session").apply() }
    }
}
