package com.smartwater.monitor.core

import kotlin.math.abs

data class PresenceParams(
    val pixelDiff: Float = 28f,      // فرق السطوع (0..255) ليُعدّ الموضع متغيّرًا عن الخلفية
    val enterFrac: Double = 0.10,    // نسبة المواضع المتغيّرة في منطقة التعبئة لاعتبار وايت موجودًا
    val leaveFrac: Double = 0.05,    // أقل من هذا = المنطقة فارغة
    val enterSamples: Int = 3,       // عدد اللقطات المتتالية للتأكد من الدخول
    val leaveSamples: Int = 4,       // عدد اللقطات المتتالية للتأكد من الخروج
    val bgRate: Float = 0.05f,       // سرعة تحديث الخلفية (والمنطقة فارغة فقط) لتتبّع تغيّر الإضاءة
    val replaceFrac: Double = 0.5,   // تغيّر ≥ هذه النسبة من مواضع الوايت الأصلي = وايت آخر
    val replaceSamples: Int = 3,
    /** منطقة التعبئة كنِسَب من الصورة: x, y, w, h (null = كل الصورة). */
    val zone: DoubleArray? = null,
)

sealed class PresenceEvent {
    /** دخل وايت. tMs = وقت أول لقطة متغيّرة في سلسلة التأكيد (وقت البداية). */
    class Entered(val tMs: Long) : PresenceEvent()
    /** غادر الوايت. tMs = وقت أول لقطة فارغة في سلسلة التأكيد. */
    class Left(val tMs: Long) : PresenceEvent()
    /** استُبدل الوايت بآخر دون أن تفرغ المنطقة لفترة تُرصد. */
    class Replaced(val tMs: Long) : PresenceEvent()
}

/**
 * كشف وجود وايت في منطقة التعبئة من لقطات القناة 7 (بلا قراءة لوحات):
 * مقارنة شبكة رمادية 64×48 بصورة الخلفية الفارغة. الخلفية تُحدَّث ببطء ما دامت المنطقة فارغة.
 * الأوقات المُمرَّرة هي أوقات جهاز Hikvision (ms).
 */
class TruckPresenceDetector(private val p: PresenceParams = PresenceParams()) {
    companion object { const val W = 64; const val H = 48

        /** تصغير بمتوسط المساحة إلى شبكة 64×48. */
        fun grid(gray: ByteArray, w: Int, h: Int): FloatArray {
            val out = FloatArray(W * H)
            for (dy in 0 until H) {
                val sy0 = dy * h / H; val sy1 = maxOf(sy0 + 1, (dy + 1) * h / H).coerceAtMost(h)
                for (dx in 0 until W) {
                    val sx0 = dx * w / W; val sx1 = maxOf(sx0 + 1, (dx + 1) * w / W).coerceAtMost(w)
                    var s = 0L; var n = 0
                    for (y in sy0 until sy1) for (x in sx0 until sx1) { s += gray[y * w + x].toInt() and 0xFF; n++ }
                    out[dy * W + dx] = s.toFloat() / n
                }
            }
            return out
        }
    }

    private var bg: FloatArray? = null
    private var entry: FloatArray? = null
    private var entryMask: IntArray = IntArray(0)   // مواضع الوايت لحظة الدخول (المتغيّرة عن الخلفية)
    var present = false
        private set
    /** آخر نسبة تغيّر محسوبة (للعرض والتشخيص). */
    var lastFraction = 0.0
        private set
    private var enterRun = 0; private var enterStart = 0L
    private var leaveRun = 0; private var leaveStart = 0L
    private var replRun = 0; private var replStart = 0L

    private val cells: IntArray = run {
        val z = p.zone
        val x0 = ((z?.get(0) ?: 0.0) * W).toInt().coerceIn(0, W - 1)
        val y0 = ((z?.get(1) ?: 0.0) * H).toInt().coerceIn(0, H - 1)
        val x1 = (x0 + ((z?.get(2) ?: 1.0) * W).toInt()).coerceIn(x0 + 1, W)
        val y1 = (y0 + ((z?.get(3) ?: 1.0) * H).toInt()).coerceIn(y0 + 1, H)
        val l = ArrayList<Int>()
        for (y in y0 until y1) for (x in x0 until x1) l.add(y * W + x)
        l.toIntArray()
    }

    /** يعتمد هذه الصورة خلفيةً فارغة (يطلبها المستخدم عند خلو المنطقة). */
    fun setBackground(gray: ByteArray, w: Int, h: Int) {
        bg = grid(gray, w, h); present = false; enterRun = 0; leaveRun = 0; replRun = 0
    }

    fun hasBackground() = bg != null

    fun update(tMs: Long, gray: ByteArray, w: Int, h: Int): PresenceEvent? {
        val g = grid(gray, w, h)
        val b = bg
        if (b == null) { bg = g; return null }       // أول لقطة تُفترض فارغة إلى أن يعيّن المستخدم خلفية
        val f = changed(g, b)
        lastFraction = f
        if (!present) {
            if (f >= p.enterFrac) {
                if (enterRun == 0) enterStart = tMs
                enterRun++
                if (enterRun >= p.enterSamples) {
                    present = true; enterRun = 0; leaveRun = 0; replRun = 0
                    entry = g; entryMask = maskOf(g, b)
                    return PresenceEvent.Entered(enterStart)
                }
            } else {
                enterRun = 0
                for (i in b.indices) b[i] += p.bgRate * (g[i] - b[i])   // تتبّع تغيّر الإضاءة البطيء
            }
            return null
        }
        // الوايت موجود
        if (f < p.leaveFrac) {
            if (leaveRun == 0) leaveStart = tMs
            leaveRun++
            replRun = 0
            if (leaveRun >= p.leaveSamples) { present = false; leaveRun = 0; entry = null; return PresenceEvent.Left(leaveStart) }
            return null
        }
        leaveRun = 0
        val e = entry
        if (e != null && differsFromEntry(g, e) >= p.replaceFrac) {
            if (replRun == 0) replStart = tMs
            replRun++
            if (replRun >= p.replaceSamples) { replRun = 0; entry = g; entryMask = maskOf(g, b); return PresenceEvent.Replaced(replStart) }
        } else replRun = 0
        return null
    }

    private fun maskOf(g: FloatArray, b: FloatArray): IntArray = cells.filter { abs(g[it] - b[it]) > p.pixelDiff }.toIntArray()

    /** نسبة مواضع الوايت الأصلي التي تغيّر لونها الآن (وايت آخر أو غادر الأصلي)؛ الحركة الطفيفة لا تكفي. */
    private fun differsFromEntry(g: FloatArray, e: FloatArray): Double {
        if (entryMask.isEmpty()) return 0.0
        var n = 0
        for (i in entryMask) if (abs(g[i] - e[i]) > p.pixelDiff) n++
        return n.toDouble() / entryMask.size
    }

    private fun changed(a: FloatArray, b: FloatArray): Double {
        var n = 0
        for (i in cells) if (abs(a[i] - b[i]) > p.pixelDiff) n++
        return n.toDouble() / cells.size
    }
}
