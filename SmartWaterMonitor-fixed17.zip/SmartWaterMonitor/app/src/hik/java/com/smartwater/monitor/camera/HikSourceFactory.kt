package com.smartwater.monitor.camera

import android.content.Context
import android.os.SystemClock
import android.view.SurfaceHolder
import com.hikvision.netsdk.ExceptionCallBack
import com.hikvision.netsdk.HCNetSDK
import com.hikvision.netsdk.INT_PTR
import com.hikvision.netsdk.NET_DVR_JPEGPARA
import com.hikvision.netsdk.NET_DVR_DEVICEINFO_V30
import com.hikvision.netsdk.NET_DVR_FILECOND
import com.hikvision.netsdk.NET_DVR_FINDDATA_V30
import com.hikvision.netsdk.NET_DVR_STREAM_INFO
import com.hikvision.netsdk.NET_DVR_TIME
import com.hikvision.netsdk.NET_DVR_VOD_PARA
import com.hikvision.netsdk.PlaybackCallBack
import com.hikvision.netsdk.NET_DVR_PREVIEWINFO
import com.hikvision.netsdk.RealPlayCallBack
import org.MediaPlayer.PlayM4.Player
import org.MediaPlayer.PlayM4.PlayerCallBack
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgcodecs.Imgcodecs

object HikSourceFactory {
    const val AVAILABLE = true

    fun create(
        ctx: Context, ip: String, user: String, pass: String,
        channel: Int, streamType: Int, realChannelOverride: Int, holder: SurfaceHolder?, livePreview: Boolean = true,
    ): FrameSource = HikvisionSource(ip, user, pass, channel, streamType, realChannelOverride, holder, livePreview)
}

/**
 * اتصال Hikvision SDK (HCNetSDK) على المنفذ 8000 وبث القناة المطلوبة، وفك الترميز بـ PlayM4 مع
 * استدعاء العرض (YV12) لأخذ قناة Y.
 *
 * تنبيه: كُتب هذا الصنف وفق واجهة SDK (HCNetSDK/PlayM4 للأندرويد) كما في العيّنة الرسمية، لكنه لم يُجرَّب
 * مع كاميرا حقيقية ولا مع الـ SDK في بيئة التطوير. راجع أي اختلاف في أسماء الدوال بحسب إصدار SDK لديك.
 */
class HikvisionSource(
    private val ip: String,
    private val user: String,
    private val pass: String,
    private val channel: Int,
    private val streamType: Int,
    private val realChannelOverride: Int,
    private val holder: SurfaceHolder?,
    /** false: تسجيل دخول فقط (للتشغيل في الخلفية بلا شاشة)؛ لا بث مباشر ولا لقطات تحليل. التسجيلات ولقطة الوايت تعمل. */
    private val livePreview: Boolean = true,
) : FrameSource, SnapshotProvider, RecordingProvider {
    private var sdkObj: HCNetSDK? = null
    private val sdk get() = sdkObj!!
    private val player get() = Player.getInstance()

    @Volatile private var running = false
    private var userId = -1
    private var playId = -1
    private var port = -1
    private var listener: FrameSource.Listener? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var gotHead = false
    @Volatile private var gotData = false
    @Volatile private var firstFrameLogged = false
    private var watchdog: Thread? = null
    private var yBuf = ByteArray(0)
    private val pktCount = java.util.concurrent.atomic.AtomicLong()
    private val byteCount = java.util.concurrent.atomic.AtomicLong()
    private val inputFail = java.util.concurrent.atomic.AtomicLong()
    private val dispCb = java.util.concurrent.atomic.AtomicLong()
    private val decCb = java.util.concurrent.atomic.AtomicLong()
    private val otherTypes = java.util.concurrent.ConcurrentHashMap<Int, Int>()
    @Volatile private var lastInputErr = 0
    @Volatile private var strategy = 0          // 0 افتراضي، 1 فك برمجي، 2 فك عتادي
    @Volatile private var playStartMs = 0L
    private var realCh = 0
    // معلومات الجهاز لتحويل رقم القناة المنطقي (مثل 7) إلى رقم SDK الفعلي، ومنع تزامن لقطتين على الجلسة نفسها
    @Volatile private var chanNum = 0
    @Volatile private var startChan = 1
    @Volatile private var startDChan = 33
    private val capLock = Any()
    private val snapBuf = ByteArray(6 * 1024 * 1024)
    @Volatile private var snapLogged = 0
    @Volatile private var managed = true        // true: معاينة يديرها SDK (hHwnd) + لقطات JPEG للتحليل
    private var snapThread: Thread? = null
    private val snapOk = java.util.concurrent.atomic.AtomicLong()
    private val snapFail = java.util.concurrent.atomic.AtomicLong()
    private fun strategyName() = if (managed) "معاينة SDK المُدارة (hHwnd) + لقطات JPEG" else "رد نداء PlayM4 (احتياطي)"

    /** يستقبل YV12 من أي من callbacks PlayM4 (عرض/فك) ويمرّر قناة Y. */
    private fun onYv12(buf: ByteArray, w: Int, h: Int) {
        val n = w * h
        if (n <= 0 || buf.size < n) { CamLog.e("إطار غير صالح: ${w}×${h} حجم=${buf.size}"); return }
        if (yBuf.size != n) yBuf = ByteArray(n)
        System.arraycopy(buf, 0, yBuf, 0, n)
        lastFrameMs = SystemClock.elapsedRealtime()
        if (!firstFrameLogged) { firstFrameLogged = true; info("وصل أول إطار ${w}×${h}") }
        listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
    }

    private fun stats(): String {
        val pr = port
        val extra = if (pr != -1) try {
            " | decoderType=${player.getDecoderType(pr)} fps=${player.getCurrentFrameRate(pr)} " +
            "مفكوك=${player.getPlayedFrames(pr)} bufRemain=${player.getSourceBufferRemain(pr)} plErr=${player.getLastError(pr)}"
        } catch (t: Throwable) { " | stats-err=${t.message}" } else ""
        return "لقطاتJPEG نجحت=${snapOk.get()} فشلت=${snapFail.get()} | حزم=${pktCount.get()} بايت=${byteCount.get()} inputDataفشل=${inputFail.get()}(آخر خطأ $lastInputErr) " +
            "displayCB=${dispCb.get()} decodeCB=${decCb.get()} أنواع أخرى=$otherTypes$extra"
    }

    private fun info(m: String) { CamLog.i(m); listener?.onStatus(m) }
    private fun fail(m: String, t: Throwable? = null) { CamLog.e(m, t); listener?.onStatus("خطأ: $m") }

    private fun errName(code: Int) = when (code) {
        1 -> "كلمة المرور/المستخدم خاطئ"; 2 -> "صلاحيات غير كافية"; 3 -> "SDK غير مهيّأ"
        4 -> "رقم القناة خاطئ"; 5 -> "تجاوز عدد الاتصالات"; 6 -> "عدم توافق إصدار SDK مع الجهاز"
        7 -> "تعذّر الاتصال بالجهاز (IP/المنفذ/الشبكة)"; 8 -> "فشل الإرسال"; 9 -> "فشل الاستقبال"
        10 -> "انتهت مهلة الاستقبال"; 11 -> "بيانات خاطئة"; 17 -> "معامل خاطئ"; 23 -> "غير مدعوم"
        47 -> "المستخدم غير موجود"; 153 -> "الحساب مقفل (محاولات خاطئة كثيرة)"
        else -> "غير معروف"
    }
    private fun lastErr(): String { val c = sdk.NET_DVR_GetLastError(); return "رمز الخطأ $c (${errName(c)})" }

    override fun start(listener: FrameSource.Listener) {
        this.listener = listener
        running = true
        Thread({
            try { connect(listener) }
            catch (t: Throwable) {   // UnsatisfiedLinkError / NoSuchMethodError وغيرها: كانت تُسقط التطبيق بصمت
                fail("استثناء أثناء الاتصال (غالبًا مكتبات SDK .so أو نسخة jar لا تطابق)", t)
                listener.onDisconnected()
            }
        }, "hik-connect").start()
    }

    private fun connect(l: FrameSource.Listener) {
        CamLog.i("=== بدء الاتصال: $ip:8000 مستخدم=$user قناة=$channel بث=$streamType (CPU: ${android.os.Build.SUPPORTED_ABIS.joinToString()}) ===")
        sdkObj = HCNetSDK.getInstance()
            ?: run { fail("HCNetSDK.getInstance() أعادت null — مكتبات SDK لم تُحمَّل"); l.onDisconnected(); return }
        if (!sdk.NET_DVR_Init()) { fail("فشل NET_DVR_Init — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("NET_DVR_Init نجح")
        sdk.NET_DVR_SetConnectTime(5000)   // التوقيع في هذا الـ jar: (int) فقط
        sdk.NET_DVR_SetReconnect(10000, true)
        val dev = NET_DVR_DEVICEINFO_V30()
        userId = sdk.NET_DVR_Login_V30(ip, 8000, user, pass, dev)
        if (userId < 0) { fail("فشل تسجيل الدخول إلى $ip:8000 — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("تسجيل الدخول نجح userId=$userId — تناظرية=${dev.byChanNum} IP=${dev.byIPChanNum} " +
            "byStartChan=${dev.byStartChan} byStartDChan=${dev.byStartDChan}")
        chanNum = dev.byChanNum.toInt(); startChan = dev.byStartChan.toInt(); startDChan = dev.byStartDChan.toInt()
        // رقم القناة: تناظرية = byStartChan + n - 1، وإلا قنوات IP = byStartDChan + n - 1
        val real = when {
            realChannelOverride > 0 -> realChannelOverride
            dev.byChanNum.toInt() >= channel -> dev.byStartChan.toInt() + channel - 1
            else -> dev.byStartDChan.toInt() + channel - 1
        }
        info("تم الدخول. فتح القناة الفعلية $real (المطلوبة $channel) ...")
        sdk.NET_DVR_SetExceptionCallBack(ExceptionCallBack { type, handle, _ ->
            CamLog.e("استثناء SDK نوع=0x${Integer.toHexString(type)} handle=$handle — ${lastErr()}")
            // في الوضع المُدار مصدر الصور لقطات JPEG لا بث المعاينة، فإشعارات إعادة اتصال المعاينة (0x8005 …)
            // لا تعني انقطاع الصور؛ الانقطاع الحقيقي هو فقدان جلسة الاتصال (0x8000)
            if (!managed || type == 0x8000) l.onDisconnected()
        })

        val valid = holder?.surface?.isValid == true
        CamLog.i("سطح العرض لـ PlayM4: ${if (holder == null) "null" else if (valid) "صالح" else "غير صالح (لم يُنشأ بعد أو دُمّر)"}")

        realCh = real
        if (!livePreview) {
            info("وضع التسجيلات بلا معاينة (يعمل في الخلفية): تسجيل الدخول فقط؛ الكمية من التسجيلات")
            return
        }
        if (!startPlay()) {
            CamLog.e("المعاينة المُدارة فشلت — التحويل إلى رد نداء PlayM4")
            managed = false
            if (!startPlay()) { l.onDisconnected(); return }
        }
        if (managed) startSnapshots(l)
        watchdog = Thread({
            var alerted = false
            var lastStat = 0L
            while (running) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                val now = SystemClock.elapsedRealtime()
                val since = now - playStartMs
                if (since - lastStat >= 2000 && since < 17000) { lastStat = since - since % 2000; CamLog.i("[إحصاء ${since / 1000}ث | ${strategyName()}] ${stats()}") }
                val limit = if (managed) 20000 else if (firstFrameLogged) 6000 else 12000
                val silent = now - lastFrameMs > limit
                if (silent && !alerted) {
                    alerted = true
                    fail("لا إطارات منذ ${limit / 1000} ث (آخر استراتيجية: ${strategyName()}) — رأس النظام=${gotHead} بيانات=${gotData}\n${stats()}")
                    l.onDisconnected()
                }
                if (!silent) alerted = false
            }
        }, "hik-watchdog").also { it.start() }
    }

    /** لقطات JPEG من الجهاز عبر SDK (لا تعتمد على فك PlayM4) ← OpenCV ← قناة رمادية للتحليل. */
    private fun startSnapshots(l: FrameSource.Listener) {
        snapThread = Thread({
            val para = NET_DVR_JPEGPARA().apply { wPicSize = 0xff; wPicQuality = 0 }   // 0xff = دقة البث الحالية، أعلى جودة
            val buf = ByteArray(8 * 1024 * 1024)
            val ret = INT_PTR()
            while (running) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    ret.iValue = 0
                    val ok = synchronized(capLock) { sdk.NET_DVR_CaptureJPEGPicture_NEW(userId, realCh, para, buf, buf.size, ret) }
                    if (!ok || ret.iValue <= 0) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5 || n % 20 == 0L) CamLog.e("فشل التقاط JPEG (القناة $realCh، حجم=${ret.iValue}) — ${lastErr()}")
                        Thread.sleep(1000); continue
                    }
                    val len = ret.iValue
                    val raw = Mat(1, len, CvType.CV_8UC1)
                    raw.put(0, 0, buf, 0, len)
                    val g = Imgcodecs.imdecode(raw, Imgcodecs.IMREAD_GRAYSCALE)
                    raw.release()
                    if (g.empty()) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5) CamLog.e("تعذّر فك JPEG ($len بايت) بـ OpenCV")
                        g.release(); Thread.sleep(1000); continue
                    }
                    val w = g.cols(); val h = g.rows()
                    if (yBuf.size != w * h) yBuf = ByteArray(w * h)
                    g.get(0, 0, yBuf); g.release()
                    val n = snapOk.incrementAndGet()
                    lastFrameMs = SystemClock.elapsedRealtime()
                    val took = lastFrameMs - t0
                    if (n <= 20 || took > 2000) CamLog.i("لقطة #$n: ${w}×${h} JPEG=$len بايت، استغرقت ${took}ms")
                    if (!firstFrameLogged) { firstFrameLogged = true; info("وصلت أول لقطة ${w}×${h} (JPEG $len بايت، ${lastFrameMs - t0}ms)") }
                    listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
                } catch (_: InterruptedException) { return@Thread
                } catch (t: Throwable) { fail("استثناء في لقطات JPEG", t); try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread } }
                val rest = 400 - (SystemClock.elapsedRealtime() - t0)   // ≥ 400ms بين بدايتي لقطتين
                if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return@Thread }
            }
        }, "hik-snapshots").also { it.start() }
    }

    /**
     * لقطة JPEG واحدة من قناة أخرى (قناة الوايتات، افتراضيًا 7) عبر جلسة SDK نفسها — بلا RTSP.
     * التحويل إلى رقم القناة الفعلي بالقاعدة نفسها المستخدمة لقناة العدّادات (تناظرية ثم IP).
     */
    override fun snapshotJpeg(channel: Int): ByteArray? {
        val s = sdkObj ?: return null
        val uid = userId
        if (!running || uid < 0) { CamLog.e("لقطة القناة $channel: لا اتصال بالجهاز"); return null }
        val real = if (chanNum >= channel) startChan + channel - 1 else startDChan + channel - 1
        val para = NET_DVR_JPEGPARA().apply { wPicSize = 0xff; wPicQuality = 0 }
        val ret = INT_PTR()
        for (attempt in 1..3) {
            ret.iValue = 0
            val t0 = SystemClock.elapsedRealtime()
            var out: ByteArray? = null
            val ok = try {
                synchronized(capLock) {   // المخزن المشترك يُستخدم تحت القفل فقط (لقطات القناة 7 تتكرر كل ثانيتين)
                    val ok0 = running && userId == uid && s.NET_DVR_CaptureJPEGPicture_NEW(uid, real, para, snapBuf, snapBuf.size, ret)
                    if (ok0 && ret.iValue > 0) out = snapBuf.copyOf(ret.iValue)
                    ok0
                }
            } catch (t: Throwable) { CamLog.e("استثناء أثناء لقطة القناة $channel", t); false }
            if (ok && out != null) {
                if (++snapLogged <= 5) CamLog.i("لقطة الوايت: القناة $channel (الفعلية $real) ${out!!.size} بايت، ${SystemClock.elapsedRealtime() - t0}ms")
                return out
            }
            CamLog.e("فشل لقطة القناة $channel (الفعلية $real) محاولة $attempt/3 — ${lastErr()}")
            try { Thread.sleep(400) } catch (_: InterruptedException) { return null }
        }
        return null
    }

    private fun startPlay(): Boolean {
        gotHead = false; gotData = false; firstFrameLogged = false
        pktCount.set(0); byteCount.set(0); inputFail.set(0); dispCb.set(0); decCb.set(0); otherTypes.clear()
        val pi = NET_DVR_PREVIEWINFO()
        pi.lChannel = realCh
        pi.dwStreamType = streamType   // 0 رئيسي، 1 فرعي
        pi.dwLinkMode = 0              // TCP
        pi.bBlocked = 1
        if (managed) {
            // المسار الذي تعتمده العيّنة الرسمية: SDK يفك ويرسم بنفسه على السطح (بلا رد نداء)
            pi.hHwnd = holder
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, null)
        } else {
            val cb = RealPlayCallBack { _, dataType, data, size -> onRealData(dataType, data, size) }
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, cb)
        }
        if (playId < 0) { fail("فشل NET_DVR_RealPlay_V40 للقناة $realCh (${strategyName()}) — ${lastErr()}"); return false }
        CamLog.i("بدأ البث playId=$playId — استراتيجية الفك: ${strategyName()}")
        playStartMs = SystemClock.elapsedRealtime(); lastFrameMs = playStartMs
        return true
    }

    private fun stopPlay() {
        try { if (playId >= 0) sdk.NET_DVR_StopRealPlay(playId) } catch (_: Throwable) {}
        try { if (port != -1) { player.stop(port); player.closeStream(port); player.freePort(port) } } catch (_: Throwable) {}
        playId = -1; port = -1
    }

    private fun onRealData(dataType: Int, data: ByteArray, size: Int) {
        try {
            when (dataType) {
                1 -> { // رأس النظام (NET_DVR_SYSHEAD)
                    gotHead = true
                    if (port != -1) return
                    val hex = data.take(minOf(size, 40)).joinToString(" ") { "%02x".format(it) }
                    CamLog.i("وصل رأس النظام ($size بايت): $hex")
                    port = player.getPort()
                    if (port == -1) { fail("PlayM4.getPort: لا منفذ متاح"); return }
                    CamLog.i("PlayM4 sdkVersion=${player.getSdkVersion()} منفذ=$port")
                    player.setStreamOpenMode(port, Player.STREAM_REALTIME)
                    when (strategy) {
                        1 -> CamLog.i("setHardDecode(منفذ,0)=${player.setHardDecode(port, 0)}")
                        2 -> CamLog.i("setHardDecode(منفذ,1)=${player.setHardDecode(port, 1)}")
                        else -> CamLog.i("بلا setHardDecode (السلوك الافتراضي لـ PlayM4)")
                    }
                    player.setEcnTypeChgCB(port, PlayerCallBack.PlayerEncTypeChgCB { t ->
                        CamLog.e("PlayM4: نوع التشفير تغيّر/اكتُشف = $t (قد يكون البث مشفّرًا ويحتاج رمز التحقق)")
                    })
                    if (!player.openStream(port, data, size, 4 * 1024 * 1024)) {
                        fail("PlayM4.openStream فشل: خطأ ${player.getLastError(port)}"); return
                    }
                    CamLog.i("openStream نجح، decoderType=${player.getDecoderType(port)}")
                    val okD = player.setDisplayCB(port, PlayerCallBack.PlayerDisplayCB { _, buf, _, w, h, _, _, _ ->
                        dispCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    val okC = player.setDecodeCB(port, PlayerCallBack.PlayerDecodeCB { _, buf, _, w, h, _, _, _ ->
                        decCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    CamLog.i("setDisplayCB=$okD setDecodeCB=$okC")
                    if (!player.play(port, holder)) fail("PlayM4.play فشل: خطأ ${player.getLastError(port)} (سطح صالح=${holder?.surface?.isValid})")
                    else CamLog.i("PlayM4.play نجح")
                }
                2 -> {
                    pktCount.incrementAndGet(); byteCount.addAndGet(size.toLong())
                    if (!gotData) { gotData = true; CamLog.i("وصلت أول بيانات بث ($size بايت)") }
                    if (port != -1 && !player.inputData(port, data, size)) {
                        inputFail.incrementAndGet(); lastInputErr = player.getLastError(port)
                        if (inputFail.get() <= 5) CamLog.e("PlayM4.inputData فشل: خطأ $lastInputErr")
                    }
                }
                else -> otherTypes.merge(dataType, 1) { a, b -> a + b }
            }
        } catch (t: Throwable) { fail("استثناء في معالجة بيانات البث", t) }
    }

    // =====================================================================================================
    // التسجيلات: بحث + تشغيل بالوقت + فك الإطارات، بجلسة SDK نفسها وبلا RTSP.
    // لم تُجرَّب على جهازك؛ استخدم «فحص التسجيلات» في التطبيق للتأكد من كل خطوة.
    // =====================================================================================================
    @Volatile private var clockOffsetMs = 0L
    @Volatile private var clockAt = 0L
    @Volatile private var clockOk = false

    private fun realChannel(ch: Int) = if (chanNum >= ch) startChan + ch - 1 else startDChan + ch - 1

    private fun naiveToMs(t: NET_DVR_TIME): Long = java.util.Calendar.getInstance().apply {
        clear(); set(t.dwYear, t.dwMonth - 1, t.dwDay, t.dwHour, t.dwMinute, t.dwSecond)
    }.timeInMillis

    private fun netTime(ms: Long): NET_DVR_TIME {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
        return NET_DVR_TIME().apply {
            dwYear = c.get(java.util.Calendar.YEAR); dwMonth = c.get(java.util.Calendar.MONTH) + 1; dwDay = c.get(java.util.Calendar.DAY_OF_MONTH)
            dwHour = c.get(java.util.Calendar.HOUR_OF_DAY); dwMinute = c.get(java.util.Calendar.MINUTE); dwSecond = c.get(java.util.Calendar.SECOND)
        }
    }

    /** ساعة الجهاز: تُقرأ عبر GET_TIMECFG وتُجدَّد كل 5 دقائق؛ بينهما تُستنتج من ساعة الهاتف + الفرق المقاس. */
    override fun deviceNowMs(): Long? {
        val s = sdkObj ?: return null
        val uid = userId
        if (!running || uid < 0) return null
        val now = System.currentTimeMillis()
        if (!clockOk || now - clockAt > 300_000L) {
            val t = NET_DVR_TIME()
            val ok = try { synchronized(capLock) { s.NET_DVR_GetDVRConfig(uid, 118, 0, t) } } catch (e: Throwable) { CamLog.e("قراءة ساعة الجهاز", e); false }
            if (ok && t.dwYear > 2000) {
                clockOffsetMs = naiveToMs(t) - now; clockAt = now; clockOk = true
                CamLog.i("ساعة الجهاز ${t.ToString()} — الفرق عن الهاتف ${clockOffsetMs / 1000} ث")
            } else if (!clockOk) { CamLog.e("فشل قراءة ساعة الجهاز — ${lastErr()}"); return null }
        }
        return now + clockOffsetMs
    }

    override fun findRecordings(channel: Int, fromMs: Long, toMs: Long): List<RecSegment>? {
        val s = sdkObj ?: return null
        val uid = userId
        if (!running || uid < 0) return null
        val cond = NET_DVR_FILECOND().apply {
            lChannel = realChannel(channel); dwFileType = 0xff; dwIsLocked = 0xff; dwUseCardNo = 0
            struStartTime = netTime(fromMs); struStopTime = netTime(toMs)
        }
        val h = s.NET_DVR_FindFile_V30(uid, cond)
        if (h < 0) { CamLog.e("NET_DVR_FindFile_V30 فشل للقناة $channel — ${lastErr()}"); return null }
        val out = ArrayList<RecSegment>()
        try {
            while (running) {
                val d = NET_DVR_FINDDATA_V30()
                val r = s.NET_DVR_FindNextFile_V30(h, d)
                when (r) {
                    1000 -> out.add(RecSegment(naiveToMs(d.struStartTime), naiveToMs(d.struStopTime)))   // NET_DVR_FILE_SUCCESS
                    1002 -> try { Thread.sleep(100) } catch (_: InterruptedException) { break }          // يبحث ...
                    1001, 1003 -> break                                                                   // لا ملفات / انتهت القائمة
                    else -> { CamLog.e("FindNextFile_V30 حالة غير متوقعة $r — ${lastErr()}"); return if (out.isEmpty()) null else out }
                }
            }
        } finally { try { s.NET_DVR_FindClose_V30(h) } catch (_: Throwable) {} }
        return out
    }

    override fun readFrames(
        channel: Int, streamType: Int, fromMs: Long, toMs: Long, minStepMs: Long,
        fastWhen: () -> Boolean, cancel: () -> Boolean, sink: RecordingFrameSink,
    ): ReadOutcome {
        val s = sdkObj ?: return ReadOutcome(ReadEnd.ERROR, -1, 0, "لا اتصال")
        val uid = userId
        if (!running || uid < 0) return ReadOutcome(ReadEnd.ERROR, -1, 0, "لا اتصال")
        val real = realChannel(channel)
        val vod = NET_DVR_VOD_PARA().apply {
            struIDInfo = NET_DVR_STREAM_INFO().also { it.dwChannel = real }
            struBeginTime = netTime(fromMs); struEndTime = netTime(toMs)
            hWnd = null; byDrawFrame = 0; byVolumType = 0; byVolumNum = 0; byStreamType = streamType.toByte(); dwFileIndex = 0; byAudioFile = 0
        }
        val h = s.NET_DVR_PlayBackByTime_V40(uid, vod)
        if (h < 0) return ReadOutcome(ReadEnd.ERROR, -1, 0, "PlayBackByTime_V40 فشل — ${lastErr()}")

        val st = PlaybackState(fromMs, toMs, minStepMs, sink)
        try {
            if (!s.NET_DVR_SetPlayDataCallBack(h, PlaybackCallBack { _, type, data, size -> onPlaybackData(st, type, data, size) }))
                return ReadOutcome(ReadEnd.ERROR, -1, 0, "SetPlayDataCallBack فشل — ${lastErr()}")
            if (!s.NET_DVR_PlayBackControl_V40(h, 1, null, 0, null))   // NET_DVR_PLAYSTART
                return ReadOutcome(ReadEnd.ERROR, -1, 0, "PlayBackControl(PLAYSTART) فشل — ${lastErr()}")
            val t0 = SystemClock.elapsedRealtime()
            var fast = false
            var endSeenAt = 0L
            while (running) {
                try { Thread.sleep(150) } catch (_: InterruptedException) { return finish(st, ReadEnd.CANCELLED, "قُطع") }
                if (cancel()) return finish(st, ReadEnd.CANCELLED, "أُلغيت القراءة")
                if (st.done) return finish(st, ReadEnd.REACHED_END, "")
                val want = fastWhen()
                if (want != fast) {   // 5 = NET_DVR_PLAYFAST، 7 = NET_DVR_PLAYNORMAL
                    if (s.NET_DVR_PlayBackControl_V40(h, if (want) 5 else 7, null, 0, null)) fast = want
                }
                val pos = s.NET_DVR_GetPlayBackPos(h)
                if (pos >= 100) {   // 100 = انتهى المقطع؛ 200 = خلل شبكة
                    if (pos == 100) { if (endSeenAt == 0L) endSeenAt = SystemClock.elapsedRealtime()
                        if (SystemClock.elapsedRealtime() - endSeenAt > 800) return finish(st, if (st.frames > 0) ReadEnd.REACHED_END else ReadEnd.NO_DATA, if (st.frames > 0) "" else "المقطع انتهى بلا إطارات")
                    } else return finish(st, ReadEnd.ERROR, "خلل شبكة أثناء التشغيل (GetPlayBackPos=$pos)")
                }
                val idle = SystemClock.elapsedRealtime() - maxOf(t0, st.lastDataAt)
                if (st.frames == 0 && idle > 20_000) return finish(st, ReadEnd.NO_DATA, "لا بيانات خلال 20ث (التسجيل غير متاح لهذه الفترة بعد؟) pktCount=${st.packets} حالة=${st.note}")
                if (st.frames > 0 && idle > 20_000) return finish(st, ReadEnd.NO_DATA, "توقفت البيانات 20ث")
            }
            return finish(st, ReadEnd.CANCELLED, "أُوقف المصدر")
        } finally {
            try { s.NET_DVR_StopPlayBack(h) } catch (_: Throwable) {}
            try { if (st.port != -1) { player.stop(st.port); player.closeStream(st.port); player.freePort(st.port) } } catch (_: Throwable) {}
        }
    }

    private fun finish(st: PlaybackState, end: ReadEnd, msg: String) = ReadOutcome(end, st.lastDeliveredMs, st.frames, msg)

    private class PlaybackState(val fromMs: Long, val toMs: Long, val minStepMs: Long, val sink: RecordingFrameSink) {
        @Volatile var port = -1
        @Volatile var done = false
        @Volatile var frames = 0
        @Volatile var packets = 0L
        @Volatile var lastDataAt = 0L
        @Volatile var lastDeliveredMs = -1L
        @Volatile var note = ""
        var anchorAbs = Long.MIN_VALUE; var anchorStamp = 0
        var prevStamp = Int.MIN_VALUE
        var y = ByteArray(0)
    }

    private fun onPlaybackData(st: PlaybackState, type: Int, data: ByteArray, size: Int) {
        try {
            st.lastDataAt = SystemClock.elapsedRealtime()
            when (type) {
                1 -> {   // NET_DVR_SYSHEAD
                    if (st.port != -1) return
                    val pr = player.getPort()
                    if (pr == -1) { st.note = "PlayM4.getPort: لا منفذ"; return }
                    player.setStreamOpenMode(pr, Player.STREAM_REALTIME)
                    if (!player.openStream(pr, data, size, 6 * 1024 * 1024)) { st.note = "openStream فشل ${player.getLastError(pr)}"; player.freePort(pr); return }
                    st.port = pr
                    player.setDecodeCB(pr, PlayerCallBack.PlayerDecodeCB { _, buf, _, w, hh, stamp, _, _ -> onPlayedFrame(st, buf, w, hh, stamp) })
                    // بعض الإصدارات تُطلق إطارات العرض فقط؛ نسجّل الاثنين (يُتجاهل المكرر بالوقت)
                    player.setDisplayCB(pr, PlayerCallBack.PlayerDisplayCB { _, buf, _, w, hh, stamp, _, _ -> onPlayedFrame(st, buf, w, hh, stamp) })
                    if (!player.play(pr, null)) st.note = "PlayM4.play فشل ${player.getLastError(pr)}"
                }
                2 -> {   // NET_DVR_STREAMDATA
                    st.packets++
                    val pr = st.port
                    if (pr != -1 && !st.done) player.inputData(pr, data, size)
                }
            }
        } catch (t: Throwable) { CamLog.e("استثناء في بيانات التشغيل", t) }
    }

    private fun onPlayedFrame(st: PlaybackState, buf: ByteArray, w: Int, h: Int, stamp: Int) {
        if (st.done) return
        val n = w * h
        if (n <= 0 || buf.size < n) return
        val pr = st.port
        // زمن الإطار المطلق: مرساة من ساعة الإطار في PlayM4 إن كانت موثوقة (قريبة من المطلوب)، وإلا من بداية الطلب؛ ثم تتابع الأختام
        if (st.anchorAbs == Long.MIN_VALUE || (st.prevStamp != Int.MIN_VALUE && stamp < st.prevStamp - 1000)) {
            var abs = st.fromMs
            try {
                val sys = Player.MPSystemTime()
                if (pr != -1 && player.getSystemTime(pr, sys) && sys.year > 2000) {
                    val c = java.util.Calendar.getInstance().apply { clear(); set(sys.year, sys.month - 1, sys.day, sys.hour, sys.min, sys.sec) }
                    val cand = c.timeInMillis + sys.ms
                    if (kotlin.math.abs(cand - st.fromMs) <= 120_000L) abs = cand else st.note = "ختم PlayM4 المطلق بعيد عن المطلوب؛ اعتُمد وقت الطلب"
                }
            } catch (_: Throwable) {}
            st.anchorAbs = abs; st.anchorStamp = stamp
        }
        st.prevStamp = stamp
        val abs = st.anchorAbs + ((stamp.toLong() - st.anchorStamp.toLong()))
        if (abs >= st.toMs) { st.done = true; return }
        if (abs < st.fromMs - 5_000L) return                        // قبل بداية الطلب (إطار مفتاحي سابق)
        if (st.lastDeliveredMs >= 0 && abs - st.lastDeliveredMs < st.minStepMs) return
        if (abs <= st.lastDeliveredMs) return
        if (st.y.size != n) st.y = ByteArray(n)
        System.arraycopy(buf, 0, st.y, 0, n)
        st.lastDeliveredMs = abs
        st.frames++
        st.sink.onFrame(st.y, w, h, abs)
    }

    override fun stop() {
        running = false
        try {
            watchdog?.interrupt(); snapThread?.interrupt()
            try { snapThread?.join(3000) } catch (_: InterruptedException) {}
            stopPlay()
            // لا نُنهي الجلسة أثناء لقطة جارية (لقطة الوايت من خيط آخر)
            synchronized(capLock) {
                if (userId >= 0) sdk.NET_DVR_Logout_V30(userId)
                sdk.NET_DVR_Cleanup()
            }
        } catch (_: Throwable) {}
        userId = -1; strategy = 0; managed = true; snapOk.set(0); snapFail.set(0)
        CamLog.i("تم إيقاف المصدر")
    }
}
