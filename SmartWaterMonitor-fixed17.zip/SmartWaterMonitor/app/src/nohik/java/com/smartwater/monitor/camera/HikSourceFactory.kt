package com.smartwater.monitor.camera

import android.content.Context
import android.view.SurfaceHolder

/** نسخة بدون Hikvision SDK: تُبنى حين لا توجد app/libs/HCNetSDK.jar. تعلن صراحةً أن الاتصال غير متاح. */
object HikSourceFactory {
    const val AVAILABLE = false

    fun create(
        ctx: Context, ip: String, user: String, pass: String,
        channel: Int, streamType: Int, realChannelOverride: Int, holder: SurfaceHolder?, livePreview: Boolean = true,
    ): FrameSource = object : FrameSource {
        override fun start(listener: FrameSource.Listener) {
            CamLog.e("البناء بلا Hikvision SDK: app/libs/HCNetSDK.jar أو PlayerSDK.jar غير موجود وقت البناء (سر HIKVISION_SDK_URL غير مضبوط في GitHub؟)")
            listener.onStatus("حزمة Hikvision SDK غير مضمّنة في هذا البناء. ضع HCNetSDK.jar و PlayerSDK.jar و ملفات .so ثم أعد البناء (انظر README).")
            listener.onDisconnected()
        }
        override fun stop() {}
    }
}
