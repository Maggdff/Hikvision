import com.smartwater.monitor.core.*
import kotlin.math.abs
import kotlin.random.Random

/**
 * اختبارات جلسة التعبئة من التسجيلات (أوقات جهاز Hikvision بالميلي ثانية) وكاشف وجود الوايت.
 * العدّادات اصطناعية بسرعة 55°/ث؛ 720° = برميل.
 */
object SessionTest {
    private var failures = 0
    private fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "  نجح  " else "  فشل  ") + name + (if (detail.isNotEmpty()) "  -> $detail" else "")); if (!ok) failures++
    }
    private const val V = 55.0
    private const val E = 1_000_000_000L            // وقت دخول الوايت (ms) — أي رقم
    private fun bar(sec: Double) = sec * V / DEG_PER_BARREL

    /** مقاطع حركة [من، إلى) بالثواني النسبية لدخول الوايت. */
    private class Mv(val meter: Int, val from: Double, val to: Double)

    private class Rig(wiring: Wiring = Wiring.PARALLEL, meters: Int = 2) {
        val finals = ArrayList<Pair<FillSnapshot, SwingResult>>()
        val s = FillSession("S1", E, meters, wiring, SwingParams()) { a, b -> finals.add(a to b) }
        val cum = DoubleArray(meters); val committed = DoubleArray(meters)
        val rnd = Random(3)
        var tSec = 0.0
        /** يغذّي من from إلى to ثانية. outage: لا إطارات (التسجيل غير متاح) لكن الماء يتدفق فعليًا. */
        fun run(moves: List<Mv>, to: Double, outages: List<Pair<Double, Double>> = emptyList(), noise: Double = 0.3) {
            val dt = 0.1
            while (tSec <= to) {
                for (mv in moves) if (tSec >= mv.from && tSec < mv.to) cum[mv.meter] += V * dt
                val out = outages.any { tSec >= it.first && tSec < it.second }
                if (!out) {
                    val samples = cum.indices.map { i ->
                        val meas = cum[i] + rnd.nextDouble(-noise, noise)
                        if (meas - committed[i] > 1.5) committed[i] = meas
                        MeterSample(tSec, true, committed[i], 0.0, 0.1, 0.0, 0.0, false)
                    }
                    s.feed(E + (tSec * 1000).toLong(), samples)
                }
                tSec += dt
            }
        }
    }

    @JvmStatic fun main(a: Array<String>) {
        println("A) جلسة تعبئة بعدّاد واحد: بدء التدفق، حساب، مهلة دقيقة، نهاية عند آخر حركة فعلية")
        run {
            val r = Rig()
            r.run(emptyList(), 10.0)
            check("قبل التدفق: بانتظار بدء التدفق (وليس حسابًا)", r.s.snapshot().state == FillState.WAITING_FLOW && r.s.snapshot().totalBarrels == 0.0)
            r.run(listOf(Mv(0, 20.0, 60.0)), 40.0)
            val mid = r.s.snapshot()
            check("أثناء الحركة: جارٍ حساب الماء + كمية تراكمية تتزايد", mid.state == FillState.COUNTING && mid.totalBarrels > bar(10.0), "%.2f".format(mid.totalBarrels))
            r.run(listOf(Mv(0, 20.0, 60.0)), 80.0)
            val w = r.s.snapshot()
            check("بعد التوقف: بانتظار انتهاء مهلة الدقيقة مع عدّ تنازلي", w.state == FillState.STOP_WAIT && (w.graceRemainingSec ?: 0.0) in 30.0..58.0, "متبقٍ ${w.graceRemainingSec}")
            check("لم تُعتمد بعد (لا سجل قبل انقضاء الدقيقة)", r.finals.isEmpty())
            r.run(listOf(Mv(0, 20.0, 60.0)), 130.0)
            check("بعد دقيقة كاملة: اعتُمدت مرة واحدة", r.finals.size == 1, "عدد=${r.finals.size}")
            val f = r.finals[0]
            check("الكمية = 40ث × 55° / 720 (لا تضيع كمية الدقيقة الأولى)", abs(f.second.totalBarrels - bar(40.0)) < 0.06, "%.3f مقابل %.3f".format(f.second.totalBarrels, bar(40.0)))
            val (st, en) = r.s.flowWindowMs()
            check("بداية التدفق الحقيقية ≈ 20ث بعد الدخول", abs((st - E) - 20_000) < 1500, "${(st - E)}ms")
            check("النهاية عند التوقف الفعلي (≈60ث) لا نهاية المهلة (≈120ث)", abs((en - E) - 60_000) < 1500, "${(en - E)}ms")
            check("الوايت موجود بعد الاعتماد: توقف مؤقت (لا إنهاء نهائي)", r.s.snapshot().state == FillState.PAUSED && !r.s.closed)
        }

        println("B) عودة التدفق خلال الدقيقة: نفس العملية دون تصفير")
        run {
            val r = Rig()
            val mv = listOf(Mv(0, 20.0, 50.0), Mv(0, 80.0, 110.0))
            r.run(mv, 150.0)
            check("لا اعتماد بين المقطعين (30ث < 60ث)", r.finals.isEmpty())
            r.run(mv, 200.0)
            check("اعتماد واحد بعد المقطع الثاني + دقيقة", r.finals.size == 1)
            check("الكمية تشمل المقطعين (60ث)", abs(r.finals[0].second.totalBarrels - bar(60.0)) < 0.08, "%.3f".format(r.finals[0].second.totalBarrels))
        }

        println("C) توقف أطول من دقيقة والوايت موجود: اعتماد ثم توقف مؤقت، ثم استئناف على السجل نفسه")
        run {
            val r = Rig()
            val mv = listOf(Mv(0, 20.0, 40.0), Mv(0, 200.0, 230.0))
            r.run(mv, 120.0)
            check("اعتماد أول بعد دقيقة", r.finals.size == 1 && abs(r.finals[0].second.totalBarrels - bar(20.0)) < 0.05)
            check("الحالة: متوقفة مؤقتًا والهوية محفوظة (الجلسة مفتوحة)", r.s.snapshot().state == FillState.PAUSED && !r.s.closed)
            r.run(mv, 210.0)
            check("عند عودة التدفق: جارٍ حساب الماء من جديد بلا تصفير", r.s.snapshot().state == FillState.COUNTING && r.s.snapshot().totalBarrels > bar(20.0))
            r.run(mv, 320.0)
            check("اعتماد ثانٍ يحدّث الجلسة نفسها بإجمالي المقطعين (50ث)", r.finals.size == 2 && abs(r.finals[1].second.totalBarrels - bar(50.0)) < 0.08,
                "%.3f".format(r.finals.last().second.totalBarrels))
        }

        println("D) مغادرة الوايت أثناء انتظار المهلة: إغلاق بعد معالجة المتبقي وبنهاية فعلية")
        run {
            val r = Rig()
            val mv = listOf(Mv(0, 20.0, 40.0))
            r.run(mv, 60.0)
            check("ما زال ينتظر المهلة", r.s.snapshot().state == FillState.STOP_WAIT)
            r.s.truckLeft(E + 50_000)
            r.run(mv, 70.0)
            r.s.finish()
            check("اكتملت التعبئة فورًا دون انتظار بقية المهلة", r.finals.size == 1 && r.s.snapshot().state == FillState.COMPLETED && r.s.closed)
            check("النهاية = آخر حركة فعلية (≈40ث)", abs((r.s.flowWindowMs().second - E) - 40_000) < 1500)
        }
        println("   إغلاق أثناء حركة جارية (غادر الوايت والتسجيل يحوي بقية الحركة)")
        run {
            val r = Rig()
            r.run(listOf(Mv(0, 20.0, 100.0)), 60.0)
            r.s.truckLeft(E + 61_000); r.s.finish()
            check("تُعتمد الحركة الجارية عند الإغلاق", r.finals.size == 1 && r.finals[0].second.totalBarrels > bar(30.0), "%.2f".format(r.finals.firstOrNull()?.second?.totalBarrels ?: -1.0))
        }

        println("E) تأخر/انقطاع التسجيل ليس توقفًا للماء")
        run {
            val r = Rig()
            val mv = listOf(Mv(0, 20.0, 40.0))
            r.run(mv, 45.0)
            r.run(mv, 120.0, outages = listOf(45.0 to 95.0))
            check("بعد انقطاع 50ث لا تُعتمد مهلة الدقيقة (الوقت المرصود فقط)", r.finals.isEmpty(), "اعتُمد=${r.finals.size}")
            r.run(mv, 170.0, outages = listOf(45.0 to 95.0))
            check("وتُعتمد بعد اكتمال دقيقة مرصودة", r.finals.size == 1)
        }
        run {
            val r = Rig()
            val mv = listOf(Mv(0, 20.0, 100.0))
            r.run(mv, 130.0, outages = listOf(40.0 to 60.0))
            check("انقطاع 20ث أثناء الحركة: الماء الذي جرى خلاله محسوب", r.finals.isEmpty() && r.s.snapshot().totalBarrels in bar(75.0)..bar(81.0), "%.2f مقابل %.2f".format(r.s.snapshot().totalBarrels, bar(80.0)))
        }

        println("F) عدّادان معًا: تتبّع مستقل + قاعدة التوصيل")
        for (w in listOf(Wiring.PARALLEL, Wiring.SERIES)) {
            val r = Rig(w)
            val mv = listOf(Mv(0, 20.0, 60.0), Mv(1, 25.0, 65.0))
            r.run(mv, 140.0)
            val f = r.finals.firstOrNull()
            val m0 = f?.first?.meterBarrels?.get(0) ?: 0.0; val m1 = f?.first?.meterBarrels?.get(1) ?: 0.0
            check("$w: كل عدّاد مستقل (40ث لكل منهما)", abs(m0 - bar(40.0)) < 0.06 && abs(m1 - bar(40.0)) < 0.06, "%.2f / %.2f".format(m0, m1))
            val want = if (w == Wiring.PARALLEL) 2 * bar(40.0) else bar(40.0)
            check("$w: الإجمالي ${if (w == Wiring.PARALLEL) "مجموع" else "الأكبر فقط (الماء نفسه لا يُجمع)"}", f != null && abs(f.second.totalBarrels - want) < 0.1, "%.3f مقابل %.3f".format(f?.second?.totalBarrels ?: -1.0, want))
        }

        println("G) حالات حدّية")
        run {
            val r = Rig()
            r.run(listOf(Mv(0, 10.0, 10.4)), 60.0)       // اهتزاز قصير لا تدفق
            r.s.truckLeft(E + 61_000); r.s.finish()
            check("وايت دخل ولم يتدفق ماء: لا اعتماد ولا سجل", r.finals.isEmpty() && r.s.snapshot().state == FillState.IDLE)
        }
        run {
            val r = Rig()
            r.run(listOf(Mv(0, 20.0, 40.0)), 50.0)
            val before = r.s.snapshot().totalBarrels
            val old = r.s.lastProcessedMs
            r.s.feed(old, listOf(MeterSample(0.0, true, 99999.0, 0.0, 0.1, 0.0, 0.0, false), null))      // مكرر
            r.s.feed(old - 5000, listOf(MeterSample(0.0, true, 99999.0, 0.0, 0.1, 0.0, 0.0, false), null)) // أقدم
            check("إطار مكرر أو أقدم من آخر معالَج يُتجاهل (لا تكرار احتساب)", r.s.snapshot().totalBarrels == before && r.s.lastProcessedMs == old)
        }

        presence()
        println(if (failures == 0) "اختبارات الجلسة وكشف الوايت نجحت" else "فشل $failures اختبار")
        if (failures > 0) System.exit(1)
    }

    // ---------- كاشف وجود الوايت (قناة 7) ----------
    private const val W = 320; private const val H = 240
    private fun scene(rnd: Random, gain: Double = 1.0, truck: Int = 0, noise: Int = 4): ByteArray {
        val b = ByteArray(W * H)
        for (y in 0 until H) for (x in 0 until W) {
            var v = 90.0 + 50.0 * y / H + 20.0 * (x / 40 % 2)          // أرض ومبنى ثابتان
            if (truck == 1 && x in 90..260 && y in 80..200) v = 215.0 + (x % 7)          // وايت فاتح
            if (truck == 2 && x in 90..260 && y in 80..200) v = 25.0 + (y % 5)           // وايت داكن
            v = v * gain + rnd.nextInt(-noise, noise + 1)
            b[y * W + x] = v.coerceIn(0.0, 255.0).toInt().toByte()
        }
        return b
    }

    private fun presence() {
        println("H) كاشف وجود الوايت على القناة 7")
        val rnd = Random(5)
        val d = TruckPresenceDetector()
        var t = 5_000_000L
        val events = ArrayList<Pair<String, Long>>()
        fun step(frame: ByteArray) {
            when (val e = d.update(t, frame, W, H)) {
                is PresenceEvent.Entered -> events.add("E" to e.tMs)
                is PresenceEvent.Left -> events.add("L" to e.tMs)
                is PresenceEvent.Replaced -> events.add("R" to e.tMs)
                null -> {}
            }
            t += 2000
        }
        repeat(8) { step(scene(rnd)) }
        check("منطقة فارغة بضجيج فقط: لا أحداث", events.isEmpty())
        repeat(6) { i -> step(scene(rnd, gain = 1.0 + 0.012 * i)) }
        check("تغيّر إضاءة بطيء لا يُعدّ وايتًا", events.isEmpty() && !d.present)
        val tEnter = t
        step(scene(rnd, truck = 1)); check("لقطة واحدة غير كافية (لا تأكيد بعد)", events.isEmpty())
        step(scene(rnd, truck = 1)); step(scene(rnd, truck = 1))
        check("دخول الوايت مؤكَّد بعد 3 لقطات", events.size == 1 && events[0].first == "E" && d.present)
        check("وقت البداية = أول لقطة متغيّرة لا لحظة التأكيد", events[0].second == tEnter, "${events[0].second - tEnter}ms")
        repeat(10) { step(scene(rnd, truck = 1)) }
        check("بقاء الوايت لا يولّد أحداثًا جديدة", events.size == 1)
        step(scene(rnd, truck = 2)); step(scene(rnd, truck = 2)); step(scene(rnd, truck = 2))
        check("استبدال بوايت مختلف (دون إفراغ المنطقة) يُرصد", events.size == 2 && events[1].first == "R", events.joinToString { it.first })
        val tLeave = t
        repeat(2) { step(scene(rnd)) }
        check("لقطتان فارغتان لا تكفيان للمغادرة", events.size == 2 && d.present)
        repeat(3) { step(scene(rnd)) }
        check("مغادرة مؤكدة بعد 4 لقطات فارغة بوقت أول لقطة فارغة", events.size == 3 && events[2].first == "L" && events[2].second == tLeave)

        val zone = TruckPresenceDetector(PresenceParams(zone = doubleArrayOf(0.0, 0.0, 0.25, 0.25)))
        val ev = ArrayList<PresenceEvent>(); var tz = 0L
        repeat(3) { zone.update(tz, scene(rnd), W, H); tz += 2000 }
        repeat(6) { zone.update(tz, scene(rnd, truck = 1), W, H)?.let { e -> ev.add(e) }; tz += 2000 }
        check("وايت خارج منطقة التعبئة المحدّدة لا يُحتسب", ev.isEmpty())
    }
}
