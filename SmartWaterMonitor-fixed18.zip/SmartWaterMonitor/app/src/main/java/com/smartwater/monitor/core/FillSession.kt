package com.smartwater.monitor.core

import kotlin.math.max

/** طريقة توصيل العدّادين: تفرّع = كل عدّاد يقيس ماءً مختلفًا فيُجمعان؛ تسلسل = يقيسان الماء نفسه فيُؤخذ الأكبر ولا يُجمعان. */
enum class Wiring { PARALLEL, SERIES;
    fun combine(barrels: List<Double>): Double = when (this) {
        PARALLEL -> barrels.sum()
        SERIES -> barrels.maxOrNull() ?: 0.0
    }
}

enum class FillState(val ar: String) {
    IDLE("لا يوجد وايت"),
    TRUCK_DETECTED("تم التعرف على الوايت"),
    WAITING_FLOW("بانتظار بدء التدفق"),
    COUNTING("جارٍ حساب الماء"),
    STOP_WAIT("بانتظار انتهاء مهلة الدقيقة"),
    PAUSED("توقف مؤقت"),
    COMPLETED("اكتملت التعبئة"),
}

class FillSnapshot(
    val sessionId: String,
    val state: FillState,
    val meterBarrels: List<Double>,
    /** الإجمالي بحسب طريقة التوصيل. */
    val totalBarrels: Double,
    val flowStartMs: Long?,
    /** آخر لحظة حركة فعلية (وليس نهاية المهلة). */
    val lastFlowMs: Long?,
    val lastProcessedMs: Long,
    val graceRemainingSec: Double?,
    val finalizedOnce: Boolean,
    val closed: Boolean,
    val notes: String,
)

/**
 * جلسة تعبئة لوايت واحد، تُغذّى بعيّنات العدّادين بأوقات تسجيل جهاز Hikvision (ms):
 *  - بدء التدفق = أول حركة حقيقية للعدّادات في التسجيل (دخول الوايت وحده لا يكفي).
 *  - كل عدّاد يُتتبَّع مستقلًا؛ الإجمالي حسب [Wiring] فلا يُجمع الماء نفسه مرتين.
 *  - بعد سكون العدّادين تنتظر مهلة (60ث مرصودة) فإن عاد التدفق استمرت الجلسة دون تصفير، وإن لم يعد اعتُمدت
 *    الكمية حتى آخر حركة فعلية، وتبقى الجلسة «متوقفة مؤقتًا» ما دام الوايت موجودًا.
 *  - تُغلق نهائيًا فقط عبر [finish] بعد غياب الوايت ومعالجة ما تبقى من التسجيل.
 */
class FillSession(
    val id: String,
    val enterMs: Long,
    private val meters: Int,
    private val wiring: Wiring,
    params: SwingParams,
    graceSec: Double = 60.0,
    /** تُستدعى عند كل اعتماد (انتهاء مهلة التوقف أو الإغلاق): احفظ/حدّث السجل. */
    private val onFinalized: (FillSnapshot, SwingResult) -> Unit,
) {
    private val carried = DoubleArray(meters)          // درجات ما اعتُمد سابقًا (قبل توقفات مؤقتة)
    private var flowStartT: Double? = null
    private var lastFlowT: Double? = null
    private var finalizedCount = 0
    private val notes = LinkedHashSet<String>()
    private val engine = SwingEngine(meters, params.copy(resolveGraceSec = graceSec)) { r -> onResult(r) }

    @Volatile var truckPresent = true
        private set

    /** هل الوايت تحت القصبة الآن (من كاشف القناة 7). يتحكم بين «توقف مؤقت» و«اكتملت التعبئة». */
    fun setTruckPresent(b: Boolean) { if (!closed) truckPresent = b }

    fun isActive(i: Int) = engine.isActive(i)
    fun currentDegrees(i: Int) = engine.currentDegrees(i)
    /** درجات الجلسة التراكمية للعدّاد (ما اعتُمد + الجاري). */
    fun cumulativeDegrees(i: Int) = degrees(i)
    @Volatile var truckLeftMs: Long? = null
        private set
    @Volatile var lastProcessedMs: Long = Long.MIN_VALUE
        private set
    private var frames = 0
    @Volatile var closed = false
        private set

    private fun tSec(ms: Long) = (ms - enterMs) / 1000.0
    private fun ms(t: Double) = enterMs + (t * 1000.0).toLong()

    fun truckLeft(tMs: Long) { truckPresent = false; if (truckLeftMs == null) truckLeftMs = tMs }

    /** إطار مسجَّل بوقت الجهاز (ms). الإطارات المتأخرة/المكررة (≤ آخر معالَج) تُتجاهل. */
    fun feed(tMs: Long, samples: List<MeterSample?>) {
        if (closed || tMs <= lastProcessedMs) return
        lastProcessedMs = tMs
        frames++
        engine.update(tSec(tMs), samples)
    }

    /** تبلّغ بانقطاع في التسجيل: لا يُحتسب توقفًا. */
    fun markGap() { if (!closed) engine.markGap() }

    private fun onResult(r: SwingResult) {
        for (p in r.parts) carried[p.meter] += p.degrees
        val st = r.parts.minOf { it.startT }; val en = r.parts.maxOf { it.endT }
        flowStartT = minOf(flowStartT ?: st, st); lastFlowT = max(lastFlowT ?: en, en)
        if (r.notes.isNotEmpty()) r.notes.split("؛ ").forEach { notes.add(it) }
        finalizedCount++
        onFinalized(snapshot(), result())
    }

    /** يُغلق نهائيًا (غادر الوايت وعولج التسجيل المتبقي): يعتمد ما تبقى من حركة جارية. */
    fun finish() {
        if (closed) return
        engine.flush()          // قد يعتمد حركة جارية/ما ينتظر المهلة (نهايته عند آخر حركة فعلية)
        closed = true
    }

    private fun degrees(i: Int) = carried[i] + engine.episodeDegrees(i)
    val hasFlowed: Boolean get() = finalizedCount > 0 || engine.isEpisodeOpen()

    private fun firstMotion(): Double? {
        val e = engine.firstMotionT()
        return when { flowStartT != null && e != null -> minOf(flowStartT!!, e); else -> flowStartT ?: e }
    }
    private fun lastMotion(): Double? {
        val e = engine.lastMotionT()
        return when { lastFlowT != null && e != null -> max(lastFlowT!!, e); else -> lastFlowT ?: e }
    }

    fun snapshot(): FillSnapshot {
        val bar = (0 until meters).map { degrees(it) / DEG_PER_BARREL }
        val grace = engine.graceRemaining()
        val active = (0 until meters).any { engine.isActive(it) }
        val flowed = hasFlowed
        val state = when {
            closed -> if (flowed) FillState.COMPLETED else FillState.IDLE
            active -> FillState.COUNTING
            grace != null -> FillState.STOP_WAIT
            flowed -> if (truckPresent) FillState.PAUSED else FillState.COMPLETED
            frames > 0 -> FillState.WAITING_FLOW
            else -> FillState.TRUCK_DETECTED
        }
        return FillSnapshot(
            id, state, bar, wiring.combine(bar),
            firstMotion()?.let { ms(it) }, lastMotion()?.let { ms(it) },
            lastProcessedMs, grace, finalizedCount > 0, closed, notes.joinToString("؛ "),
        )
    }

    /** نتيجة جاهزة للسجل: العدّادان بحسب التوصيل؛ البداية/النهاية بوقت الجهاز (النهاية = آخر حركة فعلية). */
    fun result(): SwingResult {
        val st = firstMotion() ?: 0.0
        val en = lastMotion() ?: st
        val parts = (0 until meters).filter { degrees(it) > 0.0 }.map { MeterPart(it, degrees(it), st, en) }
            .ifEmpty { listOf(MeterPart(0, 0.0, st, en)) }
        val type = if (parts.size >= 2) SwingType.FULL else SwingType.METER
        val total = wiring.combine((0 until meters).map { degrees(it) / DEG_PER_BARREL })
        return SwingResult(type, parts, notes.joinToString("؛ "), if (wiring == Wiring.SERIES) total else null)
    }

    /** وقت بدء التدفق ونهايته الفعلية (ms) بوقت الجهاز، لحفظهما في السجل. */
    fun flowWindowMs(): Pair<Long, Long> {
        val st = firstMotion() ?: tSec(enterMs)
        return ms(st) to ms(lastMotion() ?: st)
    }
}
