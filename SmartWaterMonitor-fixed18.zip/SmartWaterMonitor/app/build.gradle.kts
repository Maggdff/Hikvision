plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Hikvision SDK مرخّص ولا يمكن توزيعه مع المشروع: ضع HCNetSDK.jar و PlayerSDK.jar في app/libs
// و ملفات .so في app/src/main/jniLibs/<abi>/ (أو استخدم scripts/install_hik_sdk.sh).
// عند غيابها يُبنى التطبيق بمصدر "غير متاح" صريح بدل أن يفشل البناء.
val hasHik = file("libs/HCNetSDK.jar").exists() && file("libs/PlayerSDK.jar").exists()

android {
    namespace = "com.smartwater.monitor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.smartwater.monitor"
        minSdk = 26
        targetSdk = 34
        // يرتفع تلقائيًا مع كل بناء في GitHub ليقبله المثبّت كتحديث فوق النسخة السابقة
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.4"
        buildConfigField("boolean", "HAS_HIK_SDK", hasHik.toString())
        // مكتبات Hikvision SDK المرفقة 32-بت (ARMv7) فقط: يجب أن تعمل العملية 32-بت وإلا فشل تحميلها (UnsatisfiedLinkError)
        ndk { abiFilters += listOf("armeabi-v7a") }
    }

    buildFeatures { buildConfig = true }

    // توقيع داخلي ثابت داخل المشروع (app/smartwater-internal.jks): لا يحتاج أي secret في GitHub.
    // ثبات التوقيع بين البنيات يسمح بتحديث التطبيق فوق النسخة المثبّتة دون حذفها (فتبقى المعايرة والسجل).
    // للاستعمال الداخلي فقط؛ احتفظ بالمستودع خاصًا ولا تنشر بهذا المفتاح على متجر.
    signingConfigs {
        create("internal") {
            storeFile = file("smartwater-internal.jks")
            storeType = "pkcs12"
            storePassword = "smartwater"
            keyAlias = "smartwater"
            keyPassword = "smartwater"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("internal") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("internal")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { jniLibs { useLegacyPackaging = true } } // Hikvision يحمّل مكوّناته من مجلد المكتبات

    sourceSets {
        getByName("main") {
            java.srcDir(if (hasHik) "src/hik/java" else "src/nohik/java")
        }
    }
}

dependencies {
    implementation("org.opencv:opencv:4.9.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    if (hasHik) implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))
}
