package com.smartwater.monitor.camera

import android.content.Context
import android.os.SystemClock
import android.view.SurfaceHolder
import com.hikvision.netsdk.ExceptionCallBack
import com.hikvision.netsdk.HCNetSDK
import com.hikvision.netsdk.INT_PTR
import com.hikvision.netsdk.NET_DVR_JPEGPARA
import com.hikvision.netsdk.NET_DVR_DEVICEINFO_V30
import com.hikvision.netsdk.NET_DVR_PREVIEWINFO
import com.hikvision.netsdk.RealPlayCallBack
import org.MediaPlayer.PlayM4.Player
import org.MediaPlayer.PlayM4.PlayerCallBack
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgcodecs.Imgcodecs

object HikSourceFactory {
    const val AVAILABLE = true

    fun create(
        ctx: Context, ip: String, user: String, pass: String,
        channel: Int, streamType: Int, realChannelOverride: Int, holder: SurfaceHolder?,
    ): FrameSource = HikvisionSource(ip, user, pass, channel, streamType, realChannelOverride, holder)
}

/**
 * اتصال Hikvision SDK (HCNetSDK) على المنفذ 8000 وبث القناة المطلوبة، وفك الترميز بـ PlayM4 مع
 * استدعاء العرض (YV12) لأخذ قناة Y.
 *
 * تنبيه: كُتب هذا الصنف وفق واجهة SDK (HCNetSDK/PlayM4 للأندرويد) كما في العيّنة الرسمية، لكنه لم يُجرَّب
 * مع كاميرا حقيقية ولا مع الـ SDK في بيئة التطوير. راجع أي اختلاف في أسماء الدوال بحسب إصدار SDK لديك.
 */
class HikvisionSource(
    private val ip: String,
    private val user: String,
    private val pass: String,
    private val channel: Int,
    private val streamType: Int,
    private val realChannelOverride: Int,
    private val holder: SurfaceHolder?,
) : FrameSource {
    private var sdkObj: HCNetSDK? = null
    private val sdk get() = sdkObj!!
    private val player get() = Player.getInstance()

    @Volatile private var running = false
    private var userId = -1
    private var playId = -1
    private var port = -1
    private var listener: FrameSource.Listener? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var gotHead = false
    @Volatile private var gotData = false
    @Volatile private var firstFrameLogged = false
    private var watchdog: Thread? = null
    private var yBuf = ByteArray(0)
    private val pktCount = java.util.concurrent.atomic.AtomicLong()
    private val byteCount = java.util.concurrent.atomic.AtomicLong()
    private val inputFail = java.util.concurrent.atomic.AtomicLong()
    private val dispCb = java.util.concurrent.atomic.AtomicLong()
    private val decCb = java.util.concurrent.atomic.AtomicLong()
    private val otherTypes = java.util.concurrent.ConcurrentHashMap<Int, Int>()
    @Volatile private var lastInputErr = 0
    @Volatile private var strategy = 0          // 0 افتراضي، 1 فك برمجي، 2 فك عتادي
    @Volatile private var playStartMs = 0L
    private var realCh = 0
    @Volatile private var managed = true        // true: معاينة يديرها SDK (hHwnd) + لقطات JPEG للتحليل
    private var snapThread: Thread? = null
    private val snapOk = java.util.concurrent.atomic.AtomicLong()
    private val snapFail = java.util.concurrent.atomic.AtomicLong()
    private fun strategyName() = if (managed) "معاينة SDK المُدارة (hHwnd) + لقطات JPEG" else "رد نداء PlayM4 (احتياطي)"

    /** يستقبل YV12 من أي من callbacks PlayM4 (عرض/فك) ويمرّر قناة Y. */
    private fun onYv12(buf: ByteArray, w: Int, h: Int) {
        val n = w * h
        if (n <= 0 || buf.size < n) { CamLog.e("إطار غير صالح: ${w}×${h} حجم=${buf.size}"); return }
        if (yBuf.size != n) yBuf = ByteArray(n)
        System.arraycopy(buf, 0, yBuf, 0, n)
        lastFrameMs = SystemClock.elapsedRealtime()
        if (!firstFrameLogged) { firstFrameLogged = true; info("وصل أول إطار ${w}×${h}") }
        listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
    }

    private fun stats(): String {
        val pr = port
        val extra = if (pr != -1) try {
            " | decoderType=${player.getDecoderType(pr)} fps=${player.getCurrentFrameRate(pr)} " +
            "مفكوك=${player.getPlayedFrames(pr)} bufRemain=${player.getSourceBufferRemain(pr)} plErr=${player.getLastError(pr)}"
        } catch (t: Throwable) { " | stats-err=${t.message}" } else ""
        return "لقطاتJPEG نجحت=${snapOk.get()} فشلت=${snapFail.get()} | حزم=${pktCount.get()} بايت=${byteCount.get()} inputDataفشل=${inputFail.get()}(آخر خطأ $lastInputErr) " +
            "displayCB=${dispCb.get()} decodeCB=${decCb.get()} أنواع أخرى=$otherTypes$extra"
    }

    private fun info(m: String) { CamLog.i(m); listener?.onStatus(m) }
    private fun fail(m: String, t: Throwable? = null) { CamLog.e(m, t); listener?.onStatus("خطأ: $m") }

    private fun errName(code: Int) = when (code) {
        1 -> "كلمة المرور/المستخدم خاطئ"; 2 -> "صلاحيات غير كافية"; 3 -> "SDK غير مهيّأ"
        4 -> "رقم القناة خاطئ"; 5 -> "تجاوز عدد الاتصالات"; 6 -> "عدم توافق إصدار SDK مع الجهاز"
        7 -> "تعذّر الاتصال بالجهاز (IP/المنفذ/الشبكة)"; 8 -> "فشل الإرسال"; 9 -> "فشل الاستقبال"
        10 -> "انتهت مهلة الاستقبال"; 11 -> "بيانات خاطئة"; 17 -> "معامل خاطئ"; 23 -> "غير مدعوم"
        47 -> "المستخدم غير موجود"; 153 -> "الحساب مقفل (محاولات خاطئة كثيرة)"
        else -> "غير معروف"
    }
    private fun lastErr(): String { val c = sdk.NET_DVR_GetLastError(); return "رمز الخطأ $c (${errName(c)})" }

    override fun start(listener: FrameSource.Listener) {
        this.listener = listener
        running = true
        Thread({
            try { connect(listener) }
            catch (t: Throwable) {   // UnsatisfiedLinkError / NoSuchMethodError وغيرها: كانت تُسقط التطبيق بصمت
                fail("استثناء أثناء الاتصال (غالبًا مكتبات SDK .so أو نسخة jar لا تطابق)", t)
                listener.onDisconnected()
            }
        }, "hik-connect").start()
    }

    private fun connect(l: FrameSource.Listener) {
        CamLog.i("=== بدء الاتصال: $ip:8000 مستخدم=$user قناة=$channel بث=$streamType (CPU: ${android.os.Build.SUPPORTED_ABIS.joinToString()}) ===")
        sdkObj = HCNetSDK.getInstance()
            ?: run { fail("HCNetSDK.getInstance() أعادت null — مكتبات SDK لم تُحمَّل"); l.onDisconnected(); return }
        if (!sdk.NET_DVR_Init()) { fail("فشل NET_DVR_Init — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("NET_DVR_Init نجح")
        sdk.NET_DVR_SetConnectTime(5000)   // التوقيع في هذا الـ jar: (int) فقط
        sdk.NET_DVR_SetReconnect(10000, true)
        val dev = NET_DVR_DEVICEINFO_V30()
        userId = sdk.NET_DVR_Login_V30(ip, 8000, user, pass, dev)
        if (userId < 0) { fail("فشل تسجيل الدخول إلى $ip:8000 — ${lastErr()}"); l.onDisconnected(); return }
        CamLog.i("تسجيل الدخول نجح userId=$userId — تناظرية=${dev.byChanNum} IP=${dev.byIPChanNum} " +
            "byStartChan=${dev.byStartChan} byStartDChan=${dev.byStartDChan}")
        // رقم القناة: تناظرية = byStartChan + n - 1، وإلا قنوات IP = byStartDChan + n - 1
        val real = when {
            realChannelOverride > 0 -> realChannelOverride
            dev.byChanNum.toInt() >= channel -> dev.byStartChan.toInt() + channel - 1
            else -> dev.byStartDChan.toInt() + channel - 1
        }
        info("تم الدخول. فتح القناة الفعلية $real (المطلوبة $channel) ...")
        sdk.NET_DVR_SetExceptionCallBack(ExceptionCallBack { type, handle, _ ->
            CamLog.e("استثناء SDK نوع=0x${Integer.toHexString(type)} handle=$handle — ${lastErr()}")
            // في الوضع المُدار مصدر الصور لقطات JPEG لا بث المعاينة، فإشعارات إعادة اتصال المعاينة (0x8005 …)
            // لا تعني انقطاع الصور؛ الانقطاع الحقيقي هو فقدان جلسة الاتصال (0x8000)
            if (!managed || type == 0x8000) l.onDisconnected()
        })

        val valid = holder?.surface?.isValid == true
        CamLog.i("سطح العرض لـ PlayM4: ${if (holder == null) "null" else if (valid) "صالح" else "غير صالح (لم يُنشأ بعد أو دُمّر)"}")

        realCh = real
        if (!startPlay()) {
            CamLog.e("المعاينة المُدارة فشلت — التحويل إلى رد نداء PlayM4")
            managed = false
            if (!startPlay()) { l.onDisconnected(); return }
        }
        if (managed) startSnapshots(l)
        watchdog = Thread({
            var alerted = false
            var lastStat = 0L
            while (running) {
                try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                val now = SystemClock.elapsedRealtime()
                val since = now - playStartMs
                if (since - lastStat >= 2000 && since < 17000) { lastStat = since - since % 2000; CamLog.i("[إحصاء ${since / 1000}ث | ${strategyName()}] ${stats()}") }
                val limit = if (managed) 20000 else if (firstFrameLogged) 6000 else 12000
                val silent = now - lastFrameMs > limit
                if (silent && !alerted) {
                    alerted = true
                    fail("لا إطارات منذ ${limit / 1000} ث (آخر استراتيجية: ${strategyName()}) — رأس النظام=${gotHead} بيانات=${gotData}\n${stats()}")
                    l.onDisconnected()
                }
                if (!silent) alerted = false
            }
        }, "hik-watchdog").also { it.start() }
    }

    /** لقطات JPEG من الجهاز عبر SDK (لا تعتمد على فك PlayM4) ← OpenCV ← قناة رمادية للتحليل. */
    private fun startSnapshots(l: FrameSource.Listener) {
        snapThread = Thread({
            val para = NET_DVR_JPEGPARA().apply { wPicSize = 0xff; wPicQuality = 0 }   // 0xff = دقة البث الحالية، أعلى جودة
            val buf = ByteArray(8 * 1024 * 1024)
            val ret = INT_PTR()
            while (running) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    ret.iValue = 0
                    val ok = sdk.NET_DVR_CaptureJPEGPicture_NEW(userId, realCh, para, buf, buf.size, ret)
                    if (!ok || ret.iValue <= 0) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5 || n % 20 == 0L) CamLog.e("فشل التقاط JPEG (القناة $realCh، حجم=${ret.iValue}) — ${lastErr()}")
                        Thread.sleep(1000); continue
                    }
                    val len = ret.iValue
                    val raw = Mat(1, len, CvType.CV_8UC1)
                    raw.put(0, 0, buf, 0, len)
                    val g = Imgcodecs.imdecode(raw, Imgcodecs.IMREAD_GRAYSCALE)
                    raw.release()
                    if (g.empty()) {
                        val n = snapFail.incrementAndGet()
                        if (n <= 5) CamLog.e("تعذّر فك JPEG ($len بايت) بـ OpenCV")
                        g.release(); Thread.sleep(1000); continue
                    }
                    val w = g.cols(); val h = g.rows()
                    if (yBuf.size != w * h) yBuf = ByteArray(w * h)
                    g.get(0, 0, yBuf); g.release()
                    val n = snapOk.incrementAndGet()
                    lastFrameMs = SystemClock.elapsedRealtime()
                    val took = lastFrameMs - t0
                    if (n <= 20 || took > 2000) CamLog.i("لقطة #$n: ${w}×${h} JPEG=$len بايت، استغرقت ${took}ms")
                    if (!firstFrameLogged) { firstFrameLogged = true; info("وصلت أول لقطة ${w}×${h} (JPEG $len بايت، ${lastFrameMs - t0}ms)") }
                    listener?.onFrame(yBuf, w, h, SystemClock.elapsedRealtimeNanos() / 1e9)
                } catch (_: InterruptedException) { return@Thread
                } catch (t: Throwable) { fail("استثناء في لقطات JPEG", t); try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread } }
                val rest = 400 - (SystemClock.elapsedRealtime() - t0)   // ≥ 400ms بين بدايتي لقطتين
                if (rest > 0) try { Thread.sleep(rest) } catch (_: InterruptedException) { return@Thread }
            }
        }, "hik-snapshots").also { it.start() }
    }

    private fun startPlay(): Boolean {
        gotHead = false; gotData = false; firstFrameLogged = false
        pktCount.set(0); byteCount.set(0); inputFail.set(0); dispCb.set(0); decCb.set(0); otherTypes.clear()
        val pi = NET_DVR_PREVIEWINFO()
        pi.lChannel = realCh
        pi.dwStreamType = streamType   // 0 رئيسي، 1 فرعي
        pi.dwLinkMode = 0              // TCP
        pi.bBlocked = 1
        if (managed) {
            // المسار الذي تعتمده العيّنة الرسمية: SDK يفك ويرسم بنفسه على السطح (بلا رد نداء)
            pi.hHwnd = holder
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, null)
        } else {
            val cb = RealPlayCallBack { _, dataType, data, size -> onRealData(dataType, data, size) }
            playId = sdk.NET_DVR_RealPlay_V40(userId, pi, cb)
        }
        if (playId < 0) { fail("فشل NET_DVR_RealPlay_V40 للقناة $realCh (${strategyName()}) — ${lastErr()}"); return false }
        CamLog.i("بدأ البث playId=$playId — استراتيجية الفك: ${strategyName()}")
        playStartMs = SystemClock.elapsedRealtime(); lastFrameMs = playStartMs
        return true
    }

    private fun stopPlay() {
        try { if (playId >= 0) sdk.NET_DVR_StopRealPlay(playId) } catch (_: Throwable) {}
        try { if (port != -1) { player.stop(port); player.closeStream(port); player.freePort(port) } } catch (_: Throwable) {}
        playId = -1; port = -1
    }

    private fun onRealData(dataType: Int, data: ByteArray, size: Int) {
        try {
            when (dataType) {
                1 -> { // رأس النظام (NET_DVR_SYSHEAD)
                    gotHead = true
                    if (port != -1) return
                    val hex = data.take(minOf(size, 40)).joinToString(" ") { "%02x".format(it) }
                    CamLog.i("وصل رأس النظام ($size بايت): $hex")
                    port = player.getPort()
                    if (port == -1) { fail("PlayM4.getPort: لا منفذ متاح"); return }
                    CamLog.i("PlayM4 sdkVersion=${player.getSdkVersion()} منفذ=$port")
                    player.setStreamOpenMode(port, Player.STREAM_REALTIME)
                    when (strategy) {
                        1 -> CamLog.i("setHardDecode(منفذ,0)=${player.setHardDecode(port, 0)}")
                        2 -> CamLog.i("setHardDecode(منفذ,1)=${player.setHardDecode(port, 1)}")
                        else -> CamLog.i("بلا setHardDecode (السلوك الافتراضي لـ PlayM4)")
                    }
                    player.setEcnTypeChgCB(port, PlayerCallBack.PlayerEncTypeChgCB { t ->
                        CamLog.e("PlayM4: نوع التشفير تغيّر/اكتُشف = $t (قد يكون البث مشفّرًا ويحتاج رمز التحقق)")
                    })
                    if (!player.openStream(port, data, size, 4 * 1024 * 1024)) {
                        fail("PlayM4.openStream فشل: خطأ ${player.getLastError(port)}"); return
                    }
                    CamLog.i("openStream نجح، decoderType=${player.getDecoderType(port)}")
                    val okD = player.setDisplayCB(port, PlayerCallBack.PlayerDisplayCB { _, buf, _, w, h, _, _, _ ->
                        dispCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    val okC = player.setDecodeCB(port, PlayerCallBack.PlayerDecodeCB { _, buf, _, w, h, _, _, _ ->
                        decCb.incrementAndGet(); onYv12(buf, w, h)
                    })
                    CamLog.i("setDisplayCB=$okD setDecodeCB=$okC")
                    if (!player.play(port, holder)) fail("PlayM4.play فشل: خطأ ${player.getLastError(port)} (سطح صالح=${holder?.surface?.isValid})")
                    else CamLog.i("PlayM4.play نجح")
                }
                2 -> {
                    pktCount.incrementAndGet(); byteCount.addAndGet(size.toLong())
                    if (!gotData) { gotData = true; CamLog.i("وصلت أول بيانات بث ($size بايت)") }
                    if (port != -1 && !player.inputData(port, data, size)) {
                        inputFail.incrementAndGet(); lastInputErr = player.getLastError(port)
                        if (inputFail.get() <= 5) CamLog.e("PlayM4.inputData فشل: خطأ $lastInputErr")
                    }
                }
                else -> otherTypes.merge(dataType, 1) { a, b -> a + b }
            }
        } catch (t: Throwable) { fail("استثناء في معالجة بيانات البث", t) }
    }

    override fun stop() {
        running = false
        try {
            watchdog?.interrupt(); snapThread?.interrupt()
            try { snapThread?.join(3000) } catch (_: InterruptedException) {}
            stopPlay()
            if (userId >= 0) sdk.NET_DVR_Logout_V30(userId)
            sdk.NET_DVR_Cleanup()
        } catch (_: Throwable) {}
        userId = -1; strategy = 0; managed = true; snapOk.set(0); snapFail.set(0)
        CamLog.i("تم إيقاف المصدر")
    }
}
